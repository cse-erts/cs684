/* --- Generated the 27/1/2021 at 15:57 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. jan. 7 20:13:49 CET 2021) --- */
/* --- Command line: /home/kirito/.opam/4.03.0/bin/heptc -target c -s min_avg -hepts min_avg.ept --- */

#ifndef _MAIN_H
#define _MAIN_H

#include "min_avg.h"
#endif // _MAIN_H
