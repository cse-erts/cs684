/* --- Generated the 27/1/2021 at 14:16 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. jan. 7 20:13:49 CET 2021) --- */
/* --- Command line: /home/kirito/.opam/4.03.0/bin/heptc -target c -s edge edge.ept --- */

#ifndef EDGE_H
#define EDGE_H

#include "edge_types.h"
typedef struct Edge__edge_mem {
  int v_1;
  int v;
} Edge__edge_mem;

typedef struct Edge__edge_out {
  int y;
} Edge__edge_out;

void Edge__edge_reset(Edge__edge_mem* self);

void Edge__edge_step(int x, Edge__edge_out* _out, Edge__edge_mem* self);

#endif // EDGE_H
