/* --- Generated the 27/1/2021 at 14:16 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. jan. 7 20:13:49 CET 2021) --- */
/* --- Command line: /home/kirito/.opam/4.03.0/bin/heptc -target c -s edge edge.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "_main.h"

Edge__edge_mem mem;
int main(int argc, char** argv) {
  int step_c;
  int step_max;
  int x;
  Edge__edge_out _res;
  step_c = 0;
  step_max = 0;
  if ((argc==2)) {
    step_max = atoi(argv[1]);
  };
  Edge__edge_reset(&mem);
  while ((!(step_max)||(step_c<step_max))) {
    step_c = (step_c+1);
    
    printf("x ? ");
    scanf("%d", &x);;
    Edge__edge_step(x, &_res, &mem);
    printf("=> ");
    printf("%d ", _res.y);
    puts("");
    fflush(stdout);
  };
  return 0;
}

