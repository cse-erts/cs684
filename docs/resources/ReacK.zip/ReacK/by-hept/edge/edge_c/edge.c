/* --- Generated the 27/1/2021 at 14:16 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. jan. 7 20:13:49 CET 2021) --- */
/* --- Command line: /home/kirito/.opam/4.03.0/bin/heptc -target c -s edge edge.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "edge.h"

void Edge__edge_reset(Edge__edge_mem* self) {
  self->v = true;
}

void Edge__edge_step(int x, Edge__edge_out* _out, Edge__edge_mem* self) {
  
  int v_3;
  int v_2;
  v_2 = !(self->v_1);
  v_3 = (x&&v_2);
  if (self->v) {
    _out->y = false;
  } else {
    _out->y = v_3;
  };
  self->v_1 = _out->y;
  self->v = false;;
}

