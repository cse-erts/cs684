/* --- Generated the 27/1/2021 at 14:16 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. jan. 7 20:13:49 CET 2021) --- */
/* --- Command line: /home/kirito/.opam/4.03.0/bin/heptc -target c -s edge edge.ept --- */

#ifndef EDGE_TYPES_H
#define EDGE_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
#endif // EDGE_TYPES_H
