opam switch 4.03.0
eval $(opam env)
heptc -target c -s eventimes -hepts aut1.ept 
cd aut1_c/
gcc -Wall -c -I $(heptc -where)/c aut1.c 
gcc -Wall -c -I $(heptc -where)/c _main.c 
gcc -o eventimes_sim _main.o aut1.o 
cd ..
hepts -mod Aut1 -node eventimes -exec aut1_c/eventimes_sim
