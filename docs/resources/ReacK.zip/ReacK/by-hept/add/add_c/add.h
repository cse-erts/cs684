/* --- Generated the 27/1/2021 at 14:24 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. jan. 7 20:13:49 CET 2021) --- */
/* --- Command line: /home/kirito/.opam/4.03.0/bin/heptc -target c -s add -hepts add.ept --- */

#ifndef ADD_H
#define ADD_H

#include "add_types.h"
typedef struct Add__add_out {
  int z;
} Add__add_out;

void Add__add_step(int x, int y, Add__add_out* _out);

#endif // ADD_H
