/*
 * eBot_Sandbox.cpp
 *
 *  Created on: 11-Jan-2022
 *      Author: TAs of CS 684 Spring 2021
 */


//---------------------------------- INCLUDES -----------------------------------

#include "eBot_Sandbox.h"


//------------------------------ GLOBAL VARIABLES -------------------------------

// To store 8-bit data of left, center and right white line sensors
unsigned int left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data;
int diff, error, difference_error,integration_error = 0, prev_error, speed, flag = 0;
// To store 8-bit data of 5th IR proximity sensors
unsigned char ir_prox_5_sensor_data;
#define THRESHOLD 160
unsigned char Velocity_max = 200;
float Kp = 1;
float Ki = 0.0000;
float Kd = 0.217;


//---------------------------------- FUNCTIONS ----------------------------------
void pid()
{
    if (center_wl_sensor_data == 0)
    	error = 0;
    else
	error = 120*(right_wl_sensor_data - left_wl_sensor_data);

	difference_error = error - prev_error;
	integration_error += error/50;
	if(error == 0 && center_wl_sensor_data == 1)
		error = -(1 * prev_error);

	speed = Kp * error + Kd * difference_error + Ki * integration_error;
	prev_error = error;

	if (speed > Velocity_max)
		speed = Velocity_max;
	if (speed < -Velocity_max)
		speed = -Velocity_max;
}

/**
 * @brief      Executes the logic to achieve the aim of Lab 3
 */
void traverse_line(void)
{
	forward();
		while(1)
		{

			left_wl_sensor_data = convert_analog_channel_data(left_wl_sensor_channel);
			center_wl_sensor_data = convert_analog_channel_data(center_wl_sensor_channel);
			right_wl_sensor_data = convert_analog_channel_data(right_wl_sensor_channel);

			pid();
			if(speed > 0)
				velocity(Velocity_max - speed, Velocity_max);
			else
			{
				speed = abs(speed);
				velocity(Velocity_max, Velocity_max - speed);
			}
		}
}

