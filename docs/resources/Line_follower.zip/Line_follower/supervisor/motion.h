#include "Arduino.h"

#define DefaultSpeed 255
#define ENL 5
#define ENR 6

#define INLF A1
#define INLB A0
#define INRF A2
#define INRB A3

void motion_init(void);
void forward(void);
void SetSpeed(char ,char );
