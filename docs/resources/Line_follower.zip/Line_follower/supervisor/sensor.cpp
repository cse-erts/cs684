#include "sensor.h"

void sensor_init()
{
  pinMode(Clock, OUTPUT);
  pinMode(Address, OUTPUT);
  pinMode(DataOut, INPUT);
  pinMode(CS, OUTPUT);
}

void AnalogRead(int *sensorValues)
{
  char i,j;
  int channel = 0;
  int values[] = {0,0,0,0,0,0};

  for(j = 0;j < NUM_SENSORS + 1;j++)
  {
    digitalWrite(CS,LOW);
    for(i = 0;i < 10;i++)
    {
      //0 to 4 clock transfer channel address
      if((i < 4) && (j >> (3 - i) & 0x01))
      digitalWrite(Address,HIGH);
      else
      digitalWrite(Address,LOW);

      //0 to 10 clock receives the previous conversion result
      values[j] <<= 1;
      if(digitalRead(DataOut)) 
      values[j] |= 0x01;
      digitalWrite(Clock,HIGH);
      digitalWrite(Clock,LOW);
    }
    //sent 11 to 16 clock 
    for(i = 0;i < 6;i++)
    {
      digitalWrite(Clock,HIGH);
      digitalWrite(Clock,LOW);
    }
    digitalWrite(CS,HIGH);
  }

  for(i = 0;i < NUM_SENSORS;i++)
  {
    sensorValues[i] = values[i+1];
  }
}
