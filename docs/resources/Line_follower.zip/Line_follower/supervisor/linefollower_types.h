/* --- Generated the 12/3/2023 at 0:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. dec. 28 1:30:47 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts linefollower.ept --- */

#ifndef LINEFOLLOWER_TYPES_H
#define LINEFOLLOWER_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
static const long Linefollower__maximum = 80;

#endif // LINEFOLLOWER_TYPES_H
