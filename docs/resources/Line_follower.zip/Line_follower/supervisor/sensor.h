#include "Arduino.h"

#define Clock     13
#define Address   12
#define DataOut   11
#define CS        10

#define NUM_SENSORS 5

void sensor_init(void);
void AnalogRead(int *);
