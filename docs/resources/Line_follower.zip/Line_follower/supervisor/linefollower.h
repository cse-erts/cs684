/* --- Generated the 12/3/2023 at 0:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. dec. 28 1:30:47 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts linefollower.ept --- */

#ifndef LINEFOLLOWER_H
#define LINEFOLLOWER_H

#include "linefollower_types.h"
typedef struct Linefollower__find_velocities_out {
  long v_l;
  long v_r;
} Linefollower__find_velocities_out;

void Linefollower__find_velocities_step(long power_difference,
                                        Linefollower__find_velocities_out* _out);

typedef struct Linefollower__readcalibrated_out {
  long value_line;
} Linefollower__readcalibrated_out;

void Linefollower__readcalibrated_step(long sensor, long calibratedMax_val,
                                       long calibratedMin_val,
                                       Linefollower__readcalibrated_out* _out);

typedef struct Linefollower__check_online_out {
  long on_line;
} Linefollower__check_online_out;

void Linefollower__check_online_step(long sensor_val, long line_in,
                                     Linefollower__check_online_out* _out);

typedef struct Linefollower__average_out {
  long avg;
} Linefollower__average_out;

void Linefollower__average_step(long sensor_val, long i, long avg_in,
                                Linefollower__average_out* _out);

typedef struct Linefollower__readLine_mem {
  long v_19;
  long v_18;
} Linefollower__readLine_mem;

typedef struct Linefollower__readLine_out {
  long sensor_values[5];
  long on_line;
  long avg;
  long sum;
  long last_value;
} Linefollower__readLine_out;

void Linefollower__readLine_reset(Linefollower__readLine_mem* self);

void Linefollower__readLine_step(long sen[5],
                                 Linefollower__readLine_out* _out,
                                 Linefollower__readLine_mem* self);

typedef struct Linefollower__pid_alpha_mem {
  long v_29;
  long v_28;
  long v_26;
  long v;
  Linefollower__readLine_mem readLine;
} Linefollower__pid_alpha_mem;

typedef struct Linefollower__pid_alpha_out {
  long sensor_values[5];
  long on_line;
  long avg;
  long sum;
  long position_alpha;
  long power_difference;
  long v_l;
  long v_r;
} Linefollower__pid_alpha_out;

void Linefollower__pid_alpha_reset(Linefollower__pid_alpha_mem* self);

void Linefollower__pid_alpha_step(long sen[5],
                                  Linefollower__pid_alpha_out* _out,
                                  Linefollower__pid_alpha_mem* self);

typedef struct Linefollower__main_mem {
  Linefollower__pid_alpha_mem pid_alpha;
} Linefollower__main_mem;

typedef struct Linefollower__main_out {
  long sensor_values[5];
  long on_line;
  long avg;
  long sum;
  long position_alpha;
  long power_difference;
  long v_l;
  long v_r;
} Linefollower__main_out;

void Linefollower__main_reset(Linefollower__main_mem* self);

void Linefollower__main_step(long sen0, long sen1, long sen2, long sen3,
                             long sen4, Linefollower__main_out* _out,
                             Linefollower__main_mem* self);

#endif // LINEFOLLOWER_H
