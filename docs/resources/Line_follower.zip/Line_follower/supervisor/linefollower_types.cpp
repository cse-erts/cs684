/* --- Generated the 12/3/2023 at 0:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. dec. 28 1:30:47 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts linefollower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "linefollower_types.h"

