#include "motion.h"

void motion_init()
{
  pinMode(ENL, OUTPUT);
  pinMode(ENR, OUTPUT);
  pinMode(INLF, OUTPUT);
  pinMode(INLB, OUTPUT);
  pinMode(INRF, OUTPUT);
  pinMode(INRB, OUTPUT);
}

void forward()
{
  digitalWrite(INLF, HIGH);
  digitalWrite(INLB, LOW);
  digitalWrite(INRF, HIGH);
  digitalWrite(INRB, LOW);
}

void SetSpeed(char LSpeed,char RSpeed)
{
  analogWrite(ENR, RSpeed);  
  analogWrite(ENL, LSpeed);  
}
