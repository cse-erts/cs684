/* --- Generated the 12/3/2023 at 0:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. dec. 28 1:30:47 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts linefollower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "linefollower.h"

void Linefollower__find_velocities_step(int power_difference,
                                        Linefollower__find_velocities_out* _out) {
  
  int v_9;
  int v_8;
  int v_7;
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int v;
  v_4 = -(power_difference);
  v_5 = (Linefollower__maximum-v_4);
  v_3 = (Linefollower__maximum-power_difference);
  v_2 = (power_difference>0);
  if (v_2) {
    v_7 = 80;
    v_6 = v_3;
  } else {
    v_7 = v_5;
    v_6 = 80;
  };
  v_1 = (power_difference<-80);
  if (v_1) {
    v_9 = 0;
    v_8 = 80;
  } else {
    v_9 = v_7;
    v_8 = v_6;
  };
  v = (power_difference>Linefollower__maximum);
  if (v) {
    _out->v_r = 80;
    _out->v_l = 0;
  } else {
    _out->v_r = v_9;
    _out->v_l = v_8;
  };;
}

void Linefollower__readcalibrated_step(int sensor, int calibratedMax_val,
                                       int calibratedMin_val,
                                       Linefollower__readcalibrated_out* _out) {
  
  int v_17;
  int v_16;
  int v_15;
  int v_14;
  int v_13;
  int v_12;
  int v_11;
  int v_10;
  int v;
  int x;
  int value;
  int denominator;
  int white_line;
  v_10 = (sensor-calibratedMin_val);
  v_11 = (v_10*1000);
  denominator = (calibratedMax_val-calibratedMin_val);
  v_12 = (v_11/denominator);
  v = (denominator==0);
  if (v) {
    x = sensor;
  } else {
    x = v_12;
  };
  v_14 = (x>1000);
  if (v_14) {
    v_15 = 1000;
  } else {
    v_15 = x;
  };
  v_13 = (x<0);
  if (v_13) {
    value = 0;
  } else {
    value = v_15;
  };
  v_17 = (1000-value);
  white_line = false;
  v_16 = (white_line==true);
  if (v_16) {
    _out->value_line = v_17;
  } else {
    _out->value_line = value;
  };;
}

void Linefollower__check_online_step(int sensor_val, int line_in,
                                     Linefollower__check_online_out* _out) {
  
  int v;
  int line;
  v = (sensor_val>400);
  if (v) {
    line = 10;
  } else {
    line = 0;
  };
  _out->on_line = (line+line_in);;
}

void Linefollower__average_step(int sensor_val, int i, int avg_in,
                                Linefollower__average_out* _out) {
  
  int v;
  v = (sensor_val*i);
  _out->avg = (v+avg_in);;
}

void Linefollower__readLine_reset(Linefollower__readLine_mem* self) {
  {
    int i_4;
    for (i_4 = 0; i_4 < 5; ++i_4) {
    }
  };
  {
    int i_3;
    for (i_3 = 0; i_3 < 5; ++i_3) {
    }
  };
  {
    int i_2;
    for (i_2 = 0; i_2 < 5; ++i_2) {
    }
  };
  {
    int i_1;
    for (i_1 = 0; i_1 < 5; ++i_1) {
    }
  };
  self->v_18 = true;
}

void Linefollower__readLine_step(int sen[5],
                                 Linefollower__readLine_out* _out,
                                 Linefollower__readLine_mem* self) {
  Linefollower__check_online_out Linefollower__check_online_out_st;
  Linefollower__average_out Linefollower__average_out_st;
  Linefollower__readcalibrated_out Linefollower__readcalibrated_out_st;
  
  int v_25;
  int v_24;
  int v_23;
  int v_22;
  int v_21;
  int v_20;
  int v;
  int calibratedMax[5];
  int calibratedMin[5];
  int i[5];
  if (self->v_18) {
    v_20 = 0;
  } else {
    v_20 = self->v_19;
  };
  v_21 = (v_20<2000);
  if (v_21) {
    v_22 = 0;
  } else {
    v_22 = 4000;
  };
  i[0] = 0;
  i[1] = 1000;
  i[2] = 2000;
  i[3] = 3000;
  i[4] = 4000;
  calibratedMin[0] = 0;
  calibratedMin[1] = 0;
  calibratedMin[2] = 0;
  calibratedMin[3] = 0;
  calibratedMin[4] = 0;
  calibratedMax[0] = 1000;
  calibratedMax[1] = 1000;
  calibratedMax[2] = 1000;
  calibratedMax[3] = 1000;
  calibratedMax[4] = 1000;
  {
    int i_4;
    for (i_4 = 0; i_4 < 5; ++i_4) {
      Linefollower__readcalibrated_step(sen[i_4], calibratedMax[i_4],
                                        calibratedMin[i_4],
                                        &Linefollower__readcalibrated_out_st);
      _out->sensor_values[i_4] = Linefollower__readcalibrated_out_st.value_line;
    }
  };
  _out->avg = 0;
  {
    int i_3;
    for (i_3 = 0; i_3 < 5; ++i_3) {
      Linefollower__average_step(_out->sensor_values[i_3], i[i_3], _out->avg,
                                 &Linefollower__average_out_st);
      _out->avg = Linefollower__average_out_st.avg;
    }
  };
  _out->sum = 0;
  {
    int i_2;
    for (i_2 = 0; i_2 < 5; ++i_2) {
      _out->sum = (_out->sensor_values[i_2]+_out->sum);
    }
  };
  _out->on_line = 0;
  {
    int i_1;
    for (i_1 = 0; i_1 < 5; ++i_1) {
      Linefollower__check_online_step(_out->sensor_values[i_1],
                                      _out->on_line,
                                      &Linefollower__check_online_out_st);
      _out->on_line = Linefollower__check_online_out_st.on_line;
    }
  };
  v_24 = (_out->avg/_out->sum);
  v_23 = (_out->sum==0);
  if (v_23) {
    v_25 = 0;
  } else {
    v_25 = v_24;
  };
  v = (_out->on_line==0);
  if (v) {
    _out->last_value = v_22;
  } else {
    _out->last_value = v_25;
  };
  self->v_19 = _out->last_value;
  self->v_18 = false;;
}

void Linefollower__pid_alpha_reset(Linefollower__pid_alpha_mem* self) {
  Linefollower__readLine_reset(&self->readLine);
  self->v_28 = true;
  self->v = true;
}

void Linefollower__pid_alpha_step(int sen[5],
                                  Linefollower__pid_alpha_out* _out,
                                  Linefollower__pid_alpha_mem* self) {
  Linefollower__find_velocities_out Linefollower__find_velocities_out_st;
  Linefollower__readLine_out Linefollower__readLine_out_st;
  
  int v_30;
  int v_27;
  int proportional;
  int integral;
  int derivative;
  Linefollower__readLine_step(sen, &Linefollower__readLine_out_st,
                              &self->readLine);
  {
    int _1;
    for (_1 = 0; _1 < 5; ++_1) {
      _out->sensor_values[_1] = Linefollower__readLine_out_st.sensor_values[_1];
    }
  };
  _out->on_line = Linefollower__readLine_out_st.on_line;
  _out->avg = Linefollower__readLine_out_st.avg;
  _out->sum = Linefollower__readLine_out_st.sum;
  _out->position_alpha = Linefollower__readLine_out_st.last_value;
  proportional = (_out->position_alpha-2000);
  _out->power_difference = (proportional/15);
  Linefollower__find_velocities_step(_out->power_difference,
                                     &Linefollower__find_velocities_out_st);
  _out->v_l = Linefollower__find_velocities_out_st.v_l;
  _out->v_r = Linefollower__find_velocities_out_st.v_r;
  v_30 = (self->v_29+proportional);
  if (self->v_28) {
    integral = proportional;
  } else {
    integral = v_30;
  };
  v_27 = (proportional-self->v_26);
  if (self->v) {
    derivative = proportional;
  } else {
    derivative = v_27;
  };
  self->v_29 = integral;
  self->v_28 = false;
  self->v_26 = proportional;
  self->v = false;;
}

void Linefollower__main_reset(Linefollower__main_mem* self) {
  Linefollower__pid_alpha_reset(&self->pid_alpha);
}

void Linefollower__main_step(int sen0, int sen1, int sen2, int sen3,
                             int sen4, Linefollower__main_out* _out,
                             Linefollower__main_mem* self) {
  Linefollower__pid_alpha_out Linefollower__pid_alpha_out_st;
  
  int sen[5];
  sen[0] = sen0;
  sen[1] = sen1;
  sen[2] = sen2;
  sen[3] = sen3;
  sen[4] = sen4;
  Linefollower__pid_alpha_step(sen, &Linefollower__pid_alpha_out_st,
                               &self->pid_alpha);
  {
    int _2;
    for (_2 = 0; _2 < 5; ++_2) {
      _out->sensor_values[_2] = Linefollower__pid_alpha_out_st.sensor_values[_2];
    }
  };
  _out->on_line = Linefollower__pid_alpha_out_st.on_line;
  _out->avg = Linefollower__pid_alpha_out_st.avg;
  _out->sum = Linefollower__pid_alpha_out_st.sum;
  _out->position_alpha = Linefollower__pid_alpha_out_st.position_alpha;
  _out->power_difference = Linefollower__pid_alpha_out_st.power_difference;
  _out->v_l = Linefollower__pid_alpha_out_st.v_l;
  _out->v_r = Linefollower__pid_alpha_out_st.v_r;;
}

