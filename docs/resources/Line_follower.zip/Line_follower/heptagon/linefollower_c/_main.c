/* --- Generated the 12/3/2023 at 0:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. dec. 28 1:30:47 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts linefollower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "_main.h"

Linefollower__main_mem mem;
int main(int argc, char** argv) {
  int step_c;
  int step_max;
  int sen0;
  int sen1;
  int sen2;
  int sen3;
  int sen4;
  Linefollower__main_out _res;
  step_c = 0;
  step_max = 0;
  if ((argc==2)) {
    step_max = atoi(argv[1]);
  };
  Linefollower__main_reset(&mem);
  while ((!(step_max)||(step_c<step_max))) {
    step_c = (step_c+1);
    
    if ((scanf("%d", &sen0)==EOF)) {
      return 0;
    };;
    
    if ((scanf("%d", &sen1)==EOF)) {
      return 0;
    };;
    
    if ((scanf("%d", &sen2)==EOF)) {
      return 0;
    };;
    
    if ((scanf("%d", &sen3)==EOF)) {
      return 0;
    };;
    
    if ((scanf("%d", &sen4)==EOF)) {
      return 0;
    };;
    Linefollower__main_step(sen0, sen1, sen2, sen3, sen4, &_res, &mem);
    {
      int i;
      for (i = 0; i < 5; ++i) {
        printf("%d\n", _res.sensor_values[i]);
      }
    };
    printf("%d\n", _res.on_line);
    printf("%d\n", _res.avg);
    printf("%d\n", _res.sum);
    printf("%d\n", _res.position_alpha);
    printf("%d\n", _res.power_difference);
    printf("%d\n", _res.v_l);
    printf("%d\n", _res.v_r);
    fflush(stdout);
  };
  return 0;
}

