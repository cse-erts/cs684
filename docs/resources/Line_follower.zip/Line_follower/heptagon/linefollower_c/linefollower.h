/* --- Generated the 12/3/2023 at 0:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. dec. 28 1:30:47 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts linefollower.ept --- */

#ifndef LINEFOLLOWER_H
#define LINEFOLLOWER_H

#include "linefollower_types.h"
typedef struct Linefollower__find_velocities_out {
  int v_l;
  int v_r;
} Linefollower__find_velocities_out;

void Linefollower__find_velocities_step(int power_difference,
                                        Linefollower__find_velocities_out* _out);

typedef struct Linefollower__readcalibrated_out {
  int value_line;
} Linefollower__readcalibrated_out;

void Linefollower__readcalibrated_step(int sensor, int calibratedMax_val,
                                       int calibratedMin_val,
                                       Linefollower__readcalibrated_out* _out);

typedef struct Linefollower__check_online_out {
  int on_line;
} Linefollower__check_online_out;

void Linefollower__check_online_step(int sensor_val, int line_in,
                                     Linefollower__check_online_out* _out);

typedef struct Linefollower__average_out {
  int avg;
} Linefollower__average_out;

void Linefollower__average_step(int sensor_val, int i, int avg_in,
                                Linefollower__average_out* _out);

typedef struct Linefollower__readLine_mem {
  int v_19;
  int v_18;
} Linefollower__readLine_mem;

typedef struct Linefollower__readLine_out {
  int sensor_values[5];
  int on_line;
  int avg;
  int sum;
  int last_value;
} Linefollower__readLine_out;

void Linefollower__readLine_reset(Linefollower__readLine_mem* self);

void Linefollower__readLine_step(int sen[5],
                                 Linefollower__readLine_out* _out,
                                 Linefollower__readLine_mem* self);

typedef struct Linefollower__pid_alpha_mem {
  int v_29;
  int v_28;
  int v_26;
  int v;
  Linefollower__readLine_mem readLine;
} Linefollower__pid_alpha_mem;

typedef struct Linefollower__pid_alpha_out {
  int sensor_values[5];
  int on_line;
  int avg;
  int sum;
  int position_alpha;
  int power_difference;
  int v_l;
  int v_r;
} Linefollower__pid_alpha_out;

void Linefollower__pid_alpha_reset(Linefollower__pid_alpha_mem* self);

void Linefollower__pid_alpha_step(int sen[5],
                                  Linefollower__pid_alpha_out* _out,
                                  Linefollower__pid_alpha_mem* self);

typedef struct Linefollower__main_mem {
  Linefollower__pid_alpha_mem pid_alpha;
} Linefollower__main_mem;

typedef struct Linefollower__main_out {
  int sensor_values[5];
  int on_line;
  int avg;
  int sum;
  int position_alpha;
  int power_difference;
  int v_l;
  int v_r;
} Linefollower__main_out;

void Linefollower__main_reset(Linefollower__main_mem* self);

void Linefollower__main_step(int sen0, int sen1, int sen2, int sen3,
                             int sen4, Linefollower__main_out* _out,
                             Linefollower__main_mem* self);

#endif // LINEFOLLOWER_H
