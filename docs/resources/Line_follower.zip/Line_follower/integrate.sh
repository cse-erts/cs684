#!/usr/bin/env bash
cd "heptagon/"
(simulate.sh -s main -p linefollower.ept -k 1) 

cd ".."

dest_src=$pwd."/supervisor"
src=$pwd."/heptagon/linefollower_c"
cp "$src/linefollower_types.c" "$dest_src/linefollower_types.cpp"
cp "$src/linefollower_types.h" "$dest_src/linefollower_types.h"
cp "$src/linefollower.c" "$dest_src/linefollower.cpp"
cp "$src/linefollower.h" "$dest_src/linefollower.h"
sed -i 's/int/long/g' "$dest_src/linefollower.cpp"
sed -i 's/int/long/g' "$dest_src/linefollower.h"
sed -i 's/int/long/g' "$dest_src/linefollower_types.h"
# sed --in-place '/pervasives.h/d' "$dest_src/linefollower_types.h"

