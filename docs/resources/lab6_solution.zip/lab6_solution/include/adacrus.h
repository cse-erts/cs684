#ifdef __cplusplus
extern "C" {
#endif

/* --- Generated the 28/3/2021 at 17:32 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_H
#define ADACRUS_H

#include "adacrus_types.h"
typedef struct Adacrus__isInverted_mem {
  int v_22;
  int v_16;
  int v_14;
  int v_12;
  int v_8;
  int v_4;
  int v_1;
  int v;
} Adacrus__isInverted_mem;

typedef struct Adacrus__isInverted_out {
  int out;
} Adacrus__isInverted_out;

void Adacrus__isInverted_reset(Adacrus__isInverted_mem* self);

void Adacrus__isInverted_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__isInverted_out* _out,
                              Adacrus__isInverted_mem* self);

typedef struct Adacrus__isNode_mem {
  int v_33;
  int v_32;
} Adacrus__isNode_mem;

typedef struct Adacrus__isNode_out {
  int out;
} Adacrus__isNode_out;

void Adacrus__isNode_reset(Adacrus__isNode_mem* self);

void Adacrus__isNode_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isNode_out* _out,
                          Adacrus__isNode_mem* self);

typedef struct Adacrus__notIsNode_out {
  int out;
} Adacrus__notIsNode_out;

void Adacrus__notIsNode_step(int left_wl, int center_wl, int right_wl,
                             Adacrus__notIsNode_out* _out);

typedef struct Adacrus__isAllWhite_mem {
  int v_63;
  int v_62;
} Adacrus__isAllWhite_mem;

typedef struct Adacrus__isAllWhite_out {
  int out;
} Adacrus__isAllWhite_out;

void Adacrus__isAllWhite_reset(Adacrus__isAllWhite_mem* self);

void Adacrus__isAllWhite_step(int left_wl, int center_wl, int right_wl,
                              int t, Adacrus__isAllWhite_out* _out,
                              Adacrus__isAllWhite_mem* self);

typedef struct Adacrus__isLine_mem {
  int v_71;
  int v;
} Adacrus__isLine_mem;

typedef struct Adacrus__isLine_out {
  int out;
} Adacrus__isLine_out;

void Adacrus__isLine_reset(Adacrus__isLine_mem* self);

void Adacrus__isLine_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isLine_out* _out,
                          Adacrus__isLine_mem* self);

typedef struct Adacrus__halt_out {
  int v_l;
  int v_r;
  Adacrus__direction dir;
} Adacrus__halt_out;

void Adacrus__halt_step(Adacrus__halt_out* _out);

typedef struct Adacrus__determineLineLoc_out {
  Adacrus__lineloc l;
} Adacrus__determineLineLoc_out;

void Adacrus__determineLineLoc_step(int left_wl, int center_wl, int right_wl,
                                    Adacrus__determineLineLoc_out* _out);

typedef struct Adacrus__determineLineLocInverted_out {
  Adacrus__lineloc l;
} Adacrus__determineLineLocInverted_out;

void Adacrus__determineLineLocInverted_step(int left_wl, int center_wl,
                                            int right_wl,
                                            Adacrus__determineLineLocInverted_out* _out);

typedef struct Adacrus__moveAut_mem {
  int v_156;
  int v_152;
  int v_163;
  int v_159;
  Adacrus__st v_166;
  int v_172;
  int v_170;
  int v_168;
  int v_178;
  int v_175;
  Adacrus__st_1 v_180;
  int v_181;
  Adacrus__st_2 ck;
  int pnr_2;
  Adacrus__lineloc past_ll_6;
  Adacrus__isLine_mem isLine;
  Adacrus__isAllWhite_mem isAllWhite;
} Adacrus__moveAut_mem;

typedef struct Adacrus__moveAut_out {
  int v_l;
  int v_r;
} Adacrus__moveAut_out;

void Adacrus__moveAut_reset(Adacrus__moveAut_mem* self);

void Adacrus__moveAut_step(int left_wl, int center_wl, int right_wl,
                           int curve, int inverted, int zigzagt, int zigzagb,
                           Adacrus__moveAut_out* _out,
                           Adacrus__moveAut_mem* self);

typedef struct Adacrus__move_mem {
  Adacrus__st_4 ck;
  int v_308;
  int v_306;
  int v_303;
  int v_301;
  Adacrus__st_3 ck_3;
  int v_297;
  int v_294;
  int v_258;
  int v_257;
  int v_256;
  int pnr_3;
  int pnr;
  int zz_1;
  Adacrus__lineloc past_ll_7;
  Adacrus__isLine_mem isLine;
  Adacrus__isInverted_mem isInverted;
  Adacrus__isAllWhite_mem isAllWhite;
  Adacrus__isLine_mem isLine_1;
  Adacrus__isAllWhite_mem isAllWhite_1;
} Adacrus__move_mem;

typedef struct Adacrus__move_out {
  int v_l;
  int v_r;
} Adacrus__move_out;

void Adacrus__move_reset(Adacrus__move_mem* self);

void Adacrus__move_step(int left_wl, int center_wl, int right_wl, int curve,
                        int inverted, int zigzagt, int zigzagb,
                        Adacrus__move_out* _out, Adacrus__move_mem* self);

typedef struct Adacrus__calcOrientation_out {
  Adacrus__orientation new_orientation;
} Adacrus__calcOrientation_out;

void Adacrus__calcOrientation_step(Adacrus__states current_state,
                                   Adacrus__orientation last_oriented,
                                   Adacrus__calcOrientation_out* _out);

typedef struct Adacrus__getNextNodeAndState_mem {
  int v_516;
  int v_515;
  int v_506;
  int v_505;
  int v_496;
  int v_495;
  int v_486;
  int v_485;
  int v_471;
  int v_470;
  int v_387;
  int v_386;
} Adacrus__getNextNodeAndState_mem;

typedef struct Adacrus__getNextNodeAndState_out {
  Adacrus__coordinates next_node;
  Adacrus__states next_state;
} Adacrus__getNextNodeAndState_out;

void Adacrus__getNextNodeAndState_reset(Adacrus__getNextNodeAndState_mem* self);

void Adacrus__getNextNodeAndState_step(Adacrus__coordinates current_node,
                                       Adacrus__coordinates goal_node,
                                       Adacrus__orientation oriented,
                                       int ir_prox,
                                       Adacrus__getNextNodeAndState_out* _out,
                                       Adacrus__getNextNodeAndState_mem* self);

typedef struct Adacrus__decideAction_mem {
  int v_535;
  int v_530;
  int v_529;
  Adacrus__getNextNodeAndState_mem getNextNodeAndState;
  Adacrus__getNextNodeAndState_mem getNextNodeAndState_1;
} Adacrus__decideAction_mem;

typedef struct Adacrus__decideAction_out {
  Adacrus__coordinates next_node;
  Adacrus__states next_state;
} Adacrus__decideAction_out;

void Adacrus__decideAction_reset(Adacrus__decideAction_mem* self);

void Adacrus__decideAction_step(Adacrus__coordinates current_node,
                                Adacrus__states last_state,
                                Adacrus__orientation oriented, int ir_prox,
                                Adacrus__decideAction_out* _out,
                                Adacrus__decideAction_mem* self);

typedef struct Adacrus__adacrus_params_35__mem {
  int v_549;
  int v_546;
  int v_557;
  int v_554;
  int v_563;
  int v_560;
  Adacrus__st_8 v_565;
  int v_567;
  int v_566;
  int v_574;
  int v_571;
  int v_580;
  int v_577;
  int v_586;
  int v_583;
  Adacrus__st_7 v_588;
  int v_590;
  int v_589;
  int v_597;
  int v_594;
  int v_603;
  int v_600;
  int v_609;
  int v_606;
  Adacrus__st_6 v_611;
  int v_613;
  int v_612;
  Adacrus__st_5 v_632;
  int v_634;
  int v_633;
  Adacrus__states next_state_4;
  int v_643;
  int v_641;
  Adacrus__st_9 ck;
  int pnr_7;
  Adacrus__states debug_state_1;
  Adacrus__states current_state_2;
  Adacrus__orientation oriented_4;
  Adacrus__coordinates next_node_5;
  Adacrus__decideAction_mem decideAction;
  Adacrus__isLine_mem isLine;
  Adacrus__isLine_mem isLine_2;
  Adacrus__isLine_mem isLine_3;
  Adacrus__isAllWhite_mem isAllWhite;
  Adacrus__isLine_mem isLine_4;
  Adacrus__isAllWhite_mem isAllWhite_2;
  Adacrus__moveAut_mem moveAut;
  Adacrus__moveAut_mem moveAut_4;
  Adacrus__moveAut_mem moveAut_3;
  Adacrus__moveAut_mem moveAut_2;
  Adacrus__moveAut_mem moveAut_1;
  Adacrus__isNode_mem isNode;
  Adacrus__moveAut_mem moveAut_5;
} Adacrus__adacrus_params_35__mem;

typedef struct Adacrus__adacrus_params_35__out {
  int v_l;
  int v_r;
  Adacrus__orientation o;
  Adacrus__direction dir;
  Adacrus__states s;
  Adacrus__states d_s;
  Adacrus__coordinates nnode;
} Adacrus__adacrus_params_35__out;

void Adacrus__adacrus_params_35__reset(Adacrus__adacrus_params_35__mem* self);

void Adacrus__adacrus_params_35__step(int left_wl, int center_wl,
                                      int right_wl, int ir_prox,
                                      Adacrus__adacrus_params_35__out* _out,
                                      Adacrus__adacrus_params_35__mem* self);

typedef struct Adacrus__main_mem {
  Adacrus__adacrus_params_35__mem adacrus;
} Adacrus__main_mem;

typedef struct Adacrus__main_out {
  int v_l;
  int v_r;
  Adacrus__orientation o;
  Adacrus__direction dir;
  Adacrus__states s;
  Adacrus__states d_s;
  Adacrus__coordinates next_node;
} Adacrus__main_out;

void Adacrus__main_reset(Adacrus__main_mem* self);

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self);

#endif // ADACRUS_H

#ifdef __cplusplus
}
#endif
