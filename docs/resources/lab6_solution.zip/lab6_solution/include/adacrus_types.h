/* --- Generated the 28/3/2021 at 17:32 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_TYPES_H
#define ADACRUS_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Adacrus__St_9_RotR,
  Adacrus__St_9_RotL,
  Adacrus__St_9_Rot180,
  Adacrus__St_9_Moving,
  Adacrus__St_9_Initial,
  Adacrus__St_9_Exit,
  Adacrus__St_9_DecideAction
} Adacrus__st_9;

Adacrus__st_9 Adacrus__st_9_of_string(char* s);

char* string_of_Adacrus__st_9(Adacrus__st_9 x, char* buf);

typedef enum {
  Adacrus__St_8_TurnRightAgain,
  Adacrus__St_8_TurnRight,
  Adacrus__St_8_GoAhead,
  Adacrus__St_8_Exit
} Adacrus__st_8;

Adacrus__st_8 Adacrus__st_8_of_string(char* s);

char* string_of_Adacrus__st_8(Adacrus__st_8 x, char* buf);

typedef enum {
  Adacrus__St_7_TurnRight,
  Adacrus__St_7_GoAhead,
  Adacrus__St_7_Exit,
  Adacrus__St_7_BlackToWhite
} Adacrus__st_7;

Adacrus__st_7 Adacrus__st_7_of_string(char* s);

char* string_of_Adacrus__st_7(Adacrus__st_7 x, char* buf);

typedef enum {
  Adacrus__St_6_TurnLeft,
  Adacrus__St_6_GoAhead,
  Adacrus__St_6_Exit,
  Adacrus__St_6_BlackToWhite
} Adacrus__st_6;

Adacrus__st_6 Adacrus__st_6_of_string(char* s);

char* string_of_Adacrus__st_6(Adacrus__st_6 x, char* buf);

typedef enum {
  Adacrus__St_5_LeaveNode,
  Adacrus__St_5_Decidado
} Adacrus__st_5;

Adacrus__st_5 Adacrus__st_5_of_string(char* s);

char* string_of_Adacrus__st_5(Adacrus__st_5 x, char* buf);

typedef enum {
  Adacrus__St_4_Inv,
  Adacrus__St_4_In
} Adacrus__st_4;

Adacrus__st_4 Adacrus__st_4_of_string(char* s);

char* string_of_Adacrus__st_4(Adacrus__st_4 x, char* buf);

typedef enum {
  Adacrus__St_3_ZigToZag,
  Adacrus__St_3_MaintainWhite,
  Adacrus__St_3_MaintainBlack,
  Adacrus__St_3_In
} Adacrus__st_3;

Adacrus__st_3 Adacrus__st_3_of_string(char* s);

char* string_of_Adacrus__st_3(Adacrus__st_3 x, char* buf);

typedef enum {
  Adacrus__St_2_MoveZigZag,
  Adacrus__St_2_LookBack,
  Adacrus__St_2_Basic
} Adacrus__st_2;

Adacrus__st_2 Adacrus__st_2_of_string(char* s);

char* string_of_Adacrus__st_2(Adacrus__st_2 x, char* buf);

typedef enum {
  Adacrus__St_1_ZigOrZag,
  Adacrus__St_1_Uncertain
} Adacrus__st_1;

Adacrus__st_1 Adacrus__st_1_of_string(char* s);

char* string_of_Adacrus__st_1(Adacrus__st_1 x, char* buf);

typedef enum {
  Adacrus__St_UpdateDir,
  Adacrus__St_Scan,
  Adacrus__St_Initial
} Adacrus__st;

Adacrus__st Adacrus__st_of_string(char* s);

char* string_of_Adacrus__st(Adacrus__st x, char* buf);

typedef enum {
  Adacrus__Initial,
  Adacrus__Moving,
  Adacrus__RotL,
  Adacrus__RotR,
  Adacrus__Rot180,
  Adacrus__AtNode,
  Adacrus__Exit,
  Adacrus__GoAhead,
  Adacrus__TurnRight,
  Adacrus__TurnLeft,
  Adacrus__DecideAction,
  Adacrus__Decidado,
  Adacrus__LeaveNode,
  Adacrus__BlackToWhite,
  Adacrus__CenterAlign
} Adacrus__states;

Adacrus__states Adacrus__states_of_string(char* s);

char* string_of_Adacrus__states(Adacrus__states x, char* buf);

typedef enum {
  Adacrus__Forward,
  Adacrus__Left,
  Adacrus__Right,
  Adacrus__Stop
} Adacrus__direction;

Adacrus__direction Adacrus__direction_of_string(char* s);

char* string_of_Adacrus__direction(Adacrus__direction x, char* buf);

typedef enum {
  Adacrus__T,
  Adacrus__B,
  Adacrus__L,
  Adacrus__R
} Adacrus__orientation;

Adacrus__orientation Adacrus__orientation_of_string(char* s);

char* string_of_Adacrus__orientation(Adacrus__orientation x, char* buf);

typedef enum {
  Adacrus__OnLine,
  Adacrus__LOLeft,
  Adacrus__LOTooLeft,
  Adacrus__LORight,
  Adacrus__LOTooRight,
  Adacrus__Node,
  Adacrus__NoLine,
  Adacrus__Undef
} Adacrus__lineloc;

Adacrus__lineloc Adacrus__lineloc_of_string(char* s);

char* string_of_Adacrus__lineloc(Adacrus__lineloc x, char* buf);

typedef struct Adacrus__coordinates {
  int x;
  int y;
} Adacrus__coordinates;

typedef enum {
  Adacrus__Basic,
  Adacrus__ZigZag
} Adacrus__moving;

Adacrus__moving Adacrus__moving_of_string(char* s);

char* string_of_Adacrus__moving(Adacrus__moving x, char* buf);

static const Adacrus__coordinates Adacrus__start = {3, 1};

static const Adacrus__coordinates Adacrus__goal = {3, 6};

static const int Adacrus__node_steps = 45;

#endif // ADACRUS_TYPES_H
