#!/usr/bin/env bash
set -e

MIN=0
MAX=256
PROG="isnode"
# number of test cases
N=$1
TST=$2
if [[ ! -n $N ]]
then
  echo "No. of test cases not set!";
  exit 1 ;
fi
if [[ ! -n $TST ]] ;
then
  echo "Test script path not set!";
  exit 1 ;
fi

in_file="./test/in_$PROG.txt"
out_file="./test/out_$PROG.txt"

if [[ -e $in_file ]] ; then rm $in_file ; fi
if [[ -e $out_file ]] ; then rm $out_file ; fi

for (( c=1 ; c <= "$N" ; c++ ))
do
  left=$(( ( RANDOM % $MAX ) + $MIN ))
  right=$(( ( RANDOM % $MAX ) + $MIN ))
  center=$(( ( RANDOM % $MAX ) + $MIN ))
  printf "%d %d %d\n" $left $center $right >> $in_file
  if [[ $left -gt 200 && $center -gt 200 && $right -gt 200 ]]
  then
    printf "1\n" >> $out_file
  else
    printf "0\n" >> $out_file
  fi
done

script_files="/home/kirito/Documents/CS684-2021/Autoeval-ass3"
#declare -A output
output=( $("$script_files/betterdiff.py" "$out_file" <(simulate.sh -s isnode -p "$TST" -c 1 < "$in_file" | tail -n +2)) )
#echo ${#output[@]}
#echo "$((${output[@]}))"
sum=$(IFS=+; echo "$((${output[*]:1}))")
echo $sum
if [[ $sum -eq ${output[0]} ]] ; then echo "Hurray!"; else echo ":/"; fi
