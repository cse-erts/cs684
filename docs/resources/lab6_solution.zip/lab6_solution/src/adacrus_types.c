/* --- Generated the 28/3/2021 at 17:32 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "adacrus_types.h"

Adacrus__st_9 Adacrus__st_9_of_string(char* s) {
  if ((strcmp(s, "St_9_RotR")==0)) {
    return Adacrus__St_9_RotR;
  };
  if ((strcmp(s, "St_9_RotL")==0)) {
    return Adacrus__St_9_RotL;
  };
  if ((strcmp(s, "St_9_Rot180")==0)) {
    return Adacrus__St_9_Rot180;
  };
  if ((strcmp(s, "St_9_Moving")==0)) {
    return Adacrus__St_9_Moving;
  };
  if ((strcmp(s, "St_9_Initial")==0)) {
    return Adacrus__St_9_Initial;
  };
  if ((strcmp(s, "St_9_Exit")==0)) {
    return Adacrus__St_9_Exit;
  };
  if ((strcmp(s, "St_9_DecideAction")==0)) {
    return Adacrus__St_9_DecideAction;
  };
}

char* string_of_Adacrus__st_9(Adacrus__st_9 x, char* buf) {
  switch (x) {
    case Adacrus__St_9_RotR:
      strcpy(buf, "St_9_RotR");
      break;
    case Adacrus__St_9_RotL:
      strcpy(buf, "St_9_RotL");
      break;
    case Adacrus__St_9_Rot180:
      strcpy(buf, "St_9_Rot180");
      break;
    case Adacrus__St_9_Moving:
      strcpy(buf, "St_9_Moving");
      break;
    case Adacrus__St_9_Initial:
      strcpy(buf, "St_9_Initial");
      break;
    case Adacrus__St_9_Exit:
      strcpy(buf, "St_9_Exit");
      break;
    case Adacrus__St_9_DecideAction:
      strcpy(buf, "St_9_DecideAction");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_8 Adacrus__st_8_of_string(char* s) {
  if ((strcmp(s, "St_8_TurnRightAgain")==0)) {
    return Adacrus__St_8_TurnRightAgain;
  };
  if ((strcmp(s, "St_8_TurnRight")==0)) {
    return Adacrus__St_8_TurnRight;
  };
  if ((strcmp(s, "St_8_GoAhead")==0)) {
    return Adacrus__St_8_GoAhead;
  };
  if ((strcmp(s, "St_8_Exit")==0)) {
    return Adacrus__St_8_Exit;
  };
}

char* string_of_Adacrus__st_8(Adacrus__st_8 x, char* buf) {
  switch (x) {
    case Adacrus__St_8_TurnRightAgain:
      strcpy(buf, "St_8_TurnRightAgain");
      break;
    case Adacrus__St_8_TurnRight:
      strcpy(buf, "St_8_TurnRight");
      break;
    case Adacrus__St_8_GoAhead:
      strcpy(buf, "St_8_GoAhead");
      break;
    case Adacrus__St_8_Exit:
      strcpy(buf, "St_8_Exit");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_7 Adacrus__st_7_of_string(char* s) {
  if ((strcmp(s, "St_7_TurnRight")==0)) {
    return Adacrus__St_7_TurnRight;
  };
  if ((strcmp(s, "St_7_GoAhead")==0)) {
    return Adacrus__St_7_GoAhead;
  };
  if ((strcmp(s, "St_7_Exit")==0)) {
    return Adacrus__St_7_Exit;
  };
  if ((strcmp(s, "St_7_BlackToWhite")==0)) {
    return Adacrus__St_7_BlackToWhite;
  };
}

char* string_of_Adacrus__st_7(Adacrus__st_7 x, char* buf) {
  switch (x) {
    case Adacrus__St_7_TurnRight:
      strcpy(buf, "St_7_TurnRight");
      break;
    case Adacrus__St_7_GoAhead:
      strcpy(buf, "St_7_GoAhead");
      break;
    case Adacrus__St_7_Exit:
      strcpy(buf, "St_7_Exit");
      break;
    case Adacrus__St_7_BlackToWhite:
      strcpy(buf, "St_7_BlackToWhite");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_6 Adacrus__st_6_of_string(char* s) {
  if ((strcmp(s, "St_6_TurnLeft")==0)) {
    return Adacrus__St_6_TurnLeft;
  };
  if ((strcmp(s, "St_6_GoAhead")==0)) {
    return Adacrus__St_6_GoAhead;
  };
  if ((strcmp(s, "St_6_Exit")==0)) {
    return Adacrus__St_6_Exit;
  };
  if ((strcmp(s, "St_6_BlackToWhite")==0)) {
    return Adacrus__St_6_BlackToWhite;
  };
}

char* string_of_Adacrus__st_6(Adacrus__st_6 x, char* buf) {
  switch (x) {
    case Adacrus__St_6_TurnLeft:
      strcpy(buf, "St_6_TurnLeft");
      break;
    case Adacrus__St_6_GoAhead:
      strcpy(buf, "St_6_GoAhead");
      break;
    case Adacrus__St_6_Exit:
      strcpy(buf, "St_6_Exit");
      break;
    case Adacrus__St_6_BlackToWhite:
      strcpy(buf, "St_6_BlackToWhite");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_5 Adacrus__st_5_of_string(char* s) {
  if ((strcmp(s, "St_5_LeaveNode")==0)) {
    return Adacrus__St_5_LeaveNode;
  };
  if ((strcmp(s, "St_5_Decidado")==0)) {
    return Adacrus__St_5_Decidado;
  };
}

char* string_of_Adacrus__st_5(Adacrus__st_5 x, char* buf) {
  switch (x) {
    case Adacrus__St_5_LeaveNode:
      strcpy(buf, "St_5_LeaveNode");
      break;
    case Adacrus__St_5_Decidado:
      strcpy(buf, "St_5_Decidado");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_4 Adacrus__st_4_of_string(char* s) {
  if ((strcmp(s, "St_4_Inv")==0)) {
    return Adacrus__St_4_Inv;
  };
  if ((strcmp(s, "St_4_In")==0)) {
    return Adacrus__St_4_In;
  };
}

char* string_of_Adacrus__st_4(Adacrus__st_4 x, char* buf) {
  switch (x) {
    case Adacrus__St_4_Inv:
      strcpy(buf, "St_4_Inv");
      break;
    case Adacrus__St_4_In:
      strcpy(buf, "St_4_In");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_3 Adacrus__st_3_of_string(char* s) {
  if ((strcmp(s, "St_3_ZigToZag")==0)) {
    return Adacrus__St_3_ZigToZag;
  };
  if ((strcmp(s, "St_3_MaintainWhite")==0)) {
    return Adacrus__St_3_MaintainWhite;
  };
  if ((strcmp(s, "St_3_MaintainBlack")==0)) {
    return Adacrus__St_3_MaintainBlack;
  };
  if ((strcmp(s, "St_3_In")==0)) {
    return Adacrus__St_3_In;
  };
}

char* string_of_Adacrus__st_3(Adacrus__st_3 x, char* buf) {
  switch (x) {
    case Adacrus__St_3_ZigToZag:
      strcpy(buf, "St_3_ZigToZag");
      break;
    case Adacrus__St_3_MaintainWhite:
      strcpy(buf, "St_3_MaintainWhite");
      break;
    case Adacrus__St_3_MaintainBlack:
      strcpy(buf, "St_3_MaintainBlack");
      break;
    case Adacrus__St_3_In:
      strcpy(buf, "St_3_In");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_2 Adacrus__st_2_of_string(char* s) {
  if ((strcmp(s, "St_2_MoveZigZag")==0)) {
    return Adacrus__St_2_MoveZigZag;
  };
  if ((strcmp(s, "St_2_LookBack")==0)) {
    return Adacrus__St_2_LookBack;
  };
  if ((strcmp(s, "St_2_Basic")==0)) {
    return Adacrus__St_2_Basic;
  };
}

char* string_of_Adacrus__st_2(Adacrus__st_2 x, char* buf) {
  switch (x) {
    case Adacrus__St_2_MoveZigZag:
      strcpy(buf, "St_2_MoveZigZag");
      break;
    case Adacrus__St_2_LookBack:
      strcpy(buf, "St_2_LookBack");
      break;
    case Adacrus__St_2_Basic:
      strcpy(buf, "St_2_Basic");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_1 Adacrus__st_1_of_string(char* s) {
  if ((strcmp(s, "St_1_ZigOrZag")==0)) {
    return Adacrus__St_1_ZigOrZag;
  };
  if ((strcmp(s, "St_1_Uncertain")==0)) {
    return Adacrus__St_1_Uncertain;
  };
}

char* string_of_Adacrus__st_1(Adacrus__st_1 x, char* buf) {
  switch (x) {
    case Adacrus__St_1_ZigOrZag:
      strcpy(buf, "St_1_ZigOrZag");
      break;
    case Adacrus__St_1_Uncertain:
      strcpy(buf, "St_1_Uncertain");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st Adacrus__st_of_string(char* s) {
  if ((strcmp(s, "St_UpdateDir")==0)) {
    return Adacrus__St_UpdateDir;
  };
  if ((strcmp(s, "St_Scan")==0)) {
    return Adacrus__St_Scan;
  };
  if ((strcmp(s, "St_Initial")==0)) {
    return Adacrus__St_Initial;
  };
}

char* string_of_Adacrus__st(Adacrus__st x, char* buf) {
  switch (x) {
    case Adacrus__St_UpdateDir:
      strcpy(buf, "St_UpdateDir");
      break;
    case Adacrus__St_Scan:
      strcpy(buf, "St_Scan");
      break;
    case Adacrus__St_Initial:
      strcpy(buf, "St_Initial");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__states Adacrus__states_of_string(char* s) {
  if ((strcmp(s, "Initial")==0)) {
    return Adacrus__Initial;
  };
  if ((strcmp(s, "Moving")==0)) {
    return Adacrus__Moving;
  };
  if ((strcmp(s, "RotL")==0)) {
    return Adacrus__RotL;
  };
  if ((strcmp(s, "RotR")==0)) {
    return Adacrus__RotR;
  };
  if ((strcmp(s, "Rot180")==0)) {
    return Adacrus__Rot180;
  };
  if ((strcmp(s, "AtNode")==0)) {
    return Adacrus__AtNode;
  };
  if ((strcmp(s, "Exit")==0)) {
    return Adacrus__Exit;
  };
  if ((strcmp(s, "GoAhead")==0)) {
    return Adacrus__GoAhead;
  };
  if ((strcmp(s, "TurnRight")==0)) {
    return Adacrus__TurnRight;
  };
  if ((strcmp(s, "TurnLeft")==0)) {
    return Adacrus__TurnLeft;
  };
  if ((strcmp(s, "DecideAction")==0)) {
    return Adacrus__DecideAction;
  };
  if ((strcmp(s, "Decidado")==0)) {
    return Adacrus__Decidado;
  };
  if ((strcmp(s, "LeaveNode")==0)) {
    return Adacrus__LeaveNode;
  };
  if ((strcmp(s, "BlackToWhite")==0)) {
    return Adacrus__BlackToWhite;
  };
  if ((strcmp(s, "CenterAlign")==0)) {
    return Adacrus__CenterAlign;
  };
}

char* string_of_Adacrus__states(Adacrus__states x, char* buf) {
  switch (x) {
    case Adacrus__Initial:
      strcpy(buf, "Initial");
      break;
    case Adacrus__Moving:
      strcpy(buf, "Moving");
      break;
    case Adacrus__RotL:
      strcpy(buf, "RotL");
      break;
    case Adacrus__RotR:
      strcpy(buf, "RotR");
      break;
    case Adacrus__Rot180:
      strcpy(buf, "Rot180");
      break;
    case Adacrus__AtNode:
      strcpy(buf, "AtNode");
      break;
    case Adacrus__Exit:
      strcpy(buf, "Exit");
      break;
    case Adacrus__GoAhead:
      strcpy(buf, "GoAhead");
      break;
    case Adacrus__TurnRight:
      strcpy(buf, "TurnRight");
      break;
    case Adacrus__TurnLeft:
      strcpy(buf, "TurnLeft");
      break;
    case Adacrus__DecideAction:
      strcpy(buf, "DecideAction");
      break;
    case Adacrus__Decidado:
      strcpy(buf, "Decidado");
      break;
    case Adacrus__LeaveNode:
      strcpy(buf, "LeaveNode");
      break;
    case Adacrus__BlackToWhite:
      strcpy(buf, "BlackToWhite");
      break;
    case Adacrus__CenterAlign:
      strcpy(buf, "CenterAlign");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__direction Adacrus__direction_of_string(char* s) {
  if ((strcmp(s, "Forward")==0)) {
    return Adacrus__Forward;
  };
  if ((strcmp(s, "Left")==0)) {
    return Adacrus__Left;
  };
  if ((strcmp(s, "Right")==0)) {
    return Adacrus__Right;
  };
  if ((strcmp(s, "Stop")==0)) {
    return Adacrus__Stop;
  };
}

char* string_of_Adacrus__direction(Adacrus__direction x, char* buf) {
  switch (x) {
    case Adacrus__Forward:
      strcpy(buf, "Forward");
      break;
    case Adacrus__Left:
      strcpy(buf, "Left");
      break;
    case Adacrus__Right:
      strcpy(buf, "Right");
      break;
    case Adacrus__Stop:
      strcpy(buf, "Stop");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__orientation Adacrus__orientation_of_string(char* s) {
  if ((strcmp(s, "T")==0)) {
    return Adacrus__T;
  };
  if ((strcmp(s, "B")==0)) {
    return Adacrus__B;
  };
  if ((strcmp(s, "L")==0)) {
    return Adacrus__L;
  };
  if ((strcmp(s, "R")==0)) {
    return Adacrus__R;
  };
}

char* string_of_Adacrus__orientation(Adacrus__orientation x, char* buf) {
  switch (x) {
    case Adacrus__T:
      strcpy(buf, "T");
      break;
    case Adacrus__B:
      strcpy(buf, "B");
      break;
    case Adacrus__L:
      strcpy(buf, "L");
      break;
    case Adacrus__R:
      strcpy(buf, "R");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__lineloc Adacrus__lineloc_of_string(char* s) {
  if ((strcmp(s, "OnLine")==0)) {
    return Adacrus__OnLine;
  };
  if ((strcmp(s, "LOLeft")==0)) {
    return Adacrus__LOLeft;
  };
  if ((strcmp(s, "LOTooLeft")==0)) {
    return Adacrus__LOTooLeft;
  };
  if ((strcmp(s, "LORight")==0)) {
    return Adacrus__LORight;
  };
  if ((strcmp(s, "LOTooRight")==0)) {
    return Adacrus__LOTooRight;
  };
  if ((strcmp(s, "Node")==0)) {
    return Adacrus__Node;
  };
  if ((strcmp(s, "NoLine")==0)) {
    return Adacrus__NoLine;
  };
  if ((strcmp(s, "Undef")==0)) {
    return Adacrus__Undef;
  };
}

char* string_of_Adacrus__lineloc(Adacrus__lineloc x, char* buf) {
  switch (x) {
    case Adacrus__OnLine:
      strcpy(buf, "OnLine");
      break;
    case Adacrus__LOLeft:
      strcpy(buf, "LOLeft");
      break;
    case Adacrus__LOTooLeft:
      strcpy(buf, "LOTooLeft");
      break;
    case Adacrus__LORight:
      strcpy(buf, "LORight");
      break;
    case Adacrus__LOTooRight:
      strcpy(buf, "LOTooRight");
      break;
    case Adacrus__Node:
      strcpy(buf, "Node");
      break;
    case Adacrus__NoLine:
      strcpy(buf, "NoLine");
      break;
    case Adacrus__Undef:
      strcpy(buf, "Undef");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__moving Adacrus__moving_of_string(char* s) {
  if ((strcmp(s, "Basic")==0)) {
    return Adacrus__Basic;
  };
  if ((strcmp(s, "ZigZag")==0)) {
    return Adacrus__ZigZag;
  };
}

char* string_of_Adacrus__moving(Adacrus__moving x, char* buf) {
  switch (x) {
    case Adacrus__Basic:
      strcpy(buf, "Basic");
      break;
    case Adacrus__ZigZag:
      strcpy(buf, "ZigZag");
      break;
    default:
      break;
  };
  return buf;
}

