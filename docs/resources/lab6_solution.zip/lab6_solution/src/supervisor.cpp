#include "eBot_Sim_Predef.h"
#include "adacrus.h"
#define uc unsigned char

using namespace std;

Adacrus__main_mem mem;

/**
 * @brief      Executes the logic to achieve the aim of Lab 4
 */
void improved_velocity(int left_vel, int right_vel) {
    right_vel = right_vel > 255 ? 255 : right_vel;
    right_vel = right_vel < -255 ? -255 : right_vel;
    left_vel = left_vel > 255 ? 255 : left_vel;
    left_vel = left_vel < -255 ? -255 : left_vel;
    if (left_vel >= 0 && right_vel >= 0) {
        forward();
        velocity(left_vel, right_vel);
    } else if (left_vel < 0 && right_vel >= 0) {
        left();
        velocity(-left_vel, right_vel);
    } else if (left_vel >= 0 && right_vel < 0) {
        right();
        velocity(left_vel, -right_vel);
    } else
        stop();
}


void traverse_line_to_goal() {
    uc left_wl_reading = 0, right_wl_reading = 0, center_wl_reading = 0, fr_proximity_reading = 0;
    uc past_left_wl_reading, past_right_wl_reading, past_center_wl_reading, past_fr_proximity_reading;
    Adacrus__main_out _res;
    Adacrus__main_reset(&mem);
    Adacrus__states last_state = Adacrus__Exit;
    char buf_1[20], buf_2[20], buf_3[20], buf_4[20];
    while (true) {
        past_center_wl_reading = center_wl_reading;
        past_left_wl_reading = left_wl_reading;
        past_right_wl_reading = right_wl_reading;
        past_fr_proximity_reading = fr_proximity_reading;
        // read sensor values
        left_wl_reading = convert_analog_channel_data( left_wl_sensor_channel );
        center_wl_reading = convert_analog_channel_data( center_wl_sensor_channel );
        right_wl_reading = convert_analog_channel_data( right_wl_sensor_channel );
        fr_proximity_reading = convert_analog_channel_data( ir_prox_5_sensor_channel );
        cout<<+left_wl_reading<<" "<<+center_wl_reading<<" "<<+right_wl_reading<<" "<<+fr_proximity_reading<<endl;
        // step - generate velocity outputs for the wheels
        Adacrus__main_step(left_wl_reading, center_wl_reading, right_wl_reading, fr_proximity_reading,
                           &_res, &mem);
        // perform actuation with outputs
        //if (_res.d_s != last_state) {
            //if (!(left_wl_reading == past_left_wl_reading && center_wl_reading == past_center_wl_reading &&
            //      right_wl_reading == past_right_wl_reading)) {

            //}
            cout<<"Next Node ("<<_res.next_node.x<<", "<<_res.next_node.y<<")"<<endl;
            cout<<_res.v_l<<" "<<_res.v_r<<" "<<string_of_Adacrus__direction(_res.dir, buf_1)<<" "
                <<string_of_Adacrus__states(_res.s, buf_2)<<" "<<string_of_Adacrus__states(_res.d_s, buf_3)
                <<" "<<string_of_Adacrus__orientation(_res.o, buf_4)<<endl;
            last_state = _res.d_s;
        //}
        forward();
        if (_res.s == Adacrus__Exit)
            break;
        //if (_res.dir == Adacrus__Left)
        //    left();
        //else if (_res.dir == Adacrus__Right)
        //    right();
        //else if (_res.dir == Adacrus__Stop)
        //    stop();
        improved_velocity(_res.v_l, _res.v_r);
        //velocity(_res.v_l, _res.v_r);
        _delay_ms(5);
        improved_velocity(0, 0);
        cout<<"----"<<endl;
    }
}
