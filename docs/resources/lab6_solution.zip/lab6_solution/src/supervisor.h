//
// Created by kirito on 08/03/21.
//

#ifndef LAB6_LINE_FOLLOWER_ROBOT_SUPERVISOR_H
#define LAB6_LINE_FOLLOWER_ROBOT_SUPERVISOR_H

#ifdef NON_MATLAB_PARSING
#include "eBot_Sim_Predef.h"
#else
extern "C" {
		#include "eBot_MCU_Predef.h"
	}
#endif

#endif //LAB6_LINE_FOLLOWER_ROBOT_SUPERVISOR_H
void traverse_line_to_goal();
