/* --- Generated the 28/3/2021 at 17:32 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "adacrus.h"

void Adacrus__isInverted_reset(Adacrus__isInverted_mem* self) {
  self->v_16 = true;
  self->v = true;
}

void Adacrus__isInverted_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__isInverted_out* _out,
                              Adacrus__isInverted_mem* self) {
  
  int v_27;
  int v_26;
  int v_25;
  int v_24;
  int v_23;
  int v_21;
  int v_20;
  int v_19;
  int v_18;
  int v_17;
  int v_15;
  int v_13;
  int v_11;
  int v_10;
  int v_9;
  int v_7;
  int v_6;
  int v_5;
  int v_3;
  int v_2;
  int t;
  int inverted;
  v_23 = (self->v_22+1);
  v_20 = (right_wl>200);
  v_18 = (center_wl<50);
  v_17 = (left_wl>200);
  v_19 = (v_17&&v_18);
  v_21 = (v_19&&v_20);
  if (v_21) {
    v_24 = v_23;
  } else {
    v_24 = 0;
  };
  if (self->v_16) {
    t = 0;
  } else {
    t = v_24;
  };
  v_26 = (t>=3);
  v_13 = (self->v_12+1);
  v_9 = (255-self->v_8);
  v_10 = (center_wl==v_9);
  v_5 = (255-self->v_4);
  v_6 = (right_wl==v_5);
  v_2 = (255-self->v_1);
  v_3 = (left_wl==v_2);
  v_7 = (v_3&&v_6);
  v_11 = (v_7&&v_10);
  if (v_11) {
    v_15 = v_13;
  } else {
    v_15 = self->v_14;
  };
  if (self->v) {
    inverted = 0;
  } else {
    inverted = v_15;
  };
  v_25 = (inverted==1);
  v_27 = (v_25||v_26);
  if (v_27) {
    _out->out = true;
  } else {
    _out->out = false;
  };
  self->v_22 = t;
  self->v_16 = false;
  self->v_14 = inverted;
  self->v_12 = inverted;
  self->v_8 = center_wl;
  self->v_4 = right_wl;
  self->v_1 = left_wl;
  self->v = false;;
}

void Adacrus__isNode_reset(Adacrus__isNode_mem* self) {
  self->v_32 = true;
}

void Adacrus__isNode_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isNode_out* _out,
                          Adacrus__isNode_mem* self) {
  
  int v_35;
  int v_34;
  int v_31;
  int v_30;
  int v_29;
  int v_28;
  int v;
  int count;
  if (self->v_32) {
    v_34 = 0;
  } else {
    v_34 = self->v_33;
  };
  v_35 = (v_34+1);
  v_30 = (right_wl>200);
  v_28 = (left_wl>200);
  v = (center_wl>200);
  v_29 = (v&&v_28);
  v_31 = (v_29&&v_30);
  if (v_31) {
    count = v_35;
  } else {
    count = 0;
  };
  _out->out = (count>=t);
  self->v_33 = count;
  self->v_32 = false;;
}

void Adacrus__notIsNode_step(int left_wl, int center_wl, int right_wl,
                             Adacrus__notIsNode_out* _out) {
  
  int v_57;
  int v_56;
  int v_55;
  int v_54;
  int v_53;
  int v_52;
  int v_51;
  int v_50;
  int v_49;
  int v_48;
  int v_47;
  int v_46;
  int v_45;
  int v_44;
  int v_43;
  int v_42;
  int v_41;
  int v_40;
  int v_39;
  int v_38;
  int v_37;
  int v_36;
  int v;
  v_53 = (right_wl>200);
  v_51 = (center_wl>200);
  v_50 = (left_wl<50);
  v_52 = (v_50&&v_51);
  v_54 = (v_52&&v_53);
  if (v_54) {
    v_55 = false;
  } else {
    v_55 = true;
  };
  v_48 = (right_wl<50);
  v_46 = (center_wl>200);
  v_45 = (left_wl>200);
  v_47 = (v_45&&v_46);
  v_49 = (v_47&&v_48);
  if (v_49) {
    v_56 = false;
  } else {
    v_56 = v_55;
  };
  v_43 = (right_wl>200);
  v_41 = (center_wl>200);
  v_40 = (left_wl>200);
  v_42 = (v_40&&v_41);
  v_44 = (v_42&&v_43);
  if (v_44) {
    v_57 = false;
  } else {
    v_57 = v_56;
  };
  v_38 = (right_wl<50);
  v_36 = (center_wl<50);
  v = (left_wl<50);
  v_37 = (v&&v_36);
  v_39 = (v_37&&v_38);
  if (v_39) {
    _out->out = true;
  } else {
    _out->out = v_57;
  };;
}

void Adacrus__isAllWhite_reset(Adacrus__isAllWhite_mem* self) {
  self->v_62 = true;
}

void Adacrus__isAllWhite_step(int left_wl, int center_wl, int right_wl,
                              int t, Adacrus__isAllWhite_out* _out,
                              Adacrus__isAllWhite_mem* self) {
  
  int v_65;
  int v_64;
  int v_61;
  int v_60;
  int v_59;
  int v_58;
  int v;
  int count;
  if (self->v_62) {
    v_64 = 0;
  } else {
    v_64 = self->v_63;
  };
  v_65 = (v_64+1);
  v_60 = (right_wl<100);
  v_58 = (left_wl<100);
  v = (center_wl<100);
  v_59 = (v&&v_58);
  v_61 = (v_59&&v_60);
  if (v_61) {
    count = v_65;
  } else {
    count = 0;
  };
  _out->out = (count>=t);
  self->v_63 = count;
  self->v_62 = false;;
}

void Adacrus__isLine_reset(Adacrus__isLine_mem* self) {
  self->v = true;
}

void Adacrus__isLine_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isLine_out* _out,
                          Adacrus__isLine_mem* self) {
  
  int v_73;
  int v_72;
  int v_70;
  int v_69;
  int v_68;
  int v_67;
  int v_66;
  int count;
  v_72 = (self->v_71+1);
  v_69 = (right_wl<50);
  v_67 = (center_wl>200);
  v_66 = (left_wl<50);
  v_68 = (v_66&&v_67);
  v_70 = (v_68&&v_69);
  if (v_70) {
    v_73 = v_72;
  } else {
    v_73 = 0;
  };
  if (self->v) {
    count = 0;
  } else {
    count = v_73;
  };
  _out->out = (count>=t);
  self->v_71 = count;
  self->v = false;;
}

void Adacrus__halt_step(Adacrus__halt_out* _out) {
  _out->dir = Adacrus__Stop;
  _out->v_r = 0;
  _out->v_l = 0;
}

void Adacrus__determineLineLoc_step(int left_wl, int center_wl, int right_wl,
                                    Adacrus__determineLineLoc_out* _out) {
  
  Adacrus__lineloc v_113;
  Adacrus__lineloc v_112;
  Adacrus__lineloc v_111;
  Adacrus__lineloc v_110;
  Adacrus__lineloc v_109;
  Adacrus__lineloc v_108;
  int v_107;
  int v_106;
  int v_105;
  int v_104;
  int v_103;
  int v_102;
  int v_101;
  int v_100;
  int v_99;
  int v_98;
  int v_97;
  int v_96;
  int v_95;
  int v_94;
  int v_93;
  int v_92;
  int v_91;
  int v_90;
  int v_89;
  int v_88;
  int v_87;
  int v_86;
  int v_85;
  int v_84;
  int v_83;
  int v_82;
  int v_81;
  int v_80;
  int v_79;
  int v_78;
  int v_77;
  int v_76;
  int v_75;
  int v_74;
  int v;
  v_106 = (right_wl<50);
  v_104 = (center_wl>200);
  v_103 = (left_wl<50);
  v_105 = (v_103&&v_104);
  v_107 = (v_105&&v_106);
  if (v_107) {
    v_108 = Adacrus__OnLine;
  } else {
    v_108 = Adacrus__Undef;
  };
  v_101 = (right_wl>200);
  v_99 = (center_wl<50);
  v_98 = (left_wl<50);
  v_100 = (v_98&&v_99);
  v_102 = (v_100&&v_101);
  if (v_102) {
    v_109 = Adacrus__LOTooRight;
  } else {
    v_109 = v_108;
  };
  v_96 = (right_wl>200);
  v_94 = (center_wl>200);
  v_93 = (left_wl<50);
  v_95 = (v_93&&v_94);
  v_97 = (v_95&&v_96);
  if (v_97) {
    v_110 = Adacrus__LORight;
  } else {
    v_110 = v_109;
  };
  v_91 = (right_wl<50);
  v_89 = (center_wl<50);
  v_88 = (left_wl>200);
  v_90 = (v_88&&v_89);
  v_92 = (v_90&&v_91);
  if (v_92) {
    v_111 = Adacrus__LOTooLeft;
  } else {
    v_111 = v_110;
  };
  v_86 = (right_wl<50);
  v_84 = (center_wl>200);
  v_83 = (left_wl>200);
  v_85 = (v_83&&v_84);
  v_87 = (v_85&&v_86);
  if (v_87) {
    v_112 = Adacrus__LOLeft;
  } else {
    v_112 = v_111;
  };
  v_81 = (right_wl<50);
  v_79 = (center_wl<50);
  v_78 = (left_wl<50);
  v_80 = (v_78&&v_79);
  v_82 = (v_80&&v_81);
  if (v_82) {
    v_113 = Adacrus__NoLine;
  } else {
    v_113 = v_112;
  };
  v_76 = (right_wl>200);
  v_74 = (center_wl>200);
  v = (left_wl>200);
  v_75 = (v&&v_74);
  v_77 = (v_75&&v_76);
  if (v_77) {
    _out->l = Adacrus__Node;
  } else {
    _out->l = v_113;
  };;
}

void Adacrus__determineLineLocInverted_step(int left_wl, int center_wl,
                                            int right_wl,
                                            Adacrus__determineLineLocInverted_out* _out) {
  
  Adacrus__lineloc v_147;
  Adacrus__lineloc v_146;
  Adacrus__lineloc v_145;
  Adacrus__lineloc v_144;
  Adacrus__lineloc v_143;
  int v_142;
  int v_141;
  int v_140;
  int v_139;
  int v_138;
  int v_137;
  int v_136;
  int v_135;
  int v_134;
  int v_133;
  int v_132;
  int v_131;
  int v_130;
  int v_129;
  int v_128;
  int v_127;
  int v_126;
  int v_125;
  int v_124;
  int v_123;
  int v_122;
  int v_121;
  int v_120;
  int v_119;
  int v_118;
  int v_117;
  int v_116;
  int v_115;
  int v_114;
  int v;
  v_141 = (right_wl>200);
  v_139 = (center_wl<50);
  v_138 = (left_wl>200);
  v_140 = (v_138&&v_139);
  v_142 = (v_140&&v_141);
  if (v_142) {
    v_143 = Adacrus__OnLine;
  } else {
    v_143 = Adacrus__Undef;
  };
  v_136 = (right_wl<50);
  v_134 = (center_wl>200);
  v_133 = (left_wl>200);
  v_135 = (v_133&&v_134);
  v_137 = (v_135&&v_136);
  if (v_137) {
    v_144 = Adacrus__LOTooRight;
  } else {
    v_144 = v_143;
  };
  v_131 = (right_wl<50);
  v_129 = (center_wl<50);
  v_128 = (left_wl>200);
  v_130 = (v_128&&v_129);
  v_132 = (v_130&&v_131);
  if (v_132) {
    v_145 = Adacrus__LORight;
  } else {
    v_145 = v_144;
  };
  v_126 = (right_wl>200);
  v_124 = (center_wl>200);
  v_123 = (left_wl<50);
  v_125 = (v_123&&v_124);
  v_127 = (v_125&&v_126);
  if (v_127) {
    v_146 = Adacrus__LOTooLeft;
  } else {
    v_146 = v_145;
  };
  v_121 = (right_wl>200);
  v_119 = (center_wl<50);
  v_118 = (left_wl<50);
  v_120 = (v_118&&v_119);
  v_122 = (v_120&&v_121);
  if (v_122) {
    v_147 = Adacrus__LOLeft;
  } else {
    v_147 = v_146;
  };
  v_116 = (right_wl>200);
  v_114 = (center_wl>200);
  v = (left_wl>200);
  v_115 = (v&&v_114);
  v_117 = (v_115&&v_116);
  if (v_117) {
    _out->l = Adacrus__NoLine;
  } else {
    _out->l = v_147;
  };;
}

void Adacrus__moveAut_reset(Adacrus__moveAut_mem* self) {
  Adacrus__isAllWhite_reset(&self->isAllWhite);
  Adacrus__isLine_reset(&self->isLine);
  self->v_181 = false;
  self->v_180 = Adacrus__St_1_Uncertain;
  self->past_ll_6 = Adacrus__Node;
  self->pnr_2 = false;
  self->v_175 = true;
  self->v_172 = false;
  self->v_170 = 60;
  self->v_168 = false;
  self->v_166 = Adacrus__St_Scan;
  self->v_159 = true;
  self->v_152 = true;
  self->ck = Adacrus__St_2_Basic;
}

void Adacrus__moveAut_step(int left_wl, int center_wl, int right_wl,
                           int curve, int inverted, int zigzagt, int zigzagb,
                           Adacrus__moveAut_out* _out,
                           Adacrus__moveAut_mem* self) {
  Adacrus__isAllWhite_out Adacrus__isAllWhite_out_st;
  Adacrus__isLine_out Adacrus__isLine_out_st;
  Adacrus__determineLineLoc_out Adacrus__determineLineLoc_out_st;
  
  int v_157;
  int v_155;
  int v_154;
  int v_153;
  int v_151;
  int t_2;
  int v_164;
  int v_162;
  int v_161;
  int v_160;
  int v_158;
  int t_1;
  int v_165;
  int nr_St_UpdateDir;
  Adacrus__st ns_St_UpdateDir;
  int dir_St_UpdateDir;
  int scan_t_St_UpdateDir;
  int v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_UpdateDir;
  int v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_UpdateDir;
  int nr_St_Initial;
  Adacrus__st ns_St_Initial;
  int dir_St_Initial;
  int scan_t_St_Initial;
  int v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial;
  int v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial;
  int nr_St_Scan;
  Adacrus__st ns_St_Scan;
  int dir_St_Scan;
  int scan_t_St_Scan;
  int v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan;
  int v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan;
  Adacrus__st ck_2;
  int v_171;
  int v_169;
  int v_167;
  int r_8;
  Adacrus__st ns;
  int r;
  int nr;
  int pnr;
  int dir_7;
  int scan_t_1;
  int scan_t;
  int dir;
  int v_179;
  int v_177;
  int v_176;
  int v_174;
  int v_173;
  int r_9;
  int t;
  int nr_1_St_1_ZigOrZag;
  Adacrus__st_1 ns_1_St_1_ZigOrZag;
  int line_found_St_1_ZigOrZag;
  int v_r_St_2_MoveZigZag_St_1_ZigOrZag;
  int v_l_St_2_MoveZigZag_St_1_ZigOrZag;
  int nr_1_St_1_Uncertain;
  Adacrus__st_1 ns_1_St_1_Uncertain;
  int line_found_St_1_Uncertain;
  int v_r_St_2_MoveZigZag_St_1_Uncertain;
  int v_l_St_2_MoveZigZag_St_1_Uncertain;
  Adacrus__st_1 ck_1;
  Adacrus__st_1 ns_1;
  int r_1;
  int nr_1;
  int pnr_1;
  int line_found;
  int v_196;
  int v_195;
  int v_194;
  int v_193;
  int v_192;
  int v_191;
  int v_190;
  int v_189;
  int v_188;
  int v_187;
  int v_186;
  int v_185;
  int v_184;
  int v_183;
  int v_182;
  int v_215;
  int v_214;
  int v_213;
  int v_212;
  int v_211;
  int v_210;
  int v_209;
  int v_208;
  int v_207;
  int v_206;
  int v_205;
  int v_204;
  int v_203;
  int v_202;
  Adacrus__st_2 v_201;
  int v_200;
  int v_199;
  int v_198;
  int v_197;
  int nr_2_St_2_MoveZigZag;
  Adacrus__st_2 ns_2_St_2_MoveZigZag;
  int v_r_St_2_MoveZigZag;
  int v_l_St_2_MoveZigZag;
  int nr_2_St_2_LookBack;
  Adacrus__st_2 ns_2_St_2_LookBack;
  int v_r_St_2_LookBack;
  int v_l_St_2_LookBack;
  int nr_2_St_2_Basic;
  Adacrus__st_2 ns_2_St_2_Basic;
  int v_r_St_2_Basic;
  int v_l_St_2_Basic;
  int v_150;
  int v_149;
  int v_148;
  int v;
  Adacrus__st_2 ns_2;
  int r_2;
  int nr_2;
  Adacrus__lineloc curr_ll;
  Adacrus__lineloc past_ll;
  r_2 = self->pnr_2;
  Adacrus__determineLineLoc_step(left_wl, center_wl, right_wl,
                                 &Adacrus__determineLineLoc_out_st);
  curr_ll = Adacrus__determineLineLoc_out_st.l;
  v_148 = (curr_ll==Adacrus__Node);
  v = (curr_ll==Adacrus__NoLine);
  v_149 = (v||v_148);
  v_150 = !(v_149);
  if (v_150) {
    past_ll = curr_ll;
  } else {
    past_ll = self->past_ll_6;
  };
  switch (self->ck) {
    case Adacrus__St_2_Basic:
      v_207 = (curr_ll==Adacrus__LOTooRight);
      if (v_207) {
        v_209 = 0;
        v_208 = 200;
      } else {
        v_209 = 25;
        v_208 = 25;
      };
      v_206 = (curr_ll==Adacrus__LORight);
      if (v_206) {
        v_211 = 50;
        v_210 = 200;
      } else {
        v_211 = v_209;
        v_210 = v_208;
      };
      v_205 = (curr_ll==Adacrus__LOTooLeft);
      if (v_205) {
        v_213 = 200;
        v_212 = 0;
      } else {
        v_213 = v_211;
        v_212 = v_210;
      };
      v_204 = (curr_ll==Adacrus__LOLeft);
      if (v_204) {
        v_215 = 200;
        v_214 = 50;
      } else {
        v_215 = v_213;
        v_214 = v_212;
      };
      v_203 = (curr_ll==Adacrus__OnLine);
      if (v_203) {
        v_r_St_2_Basic = 200;
        v_l_St_2_Basic = 200;
      } else {
        v_r_St_2_Basic = v_215;
        v_l_St_2_Basic = v_214;
      };
      v_200 = (curr_ll==Adacrus__NoLine);
      if (v_200) {
        v_202 = true;
        v_201 = Adacrus__St_2_LookBack;
      } else {
        v_202 = false;
        v_201 = Adacrus__St_2_Basic;
      };
      v_198 = (zigzagt||zigzagb);
      v_197 = (curr_ll==Adacrus__NoLine);
      v_199 = (v_197&&v_198);
      if (v_199) {
        nr_2_St_2_Basic = true;
        ns_2_St_2_Basic = Adacrus__St_2_MoveZigZag;
      } else {
        nr_2_St_2_Basic = v_202;
        ns_2_St_2_Basic = v_201;
      };
      _out->v_l = v_l_St_2_Basic;
      _out->v_r = v_r_St_2_Basic;
      ns_2 = ns_2_St_2_Basic;
      nr_2 = nr_2_St_2_Basic;
      break;
    case Adacrus__St_2_LookBack:
      v_188 = (self->past_ll_6==Adacrus__LOTooRight);
      if (v_188) {
        v_190 = 0;
        v_189 = 200;
      } else {
        v_190 = 25;
        v_189 = 25;
      };
      v_187 = (self->past_ll_6==Adacrus__LORight);
      if (v_187) {
        v_192 = 0;
        v_191 = 200;
      } else {
        v_192 = v_190;
        v_191 = v_189;
      };
      v_186 = (self->past_ll_6==Adacrus__LOTooLeft);
      if (v_186) {
        v_194 = 200;
        v_193 = 0;
      } else {
        v_194 = v_192;
        v_193 = v_191;
      };
      v_185 = (self->past_ll_6==Adacrus__LOLeft);
      if (v_185) {
        v_196 = 200;
        v_195 = 0;
      } else {
        v_196 = v_194;
        v_195 = v_193;
      };
      v_184 = (self->past_ll_6==Adacrus__OnLine);
      if (v_184) {
        v_r_St_2_LookBack = 50;
        v_l_St_2_LookBack = 50;
      } else {
        v_r_St_2_LookBack = v_196;
        v_l_St_2_LookBack = v_195;
      };
      v_182 = (curr_ll==Adacrus__NoLine);
      v_183 = !(v_182);
      if (v_183) {
        nr_2_St_2_LookBack = true;
        ns_2_St_2_LookBack = Adacrus__St_2_Basic;
      } else {
        nr_2_St_2_LookBack = false;
        ns_2_St_2_LookBack = Adacrus__St_2_LookBack;
      };
      _out->v_l = v_l_St_2_LookBack;
      _out->v_r = v_r_St_2_LookBack;
      ns_2 = ns_2_St_2_LookBack;
      nr_2 = nr_2_St_2_LookBack;
      break;
    case Adacrus__St_2_MoveZigZag:
      if (r_2) {
        pnr_1 = false;
      } else {
        pnr_1 = self->v_181;
      };
      r_1 = pnr_1;
      if (r_2) {
        ck_1 = Adacrus__St_1_Uncertain;
      } else {
        ck_1 = self->v_180;
      };
      switch (ck_1) {
        case Adacrus__St_1_Uncertain:
          v_179 = (self->v_178+1);
          v_176 = (r_2||r_1);
          if (self->v_175) {
            v_177 = true;
          } else {
            v_177 = v_176;
          };
          if (v_177) {
            t = 0;
          } else {
            t = v_179;
          };
          v_r_St_2_MoveZigZag_St_1_Uncertain = 53;
          v_l_St_2_MoveZigZag_St_1_Uncertain = 53;
          v_173 = (t>15);
          if (v_173) {
            nr_1_St_1_Uncertain = false;
            ns_1_St_1_Uncertain = Adacrus__St_1_ZigOrZag;
          } else {
            nr_1_St_1_Uncertain = false;
            ns_1_St_1_Uncertain = Adacrus__St_1_Uncertain;
          };
          r_9 = (r_2||r_1);
          if (r_9) {
            Adacrus__isAllWhite_reset(&self->isAllWhite);
          };
          Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 1,
                                   &Adacrus__isAllWhite_out_st,
                                   &self->isAllWhite);
          v_174 = Adacrus__isAllWhite_out_st.out;
          line_found_St_1_Uncertain = !(v_174);
          line_found = line_found_St_1_Uncertain;
          ns_1 = ns_1_St_1_Uncertain;
          nr_1 = nr_1_St_1_Uncertain;
          v_l_St_2_MoveZigZag = v_l_St_2_MoveZigZag_St_1_Uncertain;
          v_r_St_2_MoveZigZag = v_r_St_2_MoveZigZag_St_1_Uncertain;
          break;
        case Adacrus__St_1_ZigOrZag:
          v_171 = (r_2||r_1);
          if (v_171) {
            dir_7 = false;
          } else {
            dir_7 = self->v_172;
          };
          v_169 = (r_2||r_1);
          if (v_169) {
            scan_t_1 = 60;
          } else {
            scan_t_1 = self->v_170;
          };
          v_167 = (r_2||r_1);
          if (v_167) {
            pnr = false;
          } else {
            pnr = self->v_168;
          };
          r = pnr;
          v_165 = (r_2||r_1);
          if (v_165) {
            ck_2 = Adacrus__St_Scan;
          } else {
            ck_2 = self->v_166;
          };
          r_8 = (r_2||r_1);
          if (r_8) {
            Adacrus__isLine_reset(&self->isLine);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 5,
                               &Adacrus__isLine_out_st, &self->isLine);
          line_found_St_1_ZigOrZag = Adacrus__isLine_out_st.out;
          line_found = line_found_St_1_ZigOrZag;
          if (line_found) {
            nr_1_St_1_ZigOrZag = true;
            ns_1_St_1_ZigOrZag = Adacrus__St_1_Uncertain;
          } else {
            nr_1_St_1_ZigOrZag = false;
            ns_1_St_1_ZigOrZag = Adacrus__St_1_ZigOrZag;
          };
          ns_1 = ns_1_St_1_ZigOrZag;
          nr_1 = nr_1_St_1_ZigOrZag;
          switch (ck_2) {
            case Adacrus__St_Scan:
              dir_St_Scan = dir_7;
              scan_t_St_Scan = scan_t_1;
              v_164 = (self->v_163+1);
              v_160 = (r_2||r_1);
              v_161 = (v_160||r);
              if (self->v_159) {
                v_162 = true;
              } else {
                v_162 = v_161;
              };
              if (v_162) {
                t_1 = 0;
              } else {
                t_1 = v_164;
              };
              scan_t = scan_t_St_Scan;
              v_158 = (t_1>scan_t);
              if (v_158) {
                nr_St_Scan = true;
                ns_St_Scan = Adacrus__St_Initial;
              } else {
                nr_St_Scan = false;
                ns_St_Scan = Adacrus__St_Scan;
              };
              dir = dir_St_Scan;
              if (dir) {
                v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan = -100;
                v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan = 100;
              } else {
                v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan = 100;
                v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan = -100;
              };
              v_l_St_2_MoveZigZag_St_1_ZigOrZag = v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan;
              v_r_St_2_MoveZigZag_St_1_ZigOrZag = v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Scan;
              ns = ns_St_Scan;
              nr = nr_St_Scan;
              break;
            case Adacrus__St_Initial:
              dir_St_Initial = dir_7;
              scan_t_St_Initial = scan_t_1;
              v_157 = (self->v_156+1);
              v_153 = (r_2||r_1);
              v_154 = (v_153||r);
              if (self->v_152) {
                v_155 = true;
              } else {
                v_155 = v_154;
              };
              if (v_155) {
                t_2 = 0;
              } else {
                t_2 = v_157;
              };
              scan_t = scan_t_St_Initial;
              v_151 = (t_2>scan_t);
              if (v_151) {
                nr_St_Initial = true;
                ns_St_Initial = Adacrus__St_UpdateDir;
              } else {
                nr_St_Initial = false;
                ns_St_Initial = Adacrus__St_Initial;
              };
              dir = dir_St_Initial;
              if (dir) {
                v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial = 100;
                v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial = -100;
              } else {
                v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial = -100;
                v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial = 100;
              };
              v_l_St_2_MoveZigZag_St_1_ZigOrZag = v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial;
              v_r_St_2_MoveZigZag_St_1_ZigOrZag = v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_Initial;
              ns = ns_St_Initial;
              nr = nr_St_Initial;
              break;
            case Adacrus__St_UpdateDir:
              dir_St_UpdateDir = !(dir_7);
              v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_UpdateDir = 0;
              v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_UpdateDir = 0;
              scan_t_St_UpdateDir = (2*scan_t_1);
              if (true) {
                nr_St_UpdateDir = true;
              } else {
                nr_St_UpdateDir = false;
              };
              if (true) {
                ns_St_UpdateDir = Adacrus__St_Scan;
              } else {
                ns_St_UpdateDir = Adacrus__St_UpdateDir;
              };
              scan_t = scan_t_St_UpdateDir;
              dir = dir_St_UpdateDir;
              v_l_St_2_MoveZigZag_St_1_ZigOrZag = v_l_St_2_MoveZigZag_St_1_ZigOrZag_St_UpdateDir;
              v_r_St_2_MoveZigZag_St_1_ZigOrZag = v_r_St_2_MoveZigZag_St_1_ZigOrZag_St_UpdateDir;
              ns = ns_St_UpdateDir;
              nr = nr_St_UpdateDir;
              break;
            default:
              break;
          };
          v_l_St_2_MoveZigZag = v_l_St_2_MoveZigZag_St_1_ZigOrZag;
          v_r_St_2_MoveZigZag = v_r_St_2_MoveZigZag_St_1_ZigOrZag;
          break;
        default:
          break;
      };
      if (line_found) {
        nr_2_St_2_MoveZigZag = true;
        ns_2_St_2_MoveZigZag = Adacrus__St_2_Basic;
      } else {
        nr_2_St_2_MoveZigZag = false;
        ns_2_St_2_MoveZigZag = Adacrus__St_2_MoveZigZag;
      };
      _out->v_l = v_l_St_2_MoveZigZag;
      _out->v_r = v_r_St_2_MoveZigZag;
      ns_2 = ns_2_St_2_MoveZigZag;
      nr_2 = nr_2_St_2_MoveZigZag;
      self->v_181 = nr_1;
      self->v_180 = ns_1;
      break;
    default:
      break;
  };
  self->past_ll_6 = past_ll;
  self->pnr_2 = nr_2;
  switch (self->ck) {
    case Adacrus__St_2_MoveZigZag:
      switch (ck_1) {
        case Adacrus__St_1_Uncertain:
          self->v_178 = t;
          self->v_175 = false;
          break;
        case Adacrus__St_1_ZigOrZag:
          self->v_172 = dir;
          self->v_170 = scan_t;
          self->v_168 = nr;
          self->v_166 = ns;
          switch (ck_2) {
            case Adacrus__St_Scan:
              self->v_163 = t_1;
              self->v_159 = false;
              break;
            case Adacrus__St_Initial:
              self->v_156 = t_2;
              self->v_152 = false;
              break;
            default:
              break;
          };
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };
  self->ck = ns_2;;
}

void Adacrus__move_reset(Adacrus__move_mem* self) {
  Adacrus__isAllWhite_reset(&self->isAllWhite_1);
  Adacrus__isLine_reset(&self->isLine_1);
  Adacrus__isAllWhite_reset(&self->isAllWhite);
  Adacrus__isInverted_reset(&self->isInverted);
  Adacrus__isLine_reset(&self->isLine);
  self->zz_1 = 0;
  self->past_ll_7 = Adacrus__Node;
  self->pnr = false;
  self->v_294 = true;
  self->pnr_3 = false;
  self->ck = Adacrus__St_4_In;
  self->v_256 = true;
  self->v_306 = true;
  self->v_301 = true;
  self->ck_3 = Adacrus__St_3_In;
}

void Adacrus__move_step(int left_wl, int center_wl, int right_wl, int curve,
                        int inverted, int zigzagt, int zigzagb,
                        Adacrus__move_out* _out, Adacrus__move_mem* self) {
  Adacrus__isAllWhite_out Adacrus__isAllWhite_out_st;
  Adacrus__isInverted_out Adacrus__isInverted_out_st;
  Adacrus__determineLineLocInverted_out Adacrus__determineLineLocInverted_out_st;
  Adacrus__isLine_out Adacrus__isLine_out_st;
  Adacrus__determineLineLoc_out Adacrus__determineLineLoc_out_st;
  
  int v_291;
  int r_10;
  int v_293;
  int v_292;
  int r_11;
  int nr_3_St_4_Inv;
  Adacrus__st_4 ns_3_St_4_Inv;
  Adacrus__lineloc curr_ll_St_4_Inv;
  int nr_3_St_4_In;
  Adacrus__st_4 ns_3_St_4_In;
  Adacrus__lineloc curr_ll_St_4_In;
  int v_299;
  int r_12;
  int v_300;
  int r_13;
  int v_311;
  int v_310;
  int v_309;
  int v_307;
  int v_305;
  int v_304;
  int v_302;
  int v_312;
  int r_14;
  int nr_St_3_MaintainBlack;
  Adacrus__st_3 ns_St_3_MaintainBlack;
  int zz_St_3_MaintainBlack;
  int nr_St_3_MaintainWhite;
  Adacrus__st_3 ns_St_3_MaintainWhite;
  int zz_St_3_MaintainWhite;
  int nr_St_3_ZigToZag;
  Adacrus__st_3 ns_St_3_ZigToZag;
  int zz_St_3_ZigToZag;
  int nr_St_3_In;
  Adacrus__st_3 ns_St_3_In;
  int zz_St_3_In;
  int v_298;
  int v_296;
  int v_295;
  int v_290;
  int v_289;
  int v_288;
  int v_287;
  int v_286;
  int v_285;
  int v_284;
  int v_283;
  int v_282;
  int v_281;
  int v_280;
  int v_279;
  int v_278;
  int v_277;
  int v_276;
  int v_275;
  int v_274;
  int v_273;
  int v_272;
  int v_271;
  int v_270;
  int v_269;
  int v_268;
  int v_267;
  int v_266;
  int v_265;
  int v_264;
  int v_263;
  int v_262;
  int v_261;
  int v_260;
  int v_259;
  int v_255;
  int v_254;
  int v_253;
  int v_252;
  int v_251;
  int v_250;
  int v_249;
  int v_248;
  int v_247;
  int v_246;
  int v_245;
  int v_244;
  int v_243;
  int v_242;
  int v_241;
  int v_240;
  int v_239;
  int v_238;
  int v_237;
  int v_236;
  int v_235;
  int v_234;
  int v_233;
  int v_232;
  int v_231;
  int v_230;
  int v_229;
  int v_228;
  int v_227;
  int v_226;
  int v_225;
  int v_224;
  int v_223;
  int v_222;
  int v_221;
  int v_220;
  int v_219;
  int v_218;
  int v_217;
  int v_216;
  int v;
  Adacrus__st_4 ns_3;
  int r_3;
  int nr_3;
  Adacrus__st_3 ns;
  int r;
  int nr;
  Adacrus__lineloc curr_ll;
  Adacrus__lineloc past_ll;
  int zz;
  int nzz;
  r = self->pnr;
  r_3 = self->pnr_3;
  if (self->v_256) {
    v_260 = 0;
  } else {
    v_260 = self->v_258;
  };
  if (curve) {
    v_262 = v_260;
  } else {
    v_262 = 25;
  };
  if (self->v_256) {
    v_259 = 0;
  } else {
    v_259 = self->v_257;
  };
  if (curve) {
    v_261 = v_259;
  } else {
    v_261 = 25;
  };
  v_254 = (self->past_ll_7==Adacrus__LOTooRight);
  v_251 = (self->past_ll_7==Adacrus__LORight);
  v_248 = (self->past_ll_7==Adacrus__LOTooLeft);
  v_245 = (self->past_ll_7==Adacrus__LOLeft);
  v_242 = (self->past_ll_7==Adacrus__OnLine);
  switch (self->ck_3) {
    case Adacrus__St_3_In:
      zz_St_3_In = 0;
      r_14 = r;
      if (r_14) {
        Adacrus__isAllWhite_reset(&self->isAllWhite_1);
      };
      Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 35,
                               &Adacrus__isAllWhite_out_st,
                               &self->isAllWhite_1);
      v_312 = Adacrus__isAllWhite_out_st.out;
      if (v_312) {
        nr_St_3_In = true;
        ns_St_3_In = Adacrus__St_3_ZigToZag;
      } else {
        nr_St_3_In = false;
        ns_St_3_In = Adacrus__St_3_In;
      };
      zz = zz_St_3_In;
      ns = ns_St_3_In;
      nr = nr_St_3_In;
      break;
    case Adacrus__St_3_ZigToZag:
      if (self->v_306) {
        v_307 = true;
      } else {
        v_307 = r;
      };
      if (v_307) {
        v_309 = 0;
      } else {
        v_309 = self->v_308;
      };
      v_310 = (v_309==1);
      if (v_310) {
        v_311 = 2;
      } else {
        v_311 = 1;
      };
      if (self->v_301) {
        v_302 = true;
      } else {
        v_302 = r;
      };
      if (v_302) {
        v_304 = 0;
      } else {
        v_304 = self->v_303;
      };
      v_305 = (v_304==0);
      if (v_305) {
        zz_St_3_ZigToZag = 1;
      } else {
        zz_St_3_ZigToZag = v_311;
      };
      if (true) {
        nr_St_3_ZigToZag = true;
      } else {
        nr_St_3_ZigToZag = false;
      };
      if (true) {
        ns_St_3_ZigToZag = Adacrus__St_3_MaintainWhite;
      } else {
        ns_St_3_ZigToZag = Adacrus__St_3_ZigToZag;
      };
      zz = zz_St_3_ZigToZag;
      ns = ns_St_3_ZigToZag;
      nr = nr_St_3_ZigToZag;
      break;
    case Adacrus__St_3_MaintainWhite:
      zz_St_3_MaintainWhite = 0;
      r_13 = r;
      if (r_13) {
        Adacrus__isLine_reset(&self->isLine_1);
      };
      Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                           &Adacrus__isLine_out_st, &self->isLine_1);
      v_300 = Adacrus__isLine_out_st.out;
      if (v_300) {
        nr_St_3_MaintainWhite = true;
        ns_St_3_MaintainWhite = Adacrus__St_3_MaintainBlack;
      } else {
        nr_St_3_MaintainWhite = false;
        ns_St_3_MaintainWhite = Adacrus__St_3_MaintainWhite;
      };
      zz = zz_St_3_MaintainWhite;
      ns = ns_St_3_MaintainWhite;
      nr = nr_St_3_MaintainWhite;
      break;
    case Adacrus__St_3_MaintainBlack:
      zz_St_3_MaintainBlack = 0;
      r_12 = r;
      if (r_12) {
        Adacrus__isAllWhite_reset(&self->isAllWhite);
      };
      Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 35,
                               &Adacrus__isAllWhite_out_st, &self->isAllWhite);
      v_299 = Adacrus__isAllWhite_out_st.out;
      if (v_299) {
        nr_St_3_MaintainBlack = true;
        ns_St_3_MaintainBlack = Adacrus__St_3_ZigToZag;
      } else {
        nr_St_3_MaintainBlack = false;
        ns_St_3_MaintainBlack = Adacrus__St_3_MaintainBlack;
      };
      zz = zz_St_3_MaintainBlack;
      ns = ns_St_3_MaintainBlack;
      nr = nr_St_3_MaintainBlack;
      break;
    default:
      break;
  };
  v_295 = (zz==0);
  v_296 = !(v_295);
  if (v_296) {
    v_298 = zz;
  } else {
    v_298 = self->v_297;
  };
  if (self->v_294) {
    nzz = 0;
  } else {
    nzz = v_298;
  };
  v_239 = (zz==2);
  v_235 = (zz==1);
  v_231 = (zz==2);
  v_227 = (zz==1);
  switch (self->ck) {
    case Adacrus__St_4_In:
      Adacrus__determineLineLoc_step(left_wl, center_wl, right_wl,
                                     &Adacrus__determineLineLoc_out_st);
      curr_ll_St_4_In = Adacrus__determineLineLoc_out_st.l;
      r_11 = r_3;
      if (r_11) {
        Adacrus__isInverted_reset(&self->isInverted);
      };
      Adacrus__isInverted_step(left_wl, center_wl, right_wl,
                               &Adacrus__isInverted_out_st, &self->isInverted);
      v_292 = Adacrus__isInverted_out_st.out;
      v_293 = (inverted&&v_292);
      if (v_293) {
        nr_3_St_4_In = true;
        ns_3_St_4_In = Adacrus__St_4_Inv;
      } else {
        nr_3_St_4_In = false;
        ns_3_St_4_In = Adacrus__St_4_In;
      };
      curr_ll = curr_ll_St_4_In;
      ns_3 = ns_3_St_4_In;
      nr_3 = nr_3_St_4_In;
      break;
    case Adacrus__St_4_Inv:
      Adacrus__determineLineLocInverted_step(left_wl, center_wl, right_wl,
                                             &Adacrus__determineLineLocInverted_out_st);
      curr_ll_St_4_Inv = Adacrus__determineLineLocInverted_out_st.l;
      r_10 = r_3;
      if (r_10) {
        Adacrus__isLine_reset(&self->isLine);
      };
      Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                           &Adacrus__isLine_out_st, &self->isLine);
      v_291 = Adacrus__isLine_out_st.out;
      if (v_291) {
        nr_3_St_4_Inv = true;
        ns_3_St_4_Inv = Adacrus__St_4_In;
      } else {
        nr_3_St_4_Inv = false;
        ns_3_St_4_Inv = Adacrus__St_4_Inv;
      };
      curr_ll = curr_ll_St_4_Inv;
      ns_3 = ns_3_St_4_Inv;
      nr_3 = nr_3_St_4_Inv;
      break;
    default:
      break;
  };
  v_253 = (curr_ll==Adacrus__NoLine);
  v_255 = (v_253&&v_254);
  if (v_255) {
    v_264 = 0;
    v_263 = 200;
  } else {
    v_264 = v_262;
    v_263 = v_261;
  };
  v_250 = (curr_ll==Adacrus__NoLine);
  v_252 = (v_250&&v_251);
  if (v_252) {
    v_266 = 0;
    v_265 = 200;
  } else {
    v_266 = v_264;
    v_265 = v_263;
  };
  v_247 = (curr_ll==Adacrus__NoLine);
  v_249 = (v_247&&v_248);
  if (v_249) {
    v_268 = 200;
    v_267 = 0;
  } else {
    v_268 = v_266;
    v_267 = v_265;
  };
  v_244 = (curr_ll==Adacrus__NoLine);
  v_246 = (v_244&&v_245);
  if (v_246) {
    v_270 = 200;
    v_269 = 0;
  } else {
    v_270 = v_268;
    v_269 = v_267;
  };
  v_241 = (curr_ll==Adacrus__NoLine);
  v_243 = (v_241&&v_242);
  if (v_243) {
    v_272 = 50;
    v_271 = 50;
  } else {
    v_272 = v_270;
    v_271 = v_269;
  };
  v_237 = (curr_ll==Adacrus__NoLine);
  v_238 = (v_237&&zigzagb);
  v_240 = (v_238&&v_239);
  if (v_240) {
    v_274 = 200;
    v_273 = 0;
  } else {
    v_274 = v_272;
    v_273 = v_271;
  };
  v_233 = (curr_ll==Adacrus__NoLine);
  v_234 = (v_233&&zigzagb);
  v_236 = (v_234&&v_235);
  if (v_236) {
    v_276 = 0;
    v_275 = 200;
  } else {
    v_276 = v_274;
    v_275 = v_273;
  };
  v_229 = (curr_ll==Adacrus__NoLine);
  v_230 = (v_229&&zigzagt);
  v_232 = (v_230&&v_231);
  if (v_232) {
    v_278 = 0;
    v_277 = 200;
  } else {
    v_278 = v_276;
    v_277 = v_275;
  };
  v_225 = (curr_ll==Adacrus__NoLine);
  v_226 = (v_225&&zigzagt);
  v_228 = (v_226&&v_227);
  if (v_228) {
    v_280 = 200;
    v_279 = 0;
  } else {
    v_280 = v_278;
    v_279 = v_277;
  };
  v_224 = (curr_ll==Adacrus__Node);
  if (v_224) {
    v_282 = 50;
    v_281 = 50;
  } else {
    v_282 = v_280;
    v_281 = v_279;
  };
  v_223 = (curr_ll==Adacrus__LOTooRight);
  if (v_223) {
    v_284 = 0;
    v_283 = 200;
  } else {
    v_284 = v_282;
    v_283 = v_281;
  };
  v_222 = (curr_ll==Adacrus__LORight);
  if (v_222) {
    v_286 = 50;
    v_285 = 200;
  } else {
    v_286 = v_284;
    v_285 = v_283;
  };
  v_221 = (curr_ll==Adacrus__LOTooLeft);
  if (v_221) {
    v_288 = 200;
    v_287 = 0;
  } else {
    v_288 = v_286;
    v_287 = v_285;
  };
  v_220 = (curr_ll==Adacrus__LOLeft);
  if (v_220) {
    v_290 = 200;
    v_289 = 50;
  } else {
    v_290 = v_288;
    v_289 = v_287;
  };
  v_219 = (curr_ll==Adacrus__OnLine);
  if (v_219) {
    _out->v_r = 100;
    _out->v_l = 100;
  } else {
    _out->v_r = v_290;
    _out->v_l = v_289;
  };
  v_216 = (curr_ll==Adacrus__Node);
  v = (curr_ll==Adacrus__NoLine);
  v_217 = (v||v_216);
  v_218 = !(v_217);
  if (v_218) {
    past_ll = curr_ll;
  } else {
    past_ll = self->past_ll_7;
  };
  self->zz_1 = zz;
  self->past_ll_7 = past_ll;
  self->pnr = nr;
  self->v_297 = nzz;
  self->v_294 = false;
  self->pnr_3 = nr_3;
  self->ck = ns_3;
  self->v_258 = _out->v_r;
  self->v_257 = _out->v_l;
  self->v_256 = false;
  switch (self->ck_3) {
    case Adacrus__St_3_ZigToZag:
      self->v_308 = nzz;
      self->v_306 = false;
      self->v_303 = nzz;
      self->v_301 = false;
      break;
    default:
      break;
  };
  self->ck_3 = ns;;
}

void Adacrus__calcOrientation_step(Adacrus__states current_state,
                                   Adacrus__orientation last_oriented,
                                   Adacrus__calcOrientation_out* _out) {
  
  Adacrus__orientation v_358;
  Adacrus__orientation v_357;
  Adacrus__orientation v_356;
  Adacrus__orientation v_355;
  Adacrus__orientation v_354;
  Adacrus__orientation v_353;
  Adacrus__orientation v_352;
  Adacrus__orientation v_351;
  Adacrus__orientation v_350;
  Adacrus__orientation v_349;
  Adacrus__orientation v_348;
  int v_347;
  int v_346;
  int v_345;
  int v_344;
  int v_343;
  int v_342;
  int v_341;
  int v_340;
  int v_339;
  int v_338;
  int v_337;
  int v_336;
  int v_335;
  int v_334;
  int v_333;
  int v_332;
  int v_331;
  int v_330;
  int v_329;
  int v_328;
  int v_327;
  int v_326;
  int v_325;
  int v_324;
  int v_323;
  int v_322;
  int v_321;
  int v_320;
  int v_319;
  int v_318;
  int v_317;
  int v_316;
  int v_315;
  int v_314;
  int v_313;
  int v;
  v_346 = (current_state==Adacrus__Rot180);
  v_345 = (last_oriented==Adacrus__B);
  v_347 = (v_345&&v_346);
  if (v_347) {
    v_348 = Adacrus__T;
  } else {
    v_348 = last_oriented;
  };
  v_343 = (current_state==Adacrus__RotR);
  v_342 = (last_oriented==Adacrus__B);
  v_344 = (v_342&&v_343);
  if (v_344) {
    v_349 = Adacrus__L;
  } else {
    v_349 = v_348;
  };
  v_340 = (current_state==Adacrus__RotL);
  v_339 = (last_oriented==Adacrus__B);
  v_341 = (v_339&&v_340);
  if (v_341) {
    v_350 = Adacrus__R;
  } else {
    v_350 = v_349;
  };
  v_337 = (current_state==Adacrus__Rot180);
  v_336 = (last_oriented==Adacrus__L);
  v_338 = (v_336&&v_337);
  if (v_338) {
    v_351 = Adacrus__R;
  } else {
    v_351 = v_350;
  };
  v_334 = (current_state==Adacrus__RotR);
  v_333 = (last_oriented==Adacrus__L);
  v_335 = (v_333&&v_334);
  if (v_335) {
    v_352 = Adacrus__T;
  } else {
    v_352 = v_351;
  };
  v_331 = (current_state==Adacrus__RotL);
  v_330 = (last_oriented==Adacrus__L);
  v_332 = (v_330&&v_331);
  if (v_332) {
    v_353 = Adacrus__B;
  } else {
    v_353 = v_352;
  };
  v_328 = (current_state==Adacrus__Rot180);
  v_327 = (last_oriented==Adacrus__R);
  v_329 = (v_327&&v_328);
  if (v_329) {
    v_354 = Adacrus__L;
  } else {
    v_354 = v_353;
  };
  v_325 = (current_state==Adacrus__RotR);
  v_324 = (last_oriented==Adacrus__R);
  v_326 = (v_324&&v_325);
  if (v_326) {
    v_355 = Adacrus__B;
  } else {
    v_355 = v_354;
  };
  v_322 = (current_state==Adacrus__RotL);
  v_321 = (last_oriented==Adacrus__R);
  v_323 = (v_321&&v_322);
  if (v_323) {
    v_356 = Adacrus__T;
  } else {
    v_356 = v_355;
  };
  v_319 = (current_state==Adacrus__Rot180);
  v_318 = (last_oriented==Adacrus__T);
  v_320 = (v_318&&v_319);
  if (v_320) {
    v_357 = Adacrus__B;
  } else {
    v_357 = v_356;
  };
  v_316 = (current_state==Adacrus__RotR);
  v_315 = (last_oriented==Adacrus__T);
  v_317 = (v_315&&v_316);
  if (v_317) {
    v_358 = Adacrus__R;
  } else {
    v_358 = v_357;
  };
  v_313 = (current_state==Adacrus__RotL);
  v = (last_oriented==Adacrus__T);
  v_314 = (v&&v_313);
  if (v_314) {
    _out->new_orientation = Adacrus__L;
  } else {
    _out->new_orientation = v_358;
  };;
}

void Adacrus__getNextNodeAndState_reset(Adacrus__getNextNodeAndState_mem* self) {
  self->v_515 = true;
  self->v_505 = true;
  self->v_495 = true;
  self->v_485 = true;
  self->v_470 = true;
  self->v_386 = true;
}

void Adacrus__getNextNodeAndState_step(Adacrus__coordinates current_node,
                                       Adacrus__coordinates goal_node,
                                       Adacrus__orientation oriented,
                                       int ir_prox,
                                       Adacrus__getNextNodeAndState_out* _out,
                                       Adacrus__getNextNodeAndState_mem* self) {
  
  Adacrus__coordinates v_527;
  Adacrus__coordinates v_526;
  Adacrus__coordinates v_525;
  Adacrus__coordinates v_524;
  Adacrus__coordinates v_523;
  int v_522;
  int v_521;
  int v_520;
  int v_519;
  int v_518;
  int v_517;
  int v_514;
  Adacrus__coordinates v_513;
  int v_512;
  int v_511;
  int v_510;
  int v_509;
  int v_508;
  int v_507;
  int v_504;
  Adacrus__coordinates v_503;
  int v_502;
  int v_501;
  int v_500;
  int v_499;
  int v_498;
  int v_497;
  int v_494;
  Adacrus__coordinates v_493;
  int v_492;
  int v_491;
  int v_490;
  int v_489;
  int v_488;
  int v_487;
  int v_484;
  int v_483;
  int v_482;
  int v_481;
  int v_480;
  int v_479;
  Adacrus__states v_478;
  int v_477;
  int v_476;
  int v_475;
  int v_474;
  int v_473;
  int v_472;
  int v_469;
  Adacrus__states v_468;
  Adacrus__states v_467;
  Adacrus__states v_466;
  Adacrus__states v_465;
  Adacrus__states v_464;
  Adacrus__states v_463;
  Adacrus__states v_462;
  Adacrus__states v_461;
  Adacrus__states v_460;
  Adacrus__states v_459;
  Adacrus__states v_458;
  Adacrus__states v_457;
  Adacrus__states v_456;
  Adacrus__states v_455;
  Adacrus__states v_454;
  int v_453;
  int v_452;
  int v_451;
  int v_450;
  int v_449;
  int v_448;
  int v_447;
  int v_446;
  int v_445;
  int v_444;
  int v_443;
  int v_442;
  int v_441;
  int v_440;
  int v_439;
  int v_438;
  int v_437;
  int v_436;
  int v_435;
  int v_434;
  int v_433;
  int v_432;
  int v_431;
  int v_430;
  int v_429;
  int v_428;
  int v_427;
  int v_426;
  int v_425;
  int v_424;
  int v_423;
  int v_422;
  int v_421;
  int v_420;
  int v_419;
  int v_418;
  int v_417;
  int v_416;
  int v_415;
  int v_414;
  int v_413;
  int v_412;
  int v_411;
  int v_410;
  int v_409;
  int v_408;
  int v_407;
  int v_406;
  int v_405;
  int v_404;
  int v_403;
  int v_402;
  int v_401;
  int v_400;
  int v_399;
  int v_398;
  int v_397;
  int v_396;
  int v_395;
  int v_394;
  int v_393;
  int v_392;
  int v_391;
  int v_390;
  int v_389;
  int v_388;
  int v_385;
  Adacrus__coordinates v_384;
  Adacrus__coordinates v_383;
  Adacrus__coordinates v_382;
  Adacrus__coordinates v_381;
  int v_380;
  int v_379;
  int v_378;
  int v_377;
  Adacrus__coordinates v_376;
  int v_375;
  int v_374;
  int v_373;
  int v_372;
  Adacrus__coordinates v_371;
  int v_370;
  int v_369;
  int v_368;
  int v_367;
  Adacrus__coordinates v_366;
  int v_365;
  int v_364;
  int v_363;
  int v_362;
  int v_361;
  int v_360;
  int v_359;
  int v;
  int x_diff;
  int y_diff;
  int x_abs_diff;
  int y_abs_diff;
  int prox_count;
  Adacrus__coordinates inter_node;
  Adacrus__states inter_state;
  v_522 = (current_node.x+1);
  v_520 = (oriented==Adacrus__R);
  if (self->v_515) {
    v_517 = 0;
  } else {
    v_517 = self->v_516;
  };
  v_518 = (v_517>0);
  v_512 = (current_node.x-1);
  v_510 = (oriented==Adacrus__L);
  if (self->v_505) {
    v_507 = 0;
  } else {
    v_507 = self->v_506;
  };
  v_508 = (v_507>0);
  v_502 = (current_node.y-1);
  v_500 = (oriented==Adacrus__B);
  if (self->v_495) {
    v_497 = 0;
  } else {
    v_497 = self->v_496;
  };
  v_498 = (v_497>0);
  v_492 = (current_node.y+1);
  v_490 = (oriented==Adacrus__T);
  if (self->v_485) {
    v_487 = 0;
  } else {
    v_487 = self->v_486;
  };
  v_488 = (v_487>0);
  if (self->v_470) {
    v_472 = 0;
  } else {
    v_472 = self->v_471;
  };
  v_473 = (v_472>0);
  v_452 = (oriented==Adacrus__B);
  v_448 = (oriented==Adacrus__T);
  v_444 = (oriented==Adacrus__L);
  v_440 = (oriented==Adacrus__R);
  v_436 = (oriented==Adacrus__B);
  v_432 = (oriented==Adacrus__T);
  v_428 = (oriented==Adacrus__L);
  v_424 = (oriented==Adacrus__R);
  v_420 = (oriented==Adacrus__B);
  v_416 = (oriented==Adacrus__T);
  v_412 = (oriented==Adacrus__L);
  v_408 = (oriented==Adacrus__R);
  v_404 = (oriented==Adacrus__B);
  v_400 = (oriented==Adacrus__L);
  v_396 = (oriented==Adacrus__T);
  v_392 = (oriented==Adacrus__R);
  if (self->v_386) {
    v_388 = 0;
  } else {
    v_388 = self->v_387;
  };
  v_389 = (v_388+1);
  v_385 = (ir_prox<190);
  if (v_385) {
    prox_count = v_389;
  } else {
    prox_count = 0;
  };
  v_514 = (prox_count==0);
  v_519 = (v_514&&v_518);
  v_521 = (v_519&&v_520);
  v_504 = (prox_count==0);
  v_509 = (v_504&&v_508);
  v_511 = (v_509&&v_510);
  v_494 = (prox_count==0);
  v_499 = (v_494&&v_498);
  v_501 = (v_499&&v_500);
  v_484 = (prox_count==0);
  v_489 = (v_484&&v_488);
  v_491 = (v_489&&v_490);
  v_475 = (prox_count>0);
  v_469 = (prox_count==0);
  v_474 = (v_469&&v_473);
  v_380 = (current_node.x-1);
  v_375 = (current_node.x+1);
  v_370 = (current_node.y+1);
  v_365 = (current_node.y-1);
  y_diff = (goal_node.y-current_node.y);
  x_diff = (goal_node.x-current_node.x);
  v_378 = (x_diff<0);
  v_373 = (x_diff>0);
  v_368 = (y_diff>0);
  v_363 = (y_diff<0);
  v_361 = -(y_diff);
  v_360 = (y_diff<0);
  if (v_360) {
    y_abs_diff = v_361;
  } else {
    y_abs_diff = y_diff;
  };
  v_367 = (y_abs_diff>0);
  v_369 = (v_367&&v_368);
  v_362 = (y_abs_diff>0);
  v_364 = (v_362&&v_363);
  v_359 = -(x_diff);
  v = (x_diff<0);
  if (v) {
    x_abs_diff = v_359;
  } else {
    x_abs_diff = x_diff;
  };
  v_377 = (x_abs_diff>0);
  v_379 = (v_377&&v_378);
  v_372 = (x_abs_diff>0);
  v_374 = (v_372&&v_373);
  v_523 = current_node;
  v_523.x = v_522;
  v_513 = current_node;
  v_513.x = v_512;
  v_503 = current_node;
  v_503.y = v_502;
  v_493 = current_node;
  v_493.y = v_492;
  v_381 = current_node;
  v_381.x = v_380;
  if (v_379) {
    v_382 = v_381;
  } else {
    v_382 = current_node;
  };
  v_376 = current_node;
  v_376.x = v_375;
  if (v_374) {
    v_383 = v_376;
  } else {
    v_383 = v_382;
  };
  v_371 = current_node;
  v_371.y = v_370;
  if (v_369) {
    v_384 = v_371;
  } else {
    v_384 = v_383;
  };
  v_366 = current_node;
  v_366.y = v_365;
  if (v_364) {
    inter_node = v_366;
  } else {
    inter_node = v_384;
  };
  if (v_521) {
    v_524 = v_523;
  } else {
    v_524 = inter_node;
  };
  if (v_511) {
    v_525 = v_513;
  } else {
    v_525 = v_524;
  };
  if (v_501) {
    v_526 = v_503;
  } else {
    v_526 = v_525;
  };
  if (v_491) {
    v_527 = v_493;
  } else {
    v_527 = v_526;
  };
  v_450 = (inter_node.y-current_node.y);
  v_451 = (v_450==-1);
  v_453 = (v_451&&v_452);
  if (v_453) {
    v_454 = Adacrus__Moving;
  } else {
    v_454 = Adacrus__Exit;
  };
  v_446 = (inter_node.y-current_node.y);
  v_447 = (v_446==-1);
  v_449 = (v_447&&v_448);
  if (v_449) {
    v_455 = Adacrus__Rot180;
  } else {
    v_455 = v_454;
  };
  v_442 = (inter_node.y-current_node.y);
  v_443 = (v_442==-1);
  v_445 = (v_443&&v_444);
  if (v_445) {
    v_456 = Adacrus__RotL;
  } else {
    v_456 = v_455;
  };
  v_438 = (inter_node.y-current_node.y);
  v_439 = (v_438==-1);
  v_441 = (v_439&&v_440);
  if (v_441) {
    v_457 = Adacrus__RotR;
  } else {
    v_457 = v_456;
  };
  v_434 = (inter_node.y-current_node.y);
  v_435 = (v_434==1);
  v_437 = (v_435&&v_436);
  if (v_437) {
    v_458 = Adacrus__Rot180;
  } else {
    v_458 = v_457;
  };
  v_430 = (inter_node.y-current_node.y);
  v_431 = (v_430==1);
  v_433 = (v_431&&v_432);
  if (v_433) {
    v_459 = Adacrus__Moving;
  } else {
    v_459 = v_458;
  };
  v_426 = (inter_node.y-current_node.y);
  v_427 = (v_426==1);
  v_429 = (v_427&&v_428);
  if (v_429) {
    v_460 = Adacrus__RotR;
  } else {
    v_460 = v_459;
  };
  v_422 = (inter_node.y-current_node.y);
  v_423 = (v_422==1);
  v_425 = (v_423&&v_424);
  if (v_425) {
    v_461 = Adacrus__RotL;
  } else {
    v_461 = v_460;
  };
  v_418 = (inter_node.x-current_node.x);
  v_419 = (v_418==-1);
  v_421 = (v_419&&v_420);
  if (v_421) {
    v_462 = Adacrus__RotR;
  } else {
    v_462 = v_461;
  };
  v_414 = (inter_node.x-current_node.x);
  v_415 = (v_414==-1);
  v_417 = (v_415&&v_416);
  if (v_417) {
    v_463 = Adacrus__RotL;
  } else {
    v_463 = v_462;
  };
  v_410 = (inter_node.x-current_node.x);
  v_411 = (v_410==-1);
  v_413 = (v_411&&v_412);
  if (v_413) {
    v_464 = Adacrus__Moving;
  } else {
    v_464 = v_463;
  };
  v_406 = (inter_node.x-current_node.x);
  v_407 = (v_406==-1);
  v_409 = (v_407&&v_408);
  if (v_409) {
    v_465 = Adacrus__Rot180;
  } else {
    v_465 = v_464;
  };
  v_402 = (inter_node.x-current_node.x);
  v_403 = (v_402==1);
  v_405 = (v_403&&v_404);
  if (v_405) {
    v_466 = Adacrus__RotL;
  } else {
    v_466 = v_465;
  };
  v_398 = (inter_node.x-current_node.x);
  v_399 = (v_398==1);
  v_401 = (v_399&&v_400);
  if (v_401) {
    v_467 = Adacrus__Rot180;
  } else {
    v_467 = v_466;
  };
  v_394 = (inter_node.x-current_node.x);
  v_390 = (inter_node.x-current_node.x);
  v_395 = (v_394==1);
  v_397 = (v_395&&v_396);
  if (v_397) {
    v_468 = Adacrus__RotR;
  } else {
    v_468 = v_467;
  };
  v_391 = (v_390==1);
  v_393 = (v_391&&v_392);
  if (v_393) {
    inter_state = Adacrus__Moving;
  } else {
    inter_state = v_468;
  };
  v_476 = (inter_state==Adacrus__Moving);
  v_477 = (v_475&&v_476);
  if (v_477) {
    v_478 = Adacrus__RotR;
  } else {
    v_478 = inter_state;
  };
  if (v_474) {
    _out->next_state = Adacrus__Moving;
  } else {
    _out->next_state = v_478;
  };
  v_482 = (_out->next_state==Adacrus__Rot180);
  v_480 = (_out->next_state==Adacrus__RotL);
  v_479 = (_out->next_state==Adacrus__RotR);
  v_481 = (v_479||v_480);
  v_483 = (v_481||v_482);
  if (v_483) {
    _out->next_node = current_node;
  } else {
    _out->next_node = v_527;
  };
  self->v_516 = prox_count;
  self->v_515 = false;
  self->v_506 = prox_count;
  self->v_505 = false;
  self->v_496 = prox_count;
  self->v_495 = false;
  self->v_486 = prox_count;
  self->v_485 = false;
  self->v_471 = prox_count;
  self->v_470 = false;
  self->v_387 = prox_count;
  self->v_386 = false;;
}

void Adacrus__decideAction_reset(Adacrus__decideAction_mem* self) {
  Adacrus__getNextNodeAndState_reset(&self->getNextNodeAndState_1);
  Adacrus__getNextNodeAndState_reset(&self->getNextNodeAndState);
  self->v_535 = true;
  self->v_529 = true;
}

void Adacrus__decideAction_step(Adacrus__coordinates current_node,
                                Adacrus__states last_state,
                                Adacrus__orientation oriented, int ir_prox,
                                Adacrus__decideAction_out* _out,
                                Adacrus__decideAction_mem* self) {
  Adacrus__getNextNodeAndState_out Adacrus__getNextNodeAndState_out_st;
  
  Adacrus__states v_543;
  Adacrus__coordinates v_542;
  Adacrus__coordinates v_541;
  Adacrus__states v_540;
  Adacrus__coordinates v_539;
  Adacrus__states v_538;
  Adacrus__coordinates v_537;
  int v_536;
  int v_534;
  int v_533;
  int v_532;
  int v_531;
  int v_528;
  int v;
  int is_goal;
  int start_reached;
  v_532 = (current_node.y==Adacrus__start.y);
  v_531 = (current_node.x==Adacrus__start.x);
  v_533 = (v_531&&v_532);
  if (self->v_530) {
    v_534 = true;
  } else {
    v_534 = v_533;
  };
  if (self->v_529) {
    start_reached = false;
  } else {
    start_reached = v_534;
  };
  v_536 = !(start_reached);
  v_528 = (current_node.y==Adacrus__goal.y);
  v = (current_node.x==Adacrus__goal.x);
  is_goal = (v&&v_528);
  v_541.y = 1;
  v_541.x = 4;
  Adacrus__getNextNodeAndState_step(current_node, Adacrus__goal, oriented,
                                    ir_prox,
                                    &Adacrus__getNextNodeAndState_out_st,
                                    &self->getNextNodeAndState_1);
  v_539 = Adacrus__getNextNodeAndState_out_st.next_node;
  v_540 = Adacrus__getNextNodeAndState_out_st.next_state;
  Adacrus__getNextNodeAndState_step(current_node, Adacrus__start, oriented,
                                    ir_prox,
                                    &Adacrus__getNextNodeAndState_out_st,
                                    &self->getNextNodeAndState);
  v_537 = Adacrus__getNextNodeAndState_out_st.next_node;
  v_538 = Adacrus__getNextNodeAndState_out_st.next_state;
  if (v_536) {
    v_542 = v_537;
  } else {
    v_542 = v_539;
  };
  if (self->v_535) {
    _out->next_node = v_541;
  } else {
    _out->next_node = v_542;
  };
  if (v_536) {
    v_543 = v_538;
  } else {
    v_543 = v_540;
  };
  if (self->v_535) {
    _out->next_state = Adacrus__RotL;
  } else {
    _out->next_state = v_543;
  };
  self->v_535 = false;
  self->v_530 = start_reached;
  self->v_529 = false;;
}

void Adacrus__adacrus_params_35__reset(Adacrus__adacrus_params_35__mem* self) {
  Adacrus__moveAut_reset(&self->moveAut_5);
  Adacrus__isNode_reset(&self->isNode);
  Adacrus__moveAut_reset(&self->moveAut_1);
  Adacrus__moveAut_reset(&self->moveAut_2);
  Adacrus__moveAut_reset(&self->moveAut_3);
  Adacrus__moveAut_reset(&self->moveAut_4);
  Adacrus__moveAut_reset(&self->moveAut);
  Adacrus__isAllWhite_reset(&self->isAllWhite_2);
  Adacrus__isLine_reset(&self->isLine_4);
  Adacrus__isAllWhite_reset(&self->isAllWhite);
  Adacrus__isLine_reset(&self->isLine_3);
  Adacrus__isLine_reset(&self->isLine_2);
  Adacrus__isLine_reset(&self->isLine);
  Adacrus__decideAction_reset(&self->decideAction);
  self->debug_state_1 = Adacrus__Initial;
  self->current_state_2 = Adacrus__Initial;
  self->oriented_4 = Adacrus__T;
  self->next_node_5.y = 1;
  self->next_node_5.x = 3;
  self->pnr_7 = false;
  self->v_641 = true;
  self->v_634 = false;
  self->v_633 = false;
  self->v_632 = Adacrus__St_5_Decidado;
  self->v_613 = false;
  self->v_612 = false;
  self->v_611 = Adacrus__St_6_GoAhead;
  self->v_590 = false;
  self->v_589 = false;
  self->v_588 = Adacrus__St_7_GoAhead;
  self->v_567 = false;
  self->v_566 = false;
  self->v_565 = Adacrus__St_8_GoAhead;
  self->v_606 = true;
  self->v_600 = true;
  self->v_594 = true;
  self->v_583 = true;
  self->v_577 = true;
  self->v_571 = true;
  self->v_560 = true;
  self->v_554 = true;
  self->v_546 = true;
  self->ck = Adacrus__St_9_Initial;
}

void Adacrus__adacrus_params_35__step(int left_wl, int center_wl,
                                      int right_wl, int ir_prox,
                                      Adacrus__adacrus_params_35__out* _out,
                                      Adacrus__adacrus_params_35__mem* self) {
  Adacrus__halt_out Adacrus__halt_out_st;
  Adacrus__calcOrientation_out Adacrus__calcOrientation_out_st;
  Adacrus__isLine_out Adacrus__isLine_out_st;
  Adacrus__notIsNode_out Adacrus__notIsNode_out_st;
  Adacrus__isAllWhite_out Adacrus__isAllWhite_out_st;
  Adacrus__isNode_out Adacrus__isNode_out_st;
  Adacrus__moveAut_out Adacrus__moveAut_out_st;
  Adacrus__decideAction_out Adacrus__decideAction_out_st;
  
  int v_550;
  int v_548;
  int v_547;
  int v_545;
  int v_544;
  int v;
  int r_15;
  int t_right_again;
  int v_558;
  int v_556;
  int v_555;
  int v_553;
  int v_552;
  int v_551;
  int r_16;
  int t_right_2;
  int v_564;
  int v_562;
  int v_561;
  int v_559;
  int t_forward_2;
  int nr_6_St_8_Exit;
  Adacrus__st_8 ns_6_St_8_Exit;
  int exit_3_St_8_Exit;
  Adacrus__states debug_state_St_9_Rot180_St_8_Exit;
  Adacrus__direction dir_St_9_Rot180_St_8_Exit;
  int v_r_St_9_Rot180_St_8_Exit;
  int v_l_St_9_Rot180_St_8_Exit;
  int nr_6_St_8_TurnRightAgain;
  Adacrus__st_8 ns_6_St_8_TurnRightAgain;
  int exit_3_St_8_TurnRightAgain;
  Adacrus__states debug_state_St_9_Rot180_St_8_TurnRightAgain;
  Adacrus__direction dir_St_9_Rot180_St_8_TurnRightAgain;
  int v_r_St_9_Rot180_St_8_TurnRightAgain;
  int v_l_St_9_Rot180_St_8_TurnRightAgain;
  int nr_6_St_8_TurnRight;
  Adacrus__st_8 ns_6_St_8_TurnRight;
  int exit_3_St_8_TurnRight;
  Adacrus__states debug_state_St_9_Rot180_St_8_TurnRight;
  Adacrus__direction dir_St_9_Rot180_St_8_TurnRight;
  int v_r_St_9_Rot180_St_8_TurnRight;
  int v_l_St_9_Rot180_St_8_TurnRight;
  int nr_6_St_8_GoAhead;
  Adacrus__st_8 ns_6_St_8_GoAhead;
  int exit_3_St_8_GoAhead;
  Adacrus__states debug_state_St_9_Rot180_St_8_GoAhead;
  Adacrus__direction dir_St_9_Rot180_St_8_GoAhead;
  int v_r_St_9_Rot180_St_8_GoAhead;
  int v_l_St_9_Rot180_St_8_GoAhead;
  Adacrus__st_8 ck_7;
  Adacrus__st_8 ns_6;
  int r_6;
  int nr_6;
  int pnr_6;
  int exit_3_1;
  int exit_3;
  int v_575;
  int v_573;
  int v_572;
  int v_570;
  int v_569;
  int v_568;
  int r_17;
  int t_right_1;
  int v_581;
  int v_579;
  int v_578;
  int v_576;
  int r_18;
  int t_right;
  int v_587;
  int v_585;
  int v_584;
  int v_582;
  int t_forward_1;
  int nr_5_St_7_Exit;
  Adacrus__st_7 ns_5_St_7_Exit;
  int exit_2_St_7_Exit;
  Adacrus__states debug_state_St_9_RotR_St_7_Exit;
  Adacrus__direction dir_St_9_RotR_St_7_Exit;
  int v_r_St_9_RotR_St_7_Exit;
  int v_l_St_9_RotR_St_7_Exit;
  int nr_5_St_7_TurnRight;
  Adacrus__st_7 ns_5_St_7_TurnRight;
  int exit_2_St_7_TurnRight;
  Adacrus__states debug_state_St_9_RotR_St_7_TurnRight;
  Adacrus__direction dir_St_9_RotR_St_7_TurnRight;
  int v_r_St_9_RotR_St_7_TurnRight;
  int v_l_St_9_RotR_St_7_TurnRight;
  int nr_5_St_7_BlackToWhite;
  Adacrus__st_7 ns_5_St_7_BlackToWhite;
  int exit_2_St_7_BlackToWhite;
  Adacrus__states debug_state_St_9_RotR_St_7_BlackToWhite;
  Adacrus__direction dir_St_9_RotR_St_7_BlackToWhite;
  int v_r_St_9_RotR_St_7_BlackToWhite;
  int v_l_St_9_RotR_St_7_BlackToWhite;
  int nr_5_St_7_GoAhead;
  Adacrus__st_7 ns_5_St_7_GoAhead;
  int exit_2_St_7_GoAhead;
  Adacrus__states debug_state_St_9_RotR_St_7_GoAhead;
  Adacrus__direction dir_St_9_RotR_St_7_GoAhead;
  int v_r_St_9_RotR_St_7_GoAhead;
  int v_l_St_9_RotR_St_7_GoAhead;
  Adacrus__st_7 ck_6;
  Adacrus__st_7 ns_5;
  int r_5;
  int nr_5;
  int pnr_5;
  int exit_2_1;
  int exit_2;
  int v_598;
  int v_596;
  int v_595;
  int v_593;
  int v_592;
  int v_591;
  int r_19;
  int t_left_1;
  int v_604;
  int v_602;
  int v_601;
  int v_599;
  int r_20;
  int t_left;
  int v_610;
  int v_608;
  int v_607;
  int v_605;
  int t_forward;
  int nr_4_St_6_Exit;
  Adacrus__st_6 ns_4_St_6_Exit;
  int exit_1_St_6_Exit;
  Adacrus__states debug_state_St_9_RotL_St_6_Exit;
  Adacrus__direction dir_St_9_RotL_St_6_Exit;
  int v_r_St_9_RotL_St_6_Exit;
  int v_l_St_9_RotL_St_6_Exit;
  int nr_4_St_6_TurnLeft;
  Adacrus__st_6 ns_4_St_6_TurnLeft;
  int exit_1_St_6_TurnLeft;
  Adacrus__states debug_state_St_9_RotL_St_6_TurnLeft;
  Adacrus__direction dir_St_9_RotL_St_6_TurnLeft;
  int v_r_St_9_RotL_St_6_TurnLeft;
  int v_l_St_9_RotL_St_6_TurnLeft;
  int nr_4_St_6_BlackToWhite;
  Adacrus__st_6 ns_4_St_6_BlackToWhite;
  int exit_1_St_6_BlackToWhite;
  Adacrus__states debug_state_St_9_RotL_St_6_BlackToWhite;
  Adacrus__direction dir_St_9_RotL_St_6_BlackToWhite;
  int v_r_St_9_RotL_St_6_BlackToWhite;
  int v_l_St_9_RotL_St_6_BlackToWhite;
  int nr_4_St_6_GoAhead;
  Adacrus__st_6 ns_4_St_6_GoAhead;
  int exit_1_St_6_GoAhead;
  Adacrus__states debug_state_St_9_RotL_St_6_GoAhead;
  Adacrus__direction dir_St_9_RotL_St_6_GoAhead;
  int v_r_St_9_RotL_St_6_GoAhead;
  int v_l_St_9_RotL_St_6_GoAhead;
  Adacrus__st_6 ck_5;
  Adacrus__st_6 ns_4;
  int r_4;
  int nr_4;
  int pnr_4;
  int exit_1_1;
  int exit_1;
  int r_21;
  int r_22;
  int nr_St_5_LeaveNode;
  Adacrus__st_5 ns_St_5_LeaveNode;
  Adacrus__states next_state_St_5_LeaveNode;
  int out_of_node_St_5_LeaveNode;
  Adacrus__states debug_state_St_9_DecideAction_St_5_LeaveNode;
  Adacrus__orientation oriented_St_9_DecideAction_St_5_LeaveNode;
  Adacrus__coordinates next_node_St_9_DecideAction_St_5_LeaveNode;
  Adacrus__direction dir_St_9_DecideAction_St_5_LeaveNode;
  int v_r_St_9_DecideAction_St_5_LeaveNode;
  int v_l_St_9_DecideAction_St_5_LeaveNode;
  int nr_St_5_Decidado;
  Adacrus__st_5 ns_St_5_Decidado;
  Adacrus__states next_state_St_5_Decidado;
  int out_of_node_St_5_Decidado;
  Adacrus__states debug_state_St_9_DecideAction_St_5_Decidado;
  Adacrus__orientation oriented_St_9_DecideAction_St_5_Decidado;
  Adacrus__coordinates next_node_St_9_DecideAction_St_5_Decidado;
  Adacrus__direction dir_St_9_DecideAction_St_5_Decidado;
  int v_r_St_9_DecideAction_St_5_Decidado;
  int v_l_St_9_DecideAction_St_5_Decidado;
  Adacrus__st_5 ck_4;
  int v_631;
  Adacrus__st_9 v_630;
  int v_629;
  Adacrus__st_9 v_628;
  int v_627;
  Adacrus__st_9 v_626;
  int v_625;
  Adacrus__st_9 v_624;
  int v_623;
  int v_622;
  int v_621;
  int v_620;
  int v_619;
  int v_618;
  int v_617;
  int v_616;
  int v_615;
  int v_614;
  Adacrus__st_5 ns;
  int r;
  int nr;
  int pnr;
  int out_of_node_1;
  int out_of_node;
  Adacrus__states next_state;
  int v_674;
  int v_673;
  int v_672;
  int v_671;
  int v_670;
  int v_669;
  int v_668;
  int v_667;
  int v_666;
  int v_665;
  int v_664;
  int v_663;
  int v_662;
  int v_661;
  int v_660;
  int v_659;
  int v_658;
  int v_657;
  int v_656;
  int v_655;
  int v_654;
  int v_653;
  int v_652;
  int v_651;
  int v_650;
  int v_649;
  int v_648;
  int v_647;
  int v_646;
  int v_645;
  int v_644;
  int v_642;
  int v_640;
  int v_639;
  int v_638;
  int v_637;
  int v_636;
  int v_635;
  int r_27;
  int r_26;
  int r_25;
  int r_24;
  int r_23;
  int inverted_section;
  int exit;
  int inverted_t;
  int v_675;
  int r_28;
  int nr_7_St_9_Rot180;
  Adacrus__st_9 ns_7_St_9_Rot180;
  Adacrus__states debug_state_St_9_Rot180;
  Adacrus__states current_state_St_9_Rot180;
  Adacrus__orientation oriented_St_9_Rot180;
  Adacrus__coordinates next_node_St_9_Rot180;
  Adacrus__direction dir_St_9_Rot180;
  int v_r_St_9_Rot180;
  int v_l_St_9_Rot180;
  int nr_7_St_9_RotR;
  Adacrus__st_9 ns_7_St_9_RotR;
  Adacrus__states debug_state_St_9_RotR;
  Adacrus__states current_state_St_9_RotR;
  Adacrus__orientation oriented_St_9_RotR;
  Adacrus__coordinates next_node_St_9_RotR;
  Adacrus__direction dir_St_9_RotR;
  int v_r_St_9_RotR;
  int v_l_St_9_RotR;
  int nr_7_St_9_RotL;
  Adacrus__st_9 ns_7_St_9_RotL;
  Adacrus__states debug_state_St_9_RotL;
  Adacrus__states current_state_St_9_RotL;
  Adacrus__orientation oriented_St_9_RotL;
  Adacrus__coordinates next_node_St_9_RotL;
  Adacrus__direction dir_St_9_RotL;
  int v_r_St_9_RotL;
  int v_l_St_9_RotL;
  int nr_7_St_9_DecideAction;
  Adacrus__st_9 ns_7_St_9_DecideAction;
  Adacrus__states debug_state_St_9_DecideAction;
  Adacrus__states current_state_St_9_DecideAction;
  Adacrus__orientation oriented_St_9_DecideAction;
  Adacrus__coordinates next_node_St_9_DecideAction;
  Adacrus__direction dir_St_9_DecideAction;
  int v_r_St_9_DecideAction;
  int v_l_St_9_DecideAction;
  int nr_7_St_9_Exit;
  Adacrus__st_9 ns_7_St_9_Exit;
  Adacrus__states debug_state_St_9_Exit;
  Adacrus__states current_state_St_9_Exit;
  Adacrus__orientation oriented_St_9_Exit;
  Adacrus__coordinates next_node_St_9_Exit;
  Adacrus__direction dir_St_9_Exit;
  int v_r_St_9_Exit;
  int v_l_St_9_Exit;
  int nr_7_St_9_Moving;
  Adacrus__st_9 ns_7_St_9_Moving;
  Adacrus__states debug_state_St_9_Moving;
  Adacrus__states current_state_St_9_Moving;
  Adacrus__orientation oriented_St_9_Moving;
  Adacrus__coordinates next_node_St_9_Moving;
  Adacrus__direction dir_St_9_Moving;
  int v_r_St_9_Moving;
  int v_l_St_9_Moving;
  int nr_7_St_9_Initial;
  Adacrus__st_9 ns_7_St_9_Initial;
  Adacrus__states debug_state_St_9_Initial;
  Adacrus__states current_state_St_9_Initial;
  Adacrus__orientation oriented_St_9_Initial;
  Adacrus__coordinates next_node_St_9_Initial;
  Adacrus__direction dir_St_9_Initial;
  int v_r_St_9_Initial;
  int v_l_St_9_Initial;
  Adacrus__st_9 ns_7;
  int r_7;
  int nr_7;
  Adacrus__coordinates next_node;
  Adacrus__orientation oriented;
  Adacrus__states current_state;
  Adacrus__states debug_state;
  r_7 = self->pnr_7;
  switch (self->ck) {
    case Adacrus__St_9_Initial:
      oriented_St_9_Initial = self->oriented_4;
      current_state_St_9_Initial = Adacrus__Initial;
      dir_St_9_Initial = Adacrus__Forward;
      Adacrus__notIsNode_step(left_wl, center_wl, right_wl,
                              &Adacrus__notIsNode_out_st);
      v_675 = Adacrus__notIsNode_out_st.out;
      if (v_675) {
        nr_7_St_9_Initial = true;
        ns_7_St_9_Initial = Adacrus__St_9_Moving;
      } else {
        nr_7_St_9_Initial = false;
        ns_7_St_9_Initial = Adacrus__St_9_Initial;
      };
      r_28 = r_7;
      if (r_28) {
        Adacrus__moveAut_reset(&self->moveAut_5);
      };
      Adacrus__moveAut_step(left_wl, center_wl, right_wl, false, false,
                            false, false, &Adacrus__moveAut_out_st,
                            &self->moveAut_5);
      v_l_St_9_Initial = Adacrus__moveAut_out_st.v_l;
      v_r_St_9_Initial = Adacrus__moveAut_out_st.v_r;
      current_state = current_state_St_9_Initial;
      debug_state_St_9_Initial = current_state;
      oriented = oriented_St_9_Initial;
      _out->dir = dir_St_9_Initial;
      debug_state = debug_state_St_9_Initial;
      break;
    case Adacrus__St_9_Moving:
      oriented_St_9_Moving = self->oriented_4;
      current_state_St_9_Moving = Adacrus__Moving;
      dir_St_9_Moving = Adacrus__Forward;
      v_644 = (self->v_643+1);
      if (self->v_641) {
        v_642 = true;
      } else {
        v_642 = r_7;
      };
      if (v_642) {
        inverted_t = 0;
      } else {
        inverted_t = v_644;
      };
      v_645 = (inverted_t<200);
      r_23 = r_7;
      if (r_23) {
        Adacrus__isNode_reset(&self->isNode);
      };
      Adacrus__isNode_step(left_wl, center_wl, right_wl, 15,
                           &Adacrus__isNode_out_st, &self->isNode);
      v_647 = Adacrus__isNode_out_st.out;
      r_24 = r_7;
      if (r_24) {
        Adacrus__moveAut_reset(&self->moveAut_1);
      };
      Adacrus__moveAut_step(left_wl, center_wl, right_wl, true, false, false,
                            false, &Adacrus__moveAut_out_st, &self->moveAut_1);
      v_655 = Adacrus__moveAut_out_st.v_l;
      v_656 = Adacrus__moveAut_out_st.v_r;
      r_25 = r_7;
      if (r_25) {
        Adacrus__moveAut_reset(&self->moveAut_2);
      };
      Adacrus__moveAut_step(left_wl, center_wl, right_wl, false, false, true,
                            false, &Adacrus__moveAut_out_st, &self->moveAut_2);
      v_660 = Adacrus__moveAut_out_st.v_l;
      v_661 = Adacrus__moveAut_out_st.v_r;
      r_26 = r_7;
      if (r_26) {
        Adacrus__moveAut_reset(&self->moveAut_3);
      };
      Adacrus__moveAut_step(left_wl, center_wl, right_wl, false, false,
                            false, true, &Adacrus__moveAut_out_st,
                            &self->moveAut_3);
      v_665 = Adacrus__moveAut_out_st.v_l;
      v_666 = Adacrus__moveAut_out_st.v_r;
      r_27 = r_7;
      if (r_27) {
        Adacrus__moveAut_reset(&self->moveAut_4);
      };
      Adacrus__moveAut_step(left_wl, center_wl, right_wl, false, false,
                            false, false, &Adacrus__moveAut_out_st,
                            &self->moveAut_4);
      v_667 = Adacrus__moveAut_out_st.v_l;
      v_668 = Adacrus__moveAut_out_st.v_r;
      current_state = current_state_St_9_Moving;
      debug_state_St_9_Moving = current_state;
      oriented = oriented_St_9_Moving;
      v_662 = (oriented==Adacrus__B);
      v_657 = (oriented==Adacrus__T);
      v_651 = (oriented==Adacrus__B);
      v_648 = (oriented==Adacrus__T);
      v_638 = (oriented==Adacrus__B);
      v_635 = (oriented==Adacrus__T);
      _out->dir = dir_St_9_Moving;
      debug_state = debug_state_St_9_Moving;
      break;
    case Adacrus__St_9_Exit:
      oriented_St_9_Exit = self->oriented_4;
      current_state_St_9_Exit = Adacrus__Exit;
      Adacrus__halt_step(&Adacrus__halt_out_st);
      v_l_St_9_Exit = Adacrus__halt_out_st.v_l;
      v_r_St_9_Exit = Adacrus__halt_out_st.v_r;
      dir_St_9_Exit = Adacrus__halt_out_st.dir;
      if (false) {
        nr_7_St_9_Exit = true;
      } else {
        nr_7_St_9_Exit = false;
      };
      if (false) {
        ns_7_St_9_Exit = Adacrus__St_9_Exit;
      } else {
        ns_7_St_9_Exit = Adacrus__St_9_Exit;
      };
      current_state = current_state_St_9_Exit;
      debug_state_St_9_Exit = current_state;
      oriented = oriented_St_9_Exit;
      _out->dir = dir_St_9_Exit;
      debug_state = debug_state_St_9_Exit;
      break;
    case Adacrus__St_9_DecideAction:
      if (r_7) {
        out_of_node_1 = false;
      } else {
        out_of_node_1 = self->v_634;
      };
      current_state_St_9_DecideAction = self->current_state_2;
      if (r_7) {
        pnr = false;
      } else {
        pnr = self->v_633;
      };
      r = pnr;
      if (r_7) {
        ck_4 = Adacrus__St_5_Decidado;
      } else {
        ck_4 = self->v_632;
      };
      current_state = current_state_St_9_DecideAction;
      switch (ck_4) {
        case Adacrus__St_5_Decidado:
          out_of_node_St_5_Decidado = false;
          debug_state_St_9_DecideAction_St_5_Decidado = Adacrus__Decidado;
          Adacrus__calcOrientation_step(self->current_state_2,
                                        self->oriented_4,
                                        &Adacrus__calcOrientation_out_st);
          oriented_St_9_DecideAction_St_5_Decidado = Adacrus__calcOrientation_out_st.new_orientation;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_9_DecideAction_St_5_Decidado = Adacrus__halt_out_st.v_l;
          v_r_St_9_DecideAction_St_5_Decidado = Adacrus__halt_out_st.v_r;
          dir_St_9_DecideAction_St_5_Decidado = Adacrus__halt_out_st.dir;
          if (true) {
            nr_St_5_Decidado = true;
          } else {
            nr_St_5_Decidado = false;
          };
          if (true) {
            ns_St_5_Decidado = Adacrus__St_5_LeaveNode;
          } else {
            ns_St_5_Decidado = Adacrus__St_5_Decidado;
          };
          r_22 = (r_7||r);
          v_l_St_9_DecideAction = v_l_St_9_DecideAction_St_5_Decidado;
          v_r_St_9_DecideAction = v_r_St_9_DecideAction_St_5_Decidado;
          dir_St_9_DecideAction = dir_St_9_DecideAction_St_5_Decidado;
          oriented_St_9_DecideAction = oriented_St_9_DecideAction_St_5_Decidado;
          debug_state_St_9_DecideAction = debug_state_St_9_DecideAction_St_5_Decidado;
          out_of_node = out_of_node_St_5_Decidado;
          ns = ns_St_5_Decidado;
          nr = nr_St_5_Decidado;
          break;
        case Adacrus__St_5_LeaveNode:
          next_state_St_5_LeaveNode = self->next_state_4;
          oriented_St_9_DecideAction_St_5_LeaveNode = self->oriented_4;
          Adacrus__notIsNode_step(left_wl, center_wl, right_wl,
                                  &Adacrus__notIsNode_out_st);
          out_of_node_St_5_LeaveNode = Adacrus__notIsNode_out_st.out;
          debug_state_St_9_DecideAction_St_5_LeaveNode = Adacrus__LeaveNode;
          dir_St_9_DecideAction_St_5_LeaveNode = Adacrus__Forward;
          r_21 = (r_7||r);
          if (r_21) {
            Adacrus__moveAut_reset(&self->moveAut);
          };
          Adacrus__moveAut_step(left_wl, center_wl, right_wl, false, false,
                                false, false, &Adacrus__moveAut_out_st,
                                &self->moveAut);
          v_l_St_9_DecideAction_St_5_LeaveNode = Adacrus__moveAut_out_st.v_l;
          v_r_St_9_DecideAction_St_5_LeaveNode = Adacrus__moveAut_out_st.v_r;
          v_l_St_9_DecideAction = v_l_St_9_DecideAction_St_5_LeaveNode;
          v_r_St_9_DecideAction = v_r_St_9_DecideAction_St_5_LeaveNode;
          dir_St_9_DecideAction = dir_St_9_DecideAction_St_5_LeaveNode;
          oriented_St_9_DecideAction = oriented_St_9_DecideAction_St_5_LeaveNode;
          debug_state_St_9_DecideAction = debug_state_St_9_DecideAction_St_5_LeaveNode;
          out_of_node = out_of_node_St_5_LeaveNode;
          if (out_of_node) {
            nr_St_5_LeaveNode = false;
            ns_St_5_LeaveNode = Adacrus__St_5_Decidado;
          } else {
            nr_St_5_LeaveNode = false;
            ns_St_5_LeaveNode = Adacrus__St_5_LeaveNode;
          };
          ns = ns_St_5_LeaveNode;
          nr = nr_St_5_LeaveNode;
          break;
        default:
          break;
      };
      oriented = oriented_St_9_DecideAction;
      _out->dir = dir_St_9_DecideAction;
      debug_state = debug_state_St_9_DecideAction;
      break;
    case Adacrus__St_9_RotL:
      if (r_7) {
        exit_1_1 = false;
      } else {
        exit_1_1 = self->v_613;
      };
      oriented_St_9_RotL = self->oriented_4;
      if (r_7) {
        pnr_4 = false;
      } else {
        pnr_4 = self->v_612;
      };
      r_4 = pnr_4;
      if (r_7) {
        ck_5 = Adacrus__St_6_GoAhead;
      } else {
        ck_5 = self->v_611;
      };
      current_state_St_9_RotL = Adacrus__RotL;
      current_state = current_state_St_9_RotL;
      switch (ck_5) {
        case Adacrus__St_6_GoAhead:
          exit_1_St_6_GoAhead = exit_1_1;
          debug_state_St_9_RotL_St_6_GoAhead = Adacrus__GoAhead;
          v_610 = (self->v_609+1);
          v_607 = (r_7||r_4);
          if (self->v_606) {
            v_608 = true;
          } else {
            v_608 = v_607;
          };
          if (v_608) {
            t_forward = 0;
          } else {
            t_forward = v_610;
          };
          dir_St_9_RotL_St_6_GoAhead = Adacrus__Forward;
          v_r_St_9_RotL_St_6_GoAhead = 200;
          v_l_St_9_RotL_St_6_GoAhead = 200;
          v_605 = (t_forward>35);
          if (v_605) {
            nr_4_St_6_GoAhead = true;
            ns_4_St_6_GoAhead = Adacrus__St_6_TurnLeft;
          } else {
            nr_4_St_6_GoAhead = false;
            ns_4_St_6_GoAhead = Adacrus__St_6_GoAhead;
          };
          v_l_St_9_RotL = v_l_St_9_RotL_St_6_GoAhead;
          v_r_St_9_RotL = v_r_St_9_RotL_St_6_GoAhead;
          dir_St_9_RotL = dir_St_9_RotL_St_6_GoAhead;
          debug_state_St_9_RotL = debug_state_St_9_RotL_St_6_GoAhead;
          exit_1 = exit_1_St_6_GoAhead;
          ns_4 = ns_4_St_6_GoAhead;
          nr_4 = nr_4_St_6_GoAhead;
          break;
        case Adacrus__St_6_BlackToWhite:
          exit_1_St_6_BlackToWhite = exit_1_1;
          debug_state_St_9_RotL_St_6_BlackToWhite = Adacrus__BlackToWhite;
          v_604 = (self->v_603+1);
          v_601 = (r_7||r_4);
          if (self->v_600) {
            v_602 = true;
          } else {
            v_602 = v_601;
          };
          if (v_602) {
            t_left = 0;
          } else {
            t_left = v_604;
          };
          dir_St_9_RotL_St_6_BlackToWhite = Adacrus__Left;
          v_r_St_9_RotL_St_6_BlackToWhite = 100;
          v_l_St_9_RotL_St_6_BlackToWhite = -100;
          r_20 = (r_7||r_4);
          if (r_20) {
            Adacrus__isAllWhite_reset(&self->isAllWhite_2);
          };
          Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 40,
                                   &Adacrus__isAllWhite_out_st,
                                   &self->isAllWhite_2);
          v_599 = Adacrus__isAllWhite_out_st.out;
          if (v_599) {
            nr_4_St_6_BlackToWhite = true;
            ns_4_St_6_BlackToWhite = Adacrus__St_6_TurnLeft;
          } else {
            nr_4_St_6_BlackToWhite = false;
            ns_4_St_6_BlackToWhite = Adacrus__St_6_BlackToWhite;
          };
          v_l_St_9_RotL = v_l_St_9_RotL_St_6_BlackToWhite;
          v_r_St_9_RotL = v_r_St_9_RotL_St_6_BlackToWhite;
          dir_St_9_RotL = dir_St_9_RotL_St_6_BlackToWhite;
          debug_state_St_9_RotL = debug_state_St_9_RotL_St_6_BlackToWhite;
          exit_1 = exit_1_St_6_BlackToWhite;
          ns_4 = ns_4_St_6_BlackToWhite;
          nr_4 = nr_4_St_6_BlackToWhite;
          break;
        case Adacrus__St_6_TurnLeft:
          exit_1_St_6_TurnLeft = exit_1_1;
          debug_state_St_9_RotL_St_6_TurnLeft = Adacrus__TurnLeft;
          v_598 = (self->v_597+1);
          v_595 = (r_7||r_4);
          if (self->v_594) {
            v_596 = true;
          } else {
            v_596 = v_595;
          };
          if (v_596) {
            t_left_1 = 0;
          } else {
            t_left_1 = v_598;
          };
          dir_St_9_RotL_St_6_TurnLeft = Adacrus__Left;
          v_r_St_9_RotL_St_6_TurnLeft = 100;
          v_l_St_9_RotL_St_6_TurnLeft = -100;
          v_591 = (t_left_1>35);
          r_19 = (r_7||r_4);
          if (r_19) {
            Adacrus__isLine_reset(&self->isLine_4);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                               &Adacrus__isLine_out_st, &self->isLine_4);
          v_592 = Adacrus__isLine_out_st.out;
          v_593 = (v_591&&v_592);
          if (v_593) {
            nr_4_St_6_TurnLeft = true;
            ns_4_St_6_TurnLeft = Adacrus__St_6_Exit;
          } else {
            nr_4_St_6_TurnLeft = false;
            ns_4_St_6_TurnLeft = Adacrus__St_6_TurnLeft;
          };
          v_l_St_9_RotL = v_l_St_9_RotL_St_6_TurnLeft;
          v_r_St_9_RotL = v_r_St_9_RotL_St_6_TurnLeft;
          dir_St_9_RotL = dir_St_9_RotL_St_6_TurnLeft;
          debug_state_St_9_RotL = debug_state_St_9_RotL_St_6_TurnLeft;
          exit_1 = exit_1_St_6_TurnLeft;
          ns_4 = ns_4_St_6_TurnLeft;
          nr_4 = nr_4_St_6_TurnLeft;
          break;
        case Adacrus__St_6_Exit:
          debug_state_St_9_RotL_St_6_Exit = Adacrus__Exit;
          exit_1_St_6_Exit = true;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_9_RotL_St_6_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_9_RotL_St_6_Exit = Adacrus__halt_out_st.v_r;
          dir_St_9_RotL_St_6_Exit = Adacrus__halt_out_st.dir;
          nr_4_St_6_Exit = false;
          ns_4_St_6_Exit = Adacrus__St_6_Exit;
          v_l_St_9_RotL = v_l_St_9_RotL_St_6_Exit;
          v_r_St_9_RotL = v_r_St_9_RotL_St_6_Exit;
          dir_St_9_RotL = dir_St_9_RotL_St_6_Exit;
          debug_state_St_9_RotL = debug_state_St_9_RotL_St_6_Exit;
          exit_1 = exit_1_St_6_Exit;
          ns_4 = ns_4_St_6_Exit;
          nr_4 = nr_4_St_6_Exit;
          break;
        default:
          break;
      };
      if (exit_1) {
        nr_7_St_9_RotL = false;
        ns_7_St_9_RotL = Adacrus__St_9_DecideAction;
      } else {
        nr_7_St_9_RotL = false;
        ns_7_St_9_RotL = Adacrus__St_9_RotL;
      };
      oriented = oriented_St_9_RotL;
      _out->dir = dir_St_9_RotL;
      debug_state = debug_state_St_9_RotL;
      break;
    case Adacrus__St_9_RotR:
      if (r_7) {
        exit_2_1 = false;
      } else {
        exit_2_1 = self->v_590;
      };
      oriented_St_9_RotR = self->oriented_4;
      if (r_7) {
        pnr_5 = false;
      } else {
        pnr_5 = self->v_589;
      };
      r_5 = pnr_5;
      if (r_7) {
        ck_6 = Adacrus__St_7_GoAhead;
      } else {
        ck_6 = self->v_588;
      };
      current_state_St_9_RotR = Adacrus__RotR;
      current_state = current_state_St_9_RotR;
      oriented = oriented_St_9_RotR;
      switch (ck_6) {
        case Adacrus__St_7_GoAhead:
          exit_2_St_7_GoAhead = exit_2_1;
          debug_state_St_9_RotR_St_7_GoAhead = Adacrus__GoAhead;
          v_587 = (self->v_586+1);
          v_584 = (r_7||r_5);
          if (self->v_583) {
            v_585 = true;
          } else {
            v_585 = v_584;
          };
          if (v_585) {
            t_forward_1 = 0;
          } else {
            t_forward_1 = v_587;
          };
          dir_St_9_RotR_St_7_GoAhead = Adacrus__Forward;
          v_r_St_9_RotR_St_7_GoAhead = 200;
          v_l_St_9_RotR_St_7_GoAhead = 200;
          v_582 = (t_forward_1>35);
          if (v_582) {
            nr_5_St_7_GoAhead = true;
            ns_5_St_7_GoAhead = Adacrus__St_7_BlackToWhite;
          } else {
            nr_5_St_7_GoAhead = false;
            ns_5_St_7_GoAhead = Adacrus__St_7_GoAhead;
          };
          v_l_St_9_RotR = v_l_St_9_RotR_St_7_GoAhead;
          v_r_St_9_RotR = v_r_St_9_RotR_St_7_GoAhead;
          dir_St_9_RotR = dir_St_9_RotR_St_7_GoAhead;
          debug_state_St_9_RotR = debug_state_St_9_RotR_St_7_GoAhead;
          exit_2 = exit_2_St_7_GoAhead;
          ns_5 = ns_5_St_7_GoAhead;
          nr_5 = nr_5_St_7_GoAhead;
          break;
        case Adacrus__St_7_BlackToWhite:
          exit_2_St_7_BlackToWhite = exit_2_1;
          debug_state_St_9_RotR_St_7_BlackToWhite = Adacrus__BlackToWhite;
          v_581 = (self->v_580+1);
          v_578 = (r_7||r_5);
          if (self->v_577) {
            v_579 = true;
          } else {
            v_579 = v_578;
          };
          if (v_579) {
            t_right = 0;
          } else {
            t_right = v_581;
          };
          dir_St_9_RotR_St_7_BlackToWhite = Adacrus__Right;
          v_r_St_9_RotR_St_7_BlackToWhite = -100;
          v_l_St_9_RotR_St_7_BlackToWhite = 100;
          r_18 = (r_7||r_5);
          if (r_18) {
            Adacrus__isAllWhite_reset(&self->isAllWhite);
          };
          Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 40,
                                   &Adacrus__isAllWhite_out_st,
                                   &self->isAllWhite);
          v_576 = Adacrus__isAllWhite_out_st.out;
          if (v_576) {
            nr_5_St_7_BlackToWhite = true;
            ns_5_St_7_BlackToWhite = Adacrus__St_7_TurnRight;
          } else {
            nr_5_St_7_BlackToWhite = false;
            ns_5_St_7_BlackToWhite = Adacrus__St_7_BlackToWhite;
          };
          v_l_St_9_RotR = v_l_St_9_RotR_St_7_BlackToWhite;
          v_r_St_9_RotR = v_r_St_9_RotR_St_7_BlackToWhite;
          dir_St_9_RotR = dir_St_9_RotR_St_7_BlackToWhite;
          debug_state_St_9_RotR = debug_state_St_9_RotR_St_7_BlackToWhite;
          exit_2 = exit_2_St_7_BlackToWhite;
          ns_5 = ns_5_St_7_BlackToWhite;
          nr_5 = nr_5_St_7_BlackToWhite;
          break;
        case Adacrus__St_7_TurnRight:
          exit_2_St_7_TurnRight = exit_2_1;
          debug_state_St_9_RotR_St_7_TurnRight = Adacrus__TurnRight;
          v_575 = (self->v_574+1);
          v_572 = (r_7||r_5);
          if (self->v_571) {
            v_573 = true;
          } else {
            v_573 = v_572;
          };
          if (v_573) {
            t_right_1 = 0;
          } else {
            t_right_1 = v_575;
          };
          dir_St_9_RotR_St_7_TurnRight = Adacrus__Right;
          v_r_St_9_RotR_St_7_TurnRight = -100;
          v_l_St_9_RotR_St_7_TurnRight = 100;
          v_568 = (t_right_1>35);
          r_17 = (r_7||r_5);
          if (r_17) {
            Adacrus__isLine_reset(&self->isLine_3);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                               &Adacrus__isLine_out_st, &self->isLine_3);
          v_569 = Adacrus__isLine_out_st.out;
          v_570 = (v_568&&v_569);
          if (v_570) {
            nr_5_St_7_TurnRight = true;
            ns_5_St_7_TurnRight = Adacrus__St_7_Exit;
          } else {
            nr_5_St_7_TurnRight = false;
            ns_5_St_7_TurnRight = Adacrus__St_7_TurnRight;
          };
          v_l_St_9_RotR = v_l_St_9_RotR_St_7_TurnRight;
          v_r_St_9_RotR = v_r_St_9_RotR_St_7_TurnRight;
          dir_St_9_RotR = dir_St_9_RotR_St_7_TurnRight;
          debug_state_St_9_RotR = debug_state_St_9_RotR_St_7_TurnRight;
          exit_2 = exit_2_St_7_TurnRight;
          ns_5 = ns_5_St_7_TurnRight;
          nr_5 = nr_5_St_7_TurnRight;
          break;
        case Adacrus__St_7_Exit:
          debug_state_St_9_RotR_St_7_Exit = Adacrus__Exit;
          exit_2_St_7_Exit = true;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_9_RotR_St_7_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_9_RotR_St_7_Exit = Adacrus__halt_out_st.v_r;
          dir_St_9_RotR_St_7_Exit = Adacrus__halt_out_st.dir;
          nr_5_St_7_Exit = false;
          ns_5_St_7_Exit = Adacrus__St_7_Exit;
          v_l_St_9_RotR = v_l_St_9_RotR_St_7_Exit;
          v_r_St_9_RotR = v_r_St_9_RotR_St_7_Exit;
          dir_St_9_RotR = dir_St_9_RotR_St_7_Exit;
          debug_state_St_9_RotR = debug_state_St_9_RotR_St_7_Exit;
          exit_2 = exit_2_St_7_Exit;
          ns_5 = ns_5_St_7_Exit;
          nr_5 = nr_5_St_7_Exit;
          break;
        default:
          break;
      };
      if (exit_2) {
        nr_7_St_9_RotR = false;
        ns_7_St_9_RotR = Adacrus__St_9_DecideAction;
      } else {
        nr_7_St_9_RotR = false;
        ns_7_St_9_RotR = Adacrus__St_9_RotR;
      };
      _out->dir = dir_St_9_RotR;
      debug_state = debug_state_St_9_RotR;
      break;
    case Adacrus__St_9_Rot180:
      if (r_7) {
        exit_3_1 = false;
      } else {
        exit_3_1 = self->v_567;
      };
      oriented_St_9_Rot180 = self->oriented_4;
      if (r_7) {
        pnr_6 = false;
      } else {
        pnr_6 = self->v_566;
      };
      r_6 = pnr_6;
      if (r_7) {
        ck_7 = Adacrus__St_8_GoAhead;
      } else {
        ck_7 = self->v_565;
      };
      current_state_St_9_Rot180 = Adacrus__Rot180;
      current_state = current_state_St_9_Rot180;
      oriented = oriented_St_9_Rot180;
      switch (ck_7) {
        case Adacrus__St_8_GoAhead:
          exit_3_St_8_GoAhead = exit_3_1;
          debug_state_St_9_Rot180_St_8_GoAhead = Adacrus__GoAhead;
          v_564 = (self->v_563+1);
          v_561 = (r_7||r_6);
          if (self->v_560) {
            v_562 = true;
          } else {
            v_562 = v_561;
          };
          if (v_562) {
            t_forward_2 = 0;
          } else {
            t_forward_2 = v_564;
          };
          dir_St_9_Rot180_St_8_GoAhead = Adacrus__Forward;
          v_r_St_9_Rot180_St_8_GoAhead = 200;
          v_l_St_9_Rot180_St_8_GoAhead = 200;
          v_559 = (t_forward_2>35);
          if (v_559) {
            nr_6_St_8_GoAhead = true;
            ns_6_St_8_GoAhead = Adacrus__St_8_TurnRight;
          } else {
            nr_6_St_8_GoAhead = false;
            ns_6_St_8_GoAhead = Adacrus__St_8_GoAhead;
          };
          v_l_St_9_Rot180 = v_l_St_9_Rot180_St_8_GoAhead;
          v_r_St_9_Rot180 = v_r_St_9_Rot180_St_8_GoAhead;
          dir_St_9_Rot180 = dir_St_9_Rot180_St_8_GoAhead;
          debug_state_St_9_Rot180 = debug_state_St_9_Rot180_St_8_GoAhead;
          exit_3 = exit_3_St_8_GoAhead;
          ns_6 = ns_6_St_8_GoAhead;
          nr_6 = nr_6_St_8_GoAhead;
          break;
        case Adacrus__St_8_TurnRight:
          exit_3_St_8_TurnRight = exit_3_1;
          debug_state_St_9_Rot180_St_8_TurnRight = Adacrus__TurnRight;
          v_558 = (self->v_557+1);
          v_555 = (r_7||r_6);
          if (self->v_554) {
            v_556 = true;
          } else {
            v_556 = v_555;
          };
          if (v_556) {
            t_right_2 = 0;
          } else {
            t_right_2 = v_558;
          };
          dir_St_9_Rot180_St_8_TurnRight = Adacrus__Right;
          v_r_St_9_Rot180_St_8_TurnRight = -100;
          v_l_St_9_Rot180_St_8_TurnRight = 100;
          v_551 = (t_right_2>35);
          r_16 = (r_7||r_6);
          if (r_16) {
            Adacrus__isLine_reset(&self->isLine_2);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 5,
                               &Adacrus__isLine_out_st, &self->isLine_2);
          v_552 = Adacrus__isLine_out_st.out;
          v_553 = (v_551&&v_552);
          if (v_553) {
            nr_6_St_8_TurnRight = true;
            ns_6_St_8_TurnRight = Adacrus__St_8_TurnRightAgain;
          } else {
            nr_6_St_8_TurnRight = false;
            ns_6_St_8_TurnRight = Adacrus__St_8_TurnRight;
          };
          v_l_St_9_Rot180 = v_l_St_9_Rot180_St_8_TurnRight;
          v_r_St_9_Rot180 = v_r_St_9_Rot180_St_8_TurnRight;
          dir_St_9_Rot180 = dir_St_9_Rot180_St_8_TurnRight;
          debug_state_St_9_Rot180 = debug_state_St_9_Rot180_St_8_TurnRight;
          exit_3 = exit_3_St_8_TurnRight;
          ns_6 = ns_6_St_8_TurnRight;
          nr_6 = nr_6_St_8_TurnRight;
          break;
        case Adacrus__St_8_TurnRightAgain:
          exit_3_St_8_TurnRightAgain = exit_3_1;
          debug_state_St_9_Rot180_St_8_TurnRightAgain = Adacrus__TurnRight;
          v_550 = (self->v_549+1);
          v_547 = (r_7||r_6);
          if (self->v_546) {
            v_548 = true;
          } else {
            v_548 = v_547;
          };
          if (v_548) {
            t_right_again = 0;
          } else {
            t_right_again = v_550;
          };
          dir_St_9_Rot180_St_8_TurnRightAgain = Adacrus__Right;
          v_r_St_9_Rot180_St_8_TurnRightAgain = -100;
          v_l_St_9_Rot180_St_8_TurnRightAgain = 100;
          v = (t_right_again>35);
          r_15 = (r_7||r_6);
          if (r_15) {
            Adacrus__isLine_reset(&self->isLine);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 5,
                               &Adacrus__isLine_out_st, &self->isLine);
          v_544 = Adacrus__isLine_out_st.out;
          v_545 = (v&&v_544);
          if (v_545) {
            nr_6_St_8_TurnRightAgain = true;
            ns_6_St_8_TurnRightAgain = Adacrus__St_8_Exit;
          } else {
            nr_6_St_8_TurnRightAgain = false;
            ns_6_St_8_TurnRightAgain = Adacrus__St_8_TurnRightAgain;
          };
          v_l_St_9_Rot180 = v_l_St_9_Rot180_St_8_TurnRightAgain;
          v_r_St_9_Rot180 = v_r_St_9_Rot180_St_8_TurnRightAgain;
          dir_St_9_Rot180 = dir_St_9_Rot180_St_8_TurnRightAgain;
          debug_state_St_9_Rot180 = debug_state_St_9_Rot180_St_8_TurnRightAgain;
          exit_3 = exit_3_St_8_TurnRightAgain;
          ns_6 = ns_6_St_8_TurnRightAgain;
          nr_6 = nr_6_St_8_TurnRightAgain;
          break;
        case Adacrus__St_8_Exit:
          exit_3_St_8_Exit = true;
          debug_state_St_9_Rot180_St_8_Exit = Adacrus__Exit;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_9_Rot180_St_8_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_9_Rot180_St_8_Exit = Adacrus__halt_out_st.v_r;
          dir_St_9_Rot180_St_8_Exit = Adacrus__halt_out_st.dir;
          nr_6_St_8_Exit = false;
          ns_6_St_8_Exit = Adacrus__St_8_Exit;
          v_l_St_9_Rot180 = v_l_St_9_Rot180_St_8_Exit;
          v_r_St_9_Rot180 = v_r_St_9_Rot180_St_8_Exit;
          dir_St_9_Rot180 = dir_St_9_Rot180_St_8_Exit;
          debug_state_St_9_Rot180 = debug_state_St_9_Rot180_St_8_Exit;
          exit_3 = exit_3_St_8_Exit;
          ns_6 = ns_6_St_8_Exit;
          nr_6 = nr_6_St_8_Exit;
          break;
        default:
          break;
      };
      if (exit_3) {
        nr_7_St_9_Rot180 = false;
        ns_7_St_9_Rot180 = Adacrus__St_9_DecideAction;
      } else {
        nr_7_St_9_Rot180 = false;
        ns_7_St_9_Rot180 = Adacrus__St_9_Rot180;
      };
      _out->dir = dir_St_9_Rot180;
      debug_state = debug_state_St_9_Rot180;
      break;
    default:
      break;
  };
  _out->o = oriented;
  _out->d_s = debug_state;
  _out->s = current_state;
  switch (self->ck) {
    case Adacrus__St_9_Initial:
      next_node_St_9_Initial = self->next_node_5;
      next_node = next_node_St_9_Initial;
      _out->v_l = v_l_St_9_Initial;
      _out->v_r = v_r_St_9_Initial;
      ns_7 = ns_7_St_9_Initial;
      nr_7 = nr_7_St_9_Initial;
      break;
    case Adacrus__St_9_Moving:
      next_node_St_9_Moving = self->next_node_5;
      next_node = next_node_St_9_Moving;
      v_663 = (next_node.y==3);
      v_664 = (v_662&&v_663);
      if (v_664) {
        v_670 = v_666;
        v_669 = v_665;
      } else {
        v_670 = v_668;
        v_669 = v_667;
      };
      v_658 = (next_node.y==4);
      v_659 = (v_657&&v_658);
      if (v_659) {
        v_672 = v_661;
        v_671 = v_660;
      } else {
        v_672 = v_670;
        v_671 = v_669;
      };
      v_652 = (next_node.y==1);
      v_653 = (v_651&&v_652);
      v_649 = (next_node.y==2);
      v_650 = (v_648&&v_649);
      v_654 = (v_650||v_653);
      v_639 = (next_node.y==5);
      v_640 = (v_638&&v_639);
      v_636 = (next_node.y==6);
      v_637 = (v_635&&v_636);
      inverted_section = (v_637||v_640);
      if (inverted_section) {
        v_674 = 200;
      } else {
        v_674 = v_672;
      };
      if (v_654) {
        v_r_St_9_Moving = v_656;
      } else {
        v_r_St_9_Moving = v_674;
      };
      if (inverted_section) {
        v_673 = 200;
      } else {
        v_673 = v_671;
      };
      if (v_654) {
        v_l_St_9_Moving = v_655;
      } else {
        v_l_St_9_Moving = v_673;
      };
      v_646 = (inverted_section&&v_645);
      if (v_646) {
        exit = false;
      } else {
        exit = v_647;
      };
      if (exit) {
        nr_7_St_9_Moving = false;
        ns_7_St_9_Moving = Adacrus__St_9_DecideAction;
      } else {
        nr_7_St_9_Moving = false;
        ns_7_St_9_Moving = Adacrus__St_9_Moving;
      };
      _out->v_l = v_l_St_9_Moving;
      _out->v_r = v_r_St_9_Moving;
      ns_7 = ns_7_St_9_Moving;
      nr_7 = nr_7_St_9_Moving;
      break;
    case Adacrus__St_9_Exit:
      next_node_St_9_Exit = self->next_node_5;
      next_node = next_node_St_9_Exit;
      _out->v_l = v_l_St_9_Exit;
      _out->v_r = v_r_St_9_Exit;
      ns_7 = ns_7_St_9_Exit;
      nr_7 = nr_7_St_9_Exit;
      break;
    case Adacrus__St_9_RotL:
      next_node_St_9_RotL = self->next_node_5;
      next_node = next_node_St_9_RotL;
      _out->v_l = v_l_St_9_RotL;
      _out->v_r = v_r_St_9_RotL;
      ns_7 = ns_7_St_9_RotL;
      nr_7 = nr_7_St_9_RotL;
      break;
    case Adacrus__St_9_RotR:
      next_node_St_9_RotR = self->next_node_5;
      next_node = next_node_St_9_RotR;
      _out->v_l = v_l_St_9_RotR;
      _out->v_r = v_r_St_9_RotR;
      ns_7 = ns_7_St_9_RotR;
      nr_7 = nr_7_St_9_RotR;
      break;
    case Adacrus__St_9_Rot180:
      next_node_St_9_Rot180 = self->next_node_5;
      next_node = next_node_St_9_Rot180;
      _out->v_l = v_l_St_9_Rot180;
      _out->v_r = v_r_St_9_Rot180;
      ns_7 = ns_7_St_9_Rot180;
      nr_7 = nr_7_St_9_Rot180;
      break;
    case Adacrus__St_9_DecideAction:
      switch (ck_4) {
        case Adacrus__St_5_Decidado:
          if (r_22) {
            Adacrus__decideAction_reset(&self->decideAction);
          };
          Adacrus__decideAction_step(self->next_node_5,
                                     self->current_state_2, oriented,
                                     ir_prox, &Adacrus__decideAction_out_st,
                                     &self->decideAction);
          next_node_St_9_DecideAction_St_5_Decidado = Adacrus__decideAction_out_st.next_node;
          next_state_St_5_Decidado = Adacrus__decideAction_out_st.next_state;
          next_node_St_9_DecideAction = next_node_St_9_DecideAction_St_5_Decidado;
          break;
        case Adacrus__St_5_LeaveNode:
          next_node_St_9_DecideAction_St_5_LeaveNode = self->next_node_5;
          next_node_St_9_DecideAction = next_node_St_9_DecideAction_St_5_LeaveNode;
          break;
        default:
          break;
      };
      next_node = next_node_St_9_DecideAction;
      _out->v_l = v_l_St_9_DecideAction;
      _out->v_r = v_r_St_9_DecideAction;
      switch (ck_4) {
        case Adacrus__St_5_LeaveNode:
          next_state = next_state_St_5_LeaveNode;
          break;
        case Adacrus__St_5_Decidado:
          next_state = next_state_St_5_Decidado;
          break;
        default:
          break;
      };
      v_622 = (next_state==Adacrus__Exit);
      v_623 = (out_of_node&&v_622);
      if (v_623) {
        v_625 = true;
        v_624 = Adacrus__St_9_Exit;
      } else {
        v_625 = false;
        v_624 = Adacrus__St_9_DecideAction;
      };
      v_620 = (next_state==Adacrus__Moving);
      v_621 = (out_of_node&&v_620);
      if (v_621) {
        v_627 = true;
        v_626 = Adacrus__St_9_Moving;
      } else {
        v_627 = v_625;
        v_626 = v_624;
      };
      v_618 = (next_state==Adacrus__Rot180);
      v_619 = (out_of_node&&v_618);
      if (v_619) {
        v_629 = true;
        v_628 = Adacrus__St_9_Rot180;
      } else {
        v_629 = v_627;
        v_628 = v_626;
      };
      v_616 = (next_state==Adacrus__RotR);
      v_617 = (out_of_node&&v_616);
      if (v_617) {
        v_631 = true;
        v_630 = Adacrus__St_9_RotR;
      } else {
        v_631 = v_629;
        v_630 = v_628;
      };
      v_614 = (next_state==Adacrus__RotL);
      v_615 = (out_of_node&&v_614);
      if (v_615) {
        nr_7_St_9_DecideAction = true;
        ns_7_St_9_DecideAction = Adacrus__St_9_RotL;
      } else {
        nr_7_St_9_DecideAction = v_631;
        ns_7_St_9_DecideAction = v_630;
      };
      ns_7 = ns_7_St_9_DecideAction;
      nr_7 = nr_7_St_9_DecideAction;
      break;
    default:
      break;
  };
  _out->nnode = next_node;
  self->debug_state_1 = debug_state;
  self->current_state_2 = current_state;
  self->oriented_4 = oriented;
  self->next_node_5 = next_node;
  self->pnr_7 = nr_7;
  switch (self->ck) {
    case Adacrus__St_9_Moving:
      self->v_643 = inverted_t;
      self->v_641 = false;
      break;
    case Adacrus__St_9_DecideAction:
      self->next_state_4 = next_state;
      self->v_634 = out_of_node;
      self->v_633 = nr;
      self->v_632 = ns;
      break;
    case Adacrus__St_9_RotL:
      self->v_613 = exit_1;
      self->v_612 = nr_4;
      self->v_611 = ns_4;
      switch (ck_5) {
        case Adacrus__St_6_GoAhead:
          self->v_609 = t_forward;
          self->v_606 = false;
          break;
        case Adacrus__St_6_BlackToWhite:
          self->v_603 = t_left;
          self->v_600 = false;
          break;
        case Adacrus__St_6_TurnLeft:
          self->v_597 = t_left_1;
          self->v_594 = false;
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_9_RotR:
      self->v_590 = exit_2;
      self->v_589 = nr_5;
      self->v_588 = ns_5;
      switch (ck_6) {
        case Adacrus__St_7_GoAhead:
          self->v_586 = t_forward_1;
          self->v_583 = false;
          break;
        case Adacrus__St_7_BlackToWhite:
          self->v_580 = t_right;
          self->v_577 = false;
          break;
        case Adacrus__St_7_TurnRight:
          self->v_574 = t_right_1;
          self->v_571 = false;
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_9_Rot180:
      self->v_567 = exit_3;
      self->v_566 = nr_6;
      self->v_565 = ns_6;
      switch (ck_7) {
        case Adacrus__St_8_GoAhead:
          self->v_563 = t_forward_2;
          self->v_560 = false;
          break;
        case Adacrus__St_8_TurnRight:
          self->v_557 = t_right_2;
          self->v_554 = false;
          break;
        case Adacrus__St_8_TurnRightAgain:
          self->v_549 = t_right_again;
          self->v_546 = false;
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };
  self->ck = ns_7;;
}

void Adacrus__main_reset(Adacrus__main_mem* self) {
  Adacrus__adacrus_params_35__reset(&self->adacrus);
}

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self) {
  Adacrus__adacrus_params_35__out Adacrus__adacrus_params_35__out_st;
  Adacrus__adacrus_params_35__step(left_wl, center_wl, right_wl, ir_prox,
                                   &Adacrus__adacrus_params_35__out_st,
                                   &self->adacrus);
  _out->v_l = Adacrus__adacrus_params_35__out_st.v_l;
  _out->v_r = Adacrus__adacrus_params_35__out_st.v_r;
  _out->o = Adacrus__adacrus_params_35__out_st.o;
  _out->dir = Adacrus__adacrus_params_35__out_st.dir;
  _out->s = Adacrus__adacrus_params_35__out_st.s;
  _out->d_s = Adacrus__adacrus_params_35__out_st.d_s;
  _out->next_node = Adacrus__adacrus_params_35__out_st.nnode;
}

