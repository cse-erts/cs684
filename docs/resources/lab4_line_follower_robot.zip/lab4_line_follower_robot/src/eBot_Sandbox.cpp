/*
 * eBot_Sandbox.cpp
 *
 *  Created on: 23-Feb-2022
 *      Author: TAs of CS 684 Spring 2021
 */


//---------------------------------- INCLUDES -----------------------------------

#include "eBot_Sandbox.h"
#include <stdlib.h>


//------------------------------ GLOBAL VARIABLES -------------------------------

// To store data of left, center and right white line sensors
unsigned char left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data;

int speed;

float Kp = ;
float Ki = ;
float Kd = ;
//---------------------------------- FUNCTIONS ----------------------------------

/*
*
* Function Name: calculate_pid
* Input: void
* Output: void
* Logic: Uses white line sensors to calculate the speed value
* Example Call: calculate_pid();
*
*/
void calculate_pid(void)
{

}

/*
*
* Function Name: actuation
* Input: void
* Output: void
* Logic: Uses speed value to decide the pwm frequency for two motors and in turn actuation
* Example Call: actuation();
*
*/
void actuation(void)
{

}

/**
 * @brief      Executes the logic to achieve the aim of Lab 4
 */
void traverse_line(void)
{
	while (1)
	{
		left_wl_sensor_data = convert_analog_channel_data(left_wl_sensor_channel);
		center_wl_sensor_data = convert_analog_channel_data(center_wl_sensor_channel);
		right_wl_sensor_data = convert_analog_channel_data(right_wl_sensor_channel);

		calculate_pid();

		actuation();

	}
}

