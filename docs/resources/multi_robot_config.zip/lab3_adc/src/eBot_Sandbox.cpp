/*
 * eBot_Sandbox.cpp
 *
 *  Created on: 11-Jan-2021
 *      Author: TAs of CS 684 Spring 2020
 */


//---------------------------------- INCLUDES -----------------------------------

#include "eBot_Sandbox.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

//------------------------------ GLOBAL VARIABLES -------------------------------

// To store 8-bit data of left, center and right white line sensors
unsigned int left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data;

// To store 8-bit data of 5th IR proximity sensors
unsigned char left_ir_sensor_data, center_ir_sensor_data, right_ir_sensor_data;


//---------------------------------- FUNCTIONS ----------------------------------


/**
 * @brief      Executes the logic to achieve the aim of Lab 3
 */
void send_sensor_data(void)
{
	int return_code;
	while (1)
	{
		left_wl_sensor_data = convert_analog_channel_data(0, left_wl_sensor_channel);
		center_wl_sensor_data = convert_analog_channel_data(0, center_wl_sensor_channel);
		right_wl_sensor_data = convert_analog_channel_data(0, right_wl_sensor_channel);

		left_ir_sensor_data	= convert_analog_channel_data(0, left_ir_sensor_channel);
		center_ir_sensor_data = convert_analog_channel_data(0, center_ir_sensor_channel);
		right_ir_sensor_data = convert_analog_channel_data(0, right_ir_sensor_channel);

		return_code = print_ir_prox_5_data(left_ir_sensor_data, center_ir_sensor_data, right_ir_sensor_data);

		if ( return_code == 0 )
		{
			break;
		}

		left_wl_sensor_data = convert_analog_channel_data(1, left_wl_sensor_channel);
		center_wl_sensor_data = convert_analog_channel_data(1, center_wl_sensor_channel);
		right_wl_sensor_data = convert_analog_channel_data(1, right_wl_sensor_channel);
		left_ir_sensor_data	= convert_analog_channel_data(1, left_ir_sensor_channel);
		center_ir_sensor_data = convert_analog_channel_data(1, center_ir_sensor_channel);
		right_ir_sensor_data = convert_analog_channel_data(1, right_ir_sensor_channel);

		return_code = print_ir_prox_5_data(left_ir_sensor_data, center_ir_sensor_data, right_ir_sensor_data);

		if ( return_code == 0 )
		{
			break;
		}




		forward(0);
		velocity (0, 100, 100);

		forward(1);
		velocity (1, 200, 200);



		_delay_ms(500);
	}
}

