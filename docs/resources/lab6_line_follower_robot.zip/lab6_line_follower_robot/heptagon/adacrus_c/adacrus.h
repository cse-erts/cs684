/* --- Generated the 23/3/2021 at 19:1 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_H
#define ADACRUS_H

#include "adacrus_types.h"
typedef struct Adacrus__main_mem {
  int v_2;
  int v_1;
  int v;
} Adacrus__main_mem;

typedef struct Adacrus__main_out {
  int v_l;
  int v_r;
} Adacrus__main_out;

void Adacrus__main_reset(Adacrus__main_mem* self);

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self);

#endif // ADACRUS_H
