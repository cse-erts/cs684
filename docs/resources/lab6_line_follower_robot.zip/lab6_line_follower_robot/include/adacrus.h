#ifdef __cplusplus
extern "C" {
#endif

/* --- Generated the 26/3/2021 at 11:55 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_H
#define ADACRUS_H

#include "adacrus_types.h"
typedef struct Adacrus__isInverted_mem {
  int v_22;
  int v_16;
  int v_14;
  int v_12;
  int v_8;
  int v_4;
  int v_1;
  int v;
} Adacrus__isInverted_mem;

typedef struct Adacrus__isInverted_out {
  int out;
} Adacrus__isInverted_out;

void Adacrus__isInverted_reset(Adacrus__isInverted_mem* self);

void Adacrus__isInverted_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__isInverted_out* _out,
                              Adacrus__isInverted_mem* self);

typedef struct Adacrus__isNode_mem {
  int v_33;
  int v;
} Adacrus__isNode_mem;

typedef struct Adacrus__isNode_out {
  int out;
} Adacrus__isNode_out;

void Adacrus__isNode_reset(Adacrus__isNode_mem* self);

void Adacrus__isNode_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isNode_out* _out,
                          Adacrus__isNode_mem* self);

typedef struct Adacrus__notIsNode_out {
  int out;
} Adacrus__notIsNode_out;

void Adacrus__notIsNode_step(int left_wl, int center_wl, int right_wl,
                             Adacrus__notIsNode_out* _out);

typedef struct Adacrus__isAllWhite_mem {
  int v_63;
  int v;
} Adacrus__isAllWhite_mem;

typedef struct Adacrus__isAllWhite_out {
  int out;
} Adacrus__isAllWhite_out;

void Adacrus__isAllWhite_reset(Adacrus__isAllWhite_mem* self);

void Adacrus__isAllWhite_step(int left_wl, int center_wl, int right_wl,
                              int t, Adacrus__isAllWhite_out* _out,
                              Adacrus__isAllWhite_mem* self);

typedef struct Adacrus__isLine_mem {
  int v_71;
  int v;
} Adacrus__isLine_mem;

typedef struct Adacrus__isLine_out {
  int out;
} Adacrus__isLine_out;

void Adacrus__isLine_reset(Adacrus__isLine_mem* self);

void Adacrus__isLine_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isLine_out* _out,
                          Adacrus__isLine_mem* self);

typedef struct Adacrus__halt_out {
  int v_l;
  int v_r;
  Adacrus__direction dir;
} Adacrus__halt_out;

void Adacrus__halt_step(Adacrus__halt_out* _out);

typedef struct Adacrus__determineLineLoc_out {
  Adacrus__lineloc l;
} Adacrus__determineLineLoc_out;

void Adacrus__determineLineLoc_step(int left_wl, int center_wl, int right_wl,
                                    Adacrus__determineLineLoc_out* _out);

typedef struct Adacrus__determineLineLocInverted_out {
  Adacrus__lineloc l;
} Adacrus__determineLineLocInverted_out;

void Adacrus__determineLineLocInverted_step(int left_wl, int center_wl,
                                            int right_wl,
                                            Adacrus__determineLineLocInverted_out* _out);

typedef struct Adacrus__move_mem {
  Adacrus__st_1 ck;
  Adacrus__st ck_1;
  int v_190;
  int v_189;
  int v_188;
  int pnr_1;
  int pnr;
  int zz_5;
  Adacrus__lineloc past_ll_5;
  Adacrus__isLine_mem isLine;
  Adacrus__isInverted_mem isInverted;
  Adacrus__isAllWhite_mem isAllWhite;
  Adacrus__isLine_mem isLine_1;
  Adacrus__isAllWhite_mem isAllWhite_1;
} Adacrus__move_mem;

typedef struct Adacrus__move_out {
  int v_l;
  int v_r;
} Adacrus__move_out;

void Adacrus__move_reset(Adacrus__move_mem* self);

void Adacrus__move_step(int left_wl, int center_wl, int right_wl, int curve,
                        int inverted, int zigzagt, int zigzagb,
                        Adacrus__move_out* _out, Adacrus__move_mem* self);

typedef struct Adacrus__calcOrientation_out {
  Adacrus__orientation new_orientation;
} Adacrus__calcOrientation_out;

void Adacrus__calcOrientation_step(Adacrus__states current_state,
                                   Adacrus__orientation last_oriented,
                                   Adacrus__calcOrientation_out* _out);

typedef struct Adacrus__getNextNodeAndState_mem {
  int v_435;
  int v_434;
  int v_425;
  int v_424;
  int v_415;
  int v_414;
  int v_405;
  int v_404;
  int v_390;
  int v_389;
  int v_306;
  int v_305;
} Adacrus__getNextNodeAndState_mem;

typedef struct Adacrus__getNextNodeAndState_out {
  Adacrus__coordinates next_node;
  Adacrus__states next_state;
} Adacrus__getNextNodeAndState_out;

void Adacrus__getNextNodeAndState_reset(Adacrus__getNextNodeAndState_mem* self);

void Adacrus__getNextNodeAndState_step(Adacrus__coordinates current_node,
                                       Adacrus__coordinates goal_node,
                                       Adacrus__orientation oriented,
                                       int ir_prox,
                                       Adacrus__getNextNodeAndState_out* _out,
                                       Adacrus__getNextNodeAndState_mem* self);

typedef struct Adacrus__decideAction_mem {
  int v_454;
  int v_449;
  int v_448;
  Adacrus__getNextNodeAndState_mem getNextNodeAndState;
  Adacrus__getNextNodeAndState_mem getNextNodeAndState_1;
} Adacrus__decideAction_mem;

typedef struct Adacrus__decideAction_out {
  Adacrus__coordinates next_node;
  Adacrus__states next_state;
} Adacrus__decideAction_out;

void Adacrus__decideAction_reset(Adacrus__decideAction_mem* self);

void Adacrus__decideAction_step(Adacrus__coordinates current_node,
                                Adacrus__states last_state,
                                Adacrus__orientation oriented, int ir_prox,
                                Adacrus__decideAction_out* _out,
                                Adacrus__decideAction_mem* self);

typedef struct Adacrus__adacrus_params_35__mem {
  int v_468;
  int v_465;
  int v_476;
  int v_473;
  int v_482;
  int v_479;
  Adacrus__st_6 v_484;
  int v_486;
  int v_485;
  int v_493;
  int v_490;
  int v_499;
  int v_496;
  int v_505;
  int v_502;
  Adacrus__st_5 v_507;
  int v_509;
  int v_508;
  int v_516;
  int v_513;
  int v_522;
  int v_519;
  int v_528;
  int v_525;
  Adacrus__st_4 v_530;
  int v_532;
  int v_531;
  int v_556;
  int v_552;
  int v_563;
  int v_559;
  Adacrus__st_2 v_566;
  int v_568;
  Adacrus__st_3 v_570;
  int v_572;
  int v_571;
  Adacrus__states next_state_4;
  int v_581;
  int v_579;
  Adacrus__st_7 ck;
  int pnr_6;
  Adacrus__states debug_state_1;
  Adacrus__states current_state_2;
  Adacrus__orientation oriented_4;
  Adacrus__coordinates next_node_5;
  Adacrus__decideAction_mem decideAction;
  Adacrus__isLine_mem isLine;
  Adacrus__isLine_mem isLine_2;
  Adacrus__isLine_mem isLine_3;
  Adacrus__isAllWhite_mem isAllWhite;
  Adacrus__isLine_mem isLine_4;
  Adacrus__isAllWhite_mem isAllWhite_2;
  Adacrus__isLine_mem isLine_5;
  Adacrus__move_mem move_3;
  Adacrus__move_mem move_2;
  Adacrus__move_mem move_1;
  Adacrus__move_mem move;
  Adacrus__isNode_mem isNode;
  Adacrus__move_mem move_4;
} Adacrus__adacrus_params_35__mem;

typedef struct Adacrus__adacrus_params_35__out {
  int v_l;
  int v_r;
  Adacrus__orientation o;
  Adacrus__direction dir;
  Adacrus__states s;
  Adacrus__states d_s;
  Adacrus__coordinates nnode;
} Adacrus__adacrus_params_35__out;

void Adacrus__adacrus_params_35__reset(Adacrus__adacrus_params_35__mem* self);

void Adacrus__adacrus_params_35__step(int left_wl, int center_wl,
                                      int right_wl, int ir_prox,
                                      Adacrus__adacrus_params_35__out* _out,
                                      Adacrus__adacrus_params_35__mem* self);

typedef struct Adacrus__main_mem {
  Adacrus__adacrus_params_35__mem adacrus;
} Adacrus__main_mem;

typedef struct Adacrus__main_out {
  int v_l;
  int v_r;
  Adacrus__orientation o;
  Adacrus__direction dir;
  Adacrus__states s;
  Adacrus__states d_s;
  Adacrus__coordinates next_node;
} Adacrus__main_out;

void Adacrus__main_reset(Adacrus__main_mem* self);

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self);

#endif // ADACRUS_H

#ifdef __cplusplus
}
#endif
