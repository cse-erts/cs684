/* --- Generated the 26/3/2021 at 11:55 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_TYPES_H
#define ADACRUS_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Adacrus__St_7_RotR,
  Adacrus__St_7_RotL,
  Adacrus__St_7_Rot180,
  Adacrus__St_7_Moving,
  Adacrus__St_7_Initial,
  Adacrus__St_7_Exit,
  Adacrus__St_7_DecideAction
} Adacrus__st_7;

Adacrus__st_7 Adacrus__st_7_of_string(char* s);

char* string_of_Adacrus__st_7(Adacrus__st_7 x, char* buf);

typedef enum {
  Adacrus__St_6_TurnRightAgain,
  Adacrus__St_6_TurnRight,
  Adacrus__St_6_GoAhead,
  Adacrus__St_6_Exit
} Adacrus__st_6;

Adacrus__st_6 Adacrus__st_6_of_string(char* s);

char* string_of_Adacrus__st_6(Adacrus__st_6 x, char* buf);

typedef enum {
  Adacrus__St_5_TurnRight,
  Adacrus__St_5_GoAhead,
  Adacrus__St_5_Exit,
  Adacrus__St_5_BlackToWhite
} Adacrus__st_5;

Adacrus__st_5 Adacrus__st_5_of_string(char* s);

char* string_of_Adacrus__st_5(Adacrus__st_5 x, char* buf);

typedef enum {
  Adacrus__St_4_TurnLeft,
  Adacrus__St_4_GoAhead,
  Adacrus__St_4_Exit,
  Adacrus__St_4_BlackToWhite
} Adacrus__st_4;

Adacrus__st_4 Adacrus__st_4_of_string(char* s);

char* string_of_Adacrus__st_4(Adacrus__st_4 x, char* buf);

typedef enum {
  Adacrus__St_3_LeaveNode,
  Adacrus__St_3_Decidado,
  Adacrus__St_3_CenterAlign
} Adacrus__st_3;

Adacrus__st_3 Adacrus__st_3_of_string(char* s);

char* string_of_Adacrus__st_3(Adacrus__st_3 x, char* buf);

typedef enum {
  Adacrus__St_2_TryRight,
  Adacrus__St_2_TryLeft
} Adacrus__st_2;

Adacrus__st_2 Adacrus__st_2_of_string(char* s);

char* string_of_Adacrus__st_2(Adacrus__st_2 x, char* buf);

typedef enum {
  Adacrus__St_1_Inv,
  Adacrus__St_1_In
} Adacrus__st_1;

Adacrus__st_1 Adacrus__st_1_of_string(char* s);

char* string_of_Adacrus__st_1(Adacrus__st_1 x, char* buf);

typedef enum {
  Adacrus__St_ZigToZag,
  Adacrus__St_MaintainWhite,
  Adacrus__St_MaintainBlack,
  Adacrus__St_In
} Adacrus__st;

Adacrus__st Adacrus__st_of_string(char* s);

char* string_of_Adacrus__st(Adacrus__st x, char* buf);

typedef enum {
  Adacrus__Initial,
  Adacrus__Moving,
  Adacrus__RotL,
  Adacrus__RotR,
  Adacrus__Rot180,
  Adacrus__AtNode,
  Adacrus__Exit,
  Adacrus__GoAhead,
  Adacrus__TurnRight,
  Adacrus__TurnLeft,
  Adacrus__DecideAction,
  Adacrus__Decidado,
  Adacrus__LeaveNode,
  Adacrus__BlackToWhite,
  Adacrus__CenterAlign
} Adacrus__states;

Adacrus__states Adacrus__states_of_string(char* s);

char* string_of_Adacrus__states(Adacrus__states x, char* buf);

typedef enum {
  Adacrus__Forward,
  Adacrus__Left,
  Adacrus__Right,
  Adacrus__Stop
} Adacrus__direction;

Adacrus__direction Adacrus__direction_of_string(char* s);

char* string_of_Adacrus__direction(Adacrus__direction x, char* buf);

typedef enum {
  Adacrus__T,
  Adacrus__B,
  Adacrus__L,
  Adacrus__R
} Adacrus__orientation;

Adacrus__orientation Adacrus__orientation_of_string(char* s);

char* string_of_Adacrus__orientation(Adacrus__orientation x, char* buf);

typedef enum {
  Adacrus__OnLine,
  Adacrus__LOLeft,
  Adacrus__LOTooLeft,
  Adacrus__LORight,
  Adacrus__LOTooRight,
  Adacrus__Node,
  Adacrus__NoLine,
  Adacrus__Undef
} Adacrus__lineloc;

Adacrus__lineloc Adacrus__lineloc_of_string(char* s);

char* string_of_Adacrus__lineloc(Adacrus__lineloc x, char* buf);

typedef struct Adacrus__coordinates {
  int x;
  int y;
} Adacrus__coordinates;

static const Adacrus__coordinates Adacrus__start = {3, 1};

static const Adacrus__coordinates Adacrus__goal = {3, 6};

static const int Adacrus__node_steps = 45;

#endif // ADACRUS_TYPES_H
