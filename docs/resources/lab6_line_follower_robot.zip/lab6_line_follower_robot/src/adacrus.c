/* --- Generated the 26/3/2021 at 11:55 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 30 14:52:10 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "adacrus.h"

void Adacrus__isInverted_reset(Adacrus__isInverted_mem* self) {
  self->v_16 = true;
  self->v = true;
}

void Adacrus__isInverted_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__isInverted_out* _out,
                              Adacrus__isInverted_mem* self) {
  
  int v_27;
  int v_26;
  int v_25;
  int v_24;
  int v_23;
  int v_21;
  int v_20;
  int v_19;
  int v_18;
  int v_17;
  int v_15;
  int v_13;
  int v_11;
  int v_10;
  int v_9;
  int v_7;
  int v_6;
  int v_5;
  int v_3;
  int v_2;
  int t;
  int inverted;
  v_23 = (self->v_22+1);
  v_20 = (right_wl>200);
  v_18 = (center_wl<50);
  v_17 = (left_wl>200);
  v_19 = (v_17&&v_18);
  v_21 = (v_19&&v_20);
  if (v_21) {
    v_24 = v_23;
  } else {
    v_24 = 0;
  };
  if (self->v_16) {
    t = 0;
  } else {
    t = v_24;
  };
  v_26 = (t>=3);
  v_13 = (self->v_12+1);
  v_9 = (255-self->v_8);
  v_10 = (center_wl==v_9);
  v_5 = (255-self->v_4);
  v_6 = (right_wl==v_5);
  v_2 = (255-self->v_1);
  v_3 = (left_wl==v_2);
  v_7 = (v_3&&v_6);
  v_11 = (v_7&&v_10);
  if (v_11) {
    v_15 = v_13;
  } else {
    v_15 = self->v_14;
  };
  if (self->v) {
    inverted = 0;
  } else {
    inverted = v_15;
  };
  v_25 = (inverted==1);
  v_27 = (v_25||v_26);
  if (v_27) {
    _out->out = true;
  } else {
    _out->out = false;
  };
  self->v_22 = t;
  self->v_16 = false;
  self->v_14 = inverted;
  self->v_12 = inverted;
  self->v_8 = center_wl;
  self->v_4 = right_wl;
  self->v_1 = left_wl;
  self->v = false;;
}

void Adacrus__isNode_reset(Adacrus__isNode_mem* self) {
  self->v = true;
}

void Adacrus__isNode_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isNode_out* _out,
                          Adacrus__isNode_mem* self) {
  
  int v_35;
  int v_34;
  int v_32;
  int v_31;
  int v_30;
  int v_29;
  int v_28;
  int count;
  v_34 = (self->v_33+1);
  v_31 = (right_wl>200);
  v_29 = (left_wl>200);
  v_28 = (center_wl>200);
  v_30 = (v_28&&v_29);
  v_32 = (v_30&&v_31);
  if (v_32) {
    v_35 = v_34;
  } else {
    v_35 = 0;
  };
  if (self->v) {
    count = 0;
  } else {
    count = v_35;
  };
  _out->out = (count>=t);
  self->v_33 = count;
  self->v = false;;
}

void Adacrus__notIsNode_step(int left_wl, int center_wl, int right_wl,
                             Adacrus__notIsNode_out* _out) {
  
  int v_57;
  int v_56;
  int v_55;
  int v_54;
  int v_53;
  int v_52;
  int v_51;
  int v_50;
  int v_49;
  int v_48;
  int v_47;
  int v_46;
  int v_45;
  int v_44;
  int v_43;
  int v_42;
  int v_41;
  int v_40;
  int v_39;
  int v_38;
  int v_37;
  int v_36;
  int v;
  v_53 = (right_wl>200);
  v_51 = (center_wl>200);
  v_50 = (left_wl<50);
  v_52 = (v_50&&v_51);
  v_54 = (v_52&&v_53);
  if (v_54) {
    v_55 = false;
  } else {
    v_55 = true;
  };
  v_48 = (right_wl<50);
  v_46 = (center_wl>200);
  v_45 = (left_wl>200);
  v_47 = (v_45&&v_46);
  v_49 = (v_47&&v_48);
  if (v_49) {
    v_56 = false;
  } else {
    v_56 = v_55;
  };
  v_43 = (right_wl>200);
  v_41 = (center_wl>200);
  v_40 = (left_wl>200);
  v_42 = (v_40&&v_41);
  v_44 = (v_42&&v_43);
  if (v_44) {
    v_57 = false;
  } else {
    v_57 = v_56;
  };
  v_38 = (right_wl<50);
  v_36 = (center_wl<50);
  v = (left_wl<50);
  v_37 = (v&&v_36);
  v_39 = (v_37&&v_38);
  if (v_39) {
    _out->out = true;
  } else {
    _out->out = v_57;
  };;
}

void Adacrus__isAllWhite_reset(Adacrus__isAllWhite_mem* self) {
  self->v = true;
}

void Adacrus__isAllWhite_step(int left_wl, int center_wl, int right_wl,
                              int t, Adacrus__isAllWhite_out* _out,
                              Adacrus__isAllWhite_mem* self) {
  
  int v_65;
  int v_64;
  int v_62;
  int v_61;
  int v_60;
  int v_59;
  int v_58;
  int count;
  v_64 = (self->v_63+1);
  v_61 = (right_wl<100);
  v_59 = (left_wl<100);
  v_58 = (center_wl<100);
  v_60 = (v_58&&v_59);
  v_62 = (v_60&&v_61);
  if (v_62) {
    v_65 = v_64;
  } else {
    v_65 = 0;
  };
  if (self->v) {
    count = 0;
  } else {
    count = v_65;
  };
  _out->out = (count>=t);
  self->v_63 = count;
  self->v = false;;
}

void Adacrus__isLine_reset(Adacrus__isLine_mem* self) {
  self->v = true;
}

void Adacrus__isLine_step(int left_wl, int center_wl, int right_wl, int t,
                          Adacrus__isLine_out* _out,
                          Adacrus__isLine_mem* self) {
  
  int v_73;
  int v_72;
  int v_70;
  int v_69;
  int v_68;
  int v_67;
  int v_66;
  int count;
  v_72 = (self->v_71+1);
  v_69 = (right_wl<50);
  v_67 = (center_wl>200);
  v_66 = (left_wl<50);
  v_68 = (v_66&&v_67);
  v_70 = (v_68&&v_69);
  if (v_70) {
    v_73 = v_72;
  } else {
    v_73 = 0;
  };
  if (self->v) {
    count = 0;
  } else {
    count = v_73;
  };
  _out->out = (count>=t);
  self->v_71 = count;
  self->v = false;;
}

void Adacrus__halt_step(Adacrus__halt_out* _out) {
  _out->dir = Adacrus__Stop;
  _out->v_r = 0;
  _out->v_l = 0;
}

void Adacrus__determineLineLoc_step(int left_wl, int center_wl, int right_wl,
                                    Adacrus__determineLineLoc_out* _out) {
  
  Adacrus__lineloc v_113;
  Adacrus__lineloc v_112;
  Adacrus__lineloc v_111;
  Adacrus__lineloc v_110;
  Adacrus__lineloc v_109;
  Adacrus__lineloc v_108;
  int v_107;
  int v_106;
  int v_105;
  int v_104;
  int v_103;
  int v_102;
  int v_101;
  int v_100;
  int v_99;
  int v_98;
  int v_97;
  int v_96;
  int v_95;
  int v_94;
  int v_93;
  int v_92;
  int v_91;
  int v_90;
  int v_89;
  int v_88;
  int v_87;
  int v_86;
  int v_85;
  int v_84;
  int v_83;
  int v_82;
  int v_81;
  int v_80;
  int v_79;
  int v_78;
  int v_77;
  int v_76;
  int v_75;
  int v_74;
  int v;
  v_106 = (right_wl<50);
  v_104 = (center_wl>200);
  v_103 = (left_wl<50);
  v_105 = (v_103&&v_104);
  v_107 = (v_105&&v_106);
  if (v_107) {
    v_108 = Adacrus__OnLine;
  } else {
    v_108 = Adacrus__Undef;
  };
  v_101 = (right_wl>200);
  v_99 = (center_wl<50);
  v_98 = (left_wl<50);
  v_100 = (v_98&&v_99);
  v_102 = (v_100&&v_101);
  if (v_102) {
    v_109 = Adacrus__LOTooRight;
  } else {
    v_109 = v_108;
  };
  v_96 = (right_wl>200);
  v_94 = (center_wl>200);
  v_93 = (left_wl<50);
  v_95 = (v_93&&v_94);
  v_97 = (v_95&&v_96);
  if (v_97) {
    v_110 = Adacrus__LORight;
  } else {
    v_110 = v_109;
  };
  v_91 = (right_wl<50);
  v_89 = (center_wl<50);
  v_88 = (left_wl>200);
  v_90 = (v_88&&v_89);
  v_92 = (v_90&&v_91);
  if (v_92) {
    v_111 = Adacrus__LOTooLeft;
  } else {
    v_111 = v_110;
  };
  v_86 = (right_wl<50);
  v_84 = (center_wl>200);
  v_83 = (left_wl>200);
  v_85 = (v_83&&v_84);
  v_87 = (v_85&&v_86);
  if (v_87) {
    v_112 = Adacrus__LOLeft;
  } else {
    v_112 = v_111;
  };
  v_81 = (right_wl<50);
  v_79 = (center_wl<50);
  v_78 = (left_wl<50);
  v_80 = (v_78&&v_79);
  v_82 = (v_80&&v_81);
  if (v_82) {
    v_113 = Adacrus__NoLine;
  } else {
    v_113 = v_112;
  };
  v_76 = (right_wl>200);
  v_74 = (center_wl>200);
  v = (left_wl>200);
  v_75 = (v&&v_74);
  v_77 = (v_75&&v_76);
  if (v_77) {
    _out->l = Adacrus__Node;
  } else {
    _out->l = v_113;
  };;
}

void Adacrus__determineLineLocInverted_step(int left_wl, int center_wl,
                                            int right_wl,
                                            Adacrus__determineLineLocInverted_out* _out) {
  
  Adacrus__lineloc v_147;
  Adacrus__lineloc v_146;
  Adacrus__lineloc v_145;
  Adacrus__lineloc v_144;
  Adacrus__lineloc v_143;
  int v_142;
  int v_141;
  int v_140;
  int v_139;
  int v_138;
  int v_137;
  int v_136;
  int v_135;
  int v_134;
  int v_133;
  int v_132;
  int v_131;
  int v_130;
  int v_129;
  int v_128;
  int v_127;
  int v_126;
  int v_125;
  int v_124;
  int v_123;
  int v_122;
  int v_121;
  int v_120;
  int v_119;
  int v_118;
  int v_117;
  int v_116;
  int v_115;
  int v_114;
  int v;
  v_141 = (right_wl>200);
  v_139 = (center_wl<50);
  v_138 = (left_wl>200);
  v_140 = (v_138&&v_139);
  v_142 = (v_140&&v_141);
  if (v_142) {
    v_143 = Adacrus__OnLine;
  } else {
    v_143 = Adacrus__Undef;
  };
  v_136 = (right_wl<50);
  v_134 = (center_wl>200);
  v_133 = (left_wl>200);
  v_135 = (v_133&&v_134);
  v_137 = (v_135&&v_136);
  if (v_137) {
    v_144 = Adacrus__LOTooRight;
  } else {
    v_144 = v_143;
  };
  v_131 = (right_wl<50);
  v_129 = (center_wl<50);
  v_128 = (left_wl>200);
  v_130 = (v_128&&v_129);
  v_132 = (v_130&&v_131);
  if (v_132) {
    v_145 = Adacrus__LORight;
  } else {
    v_145 = v_144;
  };
  v_126 = (right_wl>200);
  v_124 = (center_wl>200);
  v_123 = (left_wl<50);
  v_125 = (v_123&&v_124);
  v_127 = (v_125&&v_126);
  if (v_127) {
    v_146 = Adacrus__LOTooLeft;
  } else {
    v_146 = v_145;
  };
  v_121 = (right_wl>200);
  v_119 = (center_wl<50);
  v_118 = (left_wl<50);
  v_120 = (v_118&&v_119);
  v_122 = (v_120&&v_121);
  if (v_122) {
    v_147 = Adacrus__LOLeft;
  } else {
    v_147 = v_146;
  };
  v_116 = (right_wl>200);
  v_114 = (center_wl>200);
  v = (left_wl>200);
  v_115 = (v&&v_114);
  v_117 = (v_115&&v_116);
  if (v_117) {
    _out->l = Adacrus__NoLine;
  } else {
    _out->l = v_147;
  };;
}

void Adacrus__move_reset(Adacrus__move_mem* self) {
  Adacrus__isAllWhite_reset(&self->isAllWhite_1);
  Adacrus__isLine_reset(&self->isLine_1);
  Adacrus__isAllWhite_reset(&self->isAllWhite);
  Adacrus__isInverted_reset(&self->isInverted);
  Adacrus__isLine_reset(&self->isLine);
  self->zz_5 = 0;
  self->past_ll_5 = Adacrus__Node;
  self->pnr = false;
  self->ck_1 = Adacrus__St_In;
  self->pnr_1 = false;
  self->ck = Adacrus__St_1_In;
  self->v_188 = true;
}

void Adacrus__move_step(int left_wl, int center_wl, int right_wl, int curve,
                        int inverted, int zigzagt, int zigzagb,
                        Adacrus__move_out* _out, Adacrus__move_mem* self) {
  Adacrus__isAllWhite_out Adacrus__isAllWhite_out_st;
  Adacrus__isInverted_out Adacrus__isInverted_out_st;
  Adacrus__determineLineLocInverted_out Adacrus__determineLineLocInverted_out_st;
  Adacrus__isLine_out Adacrus__isLine_out_st;
  Adacrus__determineLineLoc_out Adacrus__determineLineLoc_out_st;
  
  int v_223;
  int r_7;
  int v_225;
  int v_224;
  int r_8;
  int nr_1_St_1_Inv;
  Adacrus__st_1 ns_1_St_1_Inv;
  Adacrus__lineloc curr_ll_St_1_Inv;
  int nr_1_St_1_In;
  Adacrus__st_1 ns_1_St_1_In;
  Adacrus__lineloc curr_ll_St_1_In;
  int v_226;
  int r_9;
  int v_227;
  int r_10;
  int v_230;
  int v_229;
  int v_228;
  int v_231;
  int r_11;
  int nr_St_MaintainBlack;
  Adacrus__st ns_St_MaintainBlack;
  int zz_St_MaintainBlack;
  int nr_St_MaintainWhite;
  Adacrus__st ns_St_MaintainWhite;
  int zz_St_MaintainWhite;
  int nr_St_ZigToZag;
  Adacrus__st ns_St_ZigToZag;
  int zz_St_ZigToZag;
  int nr_St_In;
  Adacrus__st ns_St_In;
  int zz_St_In;
  int v_222;
  int v_221;
  int v_220;
  int v_219;
  int v_218;
  int v_217;
  int v_216;
  int v_215;
  int v_214;
  int v_213;
  int v_212;
  int v_211;
  int v_210;
  int v_209;
  int v_208;
  int v_207;
  int v_206;
  int v_205;
  int v_204;
  int v_203;
  int v_202;
  int v_201;
  int v_200;
  int v_199;
  int v_198;
  int v_197;
  int v_196;
  int v_195;
  int v_194;
  int v_193;
  int v_192;
  int v_191;
  int v_187;
  int v_186;
  int v_185;
  int v_184;
  int v_183;
  int v_182;
  int v_181;
  int v_180;
  int v_179;
  int v_178;
  int v_177;
  int v_176;
  int v_175;
  int v_174;
  int v_173;
  int v_172;
  int v_171;
  int v_170;
  int v_169;
  int v_168;
  int v_167;
  int v_166;
  int v_165;
  int v_164;
  int v_163;
  int v_162;
  int v_161;
  int v_160;
  int v_159;
  int v_158;
  int v_157;
  int v_156;
  int v_155;
  int v_154;
  int v_153;
  int v_152;
  int v_151;
  int v_150;
  int v_149;
  int v_148;
  int v;
  Adacrus__st_1 ns_1;
  int r_1;
  int nr_1;
  Adacrus__st ns;
  int r;
  int nr;
  Adacrus__lineloc curr_ll;
  Adacrus__lineloc past_ll;
  int zz;
  r = self->pnr;
  r_1 = self->pnr_1;
  if (self->v_188) {
    v_192 = 0;
  } else {
    v_192 = self->v_190;
  };
  if (curve) {
    v_194 = v_192;
  } else {
    v_194 = 25;
  };
  if (self->v_188) {
    v_191 = 0;
  } else {
    v_191 = self->v_189;
  };
  if (curve) {
    v_193 = v_191;
  } else {
    v_193 = 25;
  };
  v_186 = (self->past_ll_5==Adacrus__LOTooRight);
  v_183 = (self->past_ll_5==Adacrus__LORight);
  v_180 = (self->past_ll_5==Adacrus__LOTooLeft);
  v_177 = (self->past_ll_5==Adacrus__LOLeft);
  v_174 = (self->past_ll_5==Adacrus__OnLine);
  switch (self->ck_1) {
    case Adacrus__St_In:
      zz_St_In = 0;
      r_11 = r;
      if (r_11) {
        Adacrus__isAllWhite_reset(&self->isAllWhite_1);
      };
      Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 35,
                               &Adacrus__isAllWhite_out_st,
                               &self->isAllWhite_1);
      v_231 = Adacrus__isAllWhite_out_st.out;
      if (v_231) {
        nr_St_In = true;
        ns_St_In = Adacrus__St_ZigToZag;
      } else {
        nr_St_In = false;
        ns_St_In = Adacrus__St_In;
      };
      zz = zz_St_In;
      ns = ns_St_In;
      nr = nr_St_In;
      break;
    case Adacrus__St_ZigToZag:
      v_229 = (self->zz_5==1);
      if (v_229) {
        v_230 = 2;
      } else {
        v_230 = 1;
      };
      v_228 = (self->zz_5==0);
      if (v_228) {
        zz_St_ZigToZag = 1;
      } else {
        zz_St_ZigToZag = v_230;
      };
      if (true) {
        nr_St_ZigToZag = true;
      } else {
        nr_St_ZigToZag = false;
      };
      if (true) {
        ns_St_ZigToZag = Adacrus__St_MaintainWhite;
      } else {
        ns_St_ZigToZag = Adacrus__St_ZigToZag;
      };
      zz = zz_St_ZigToZag;
      ns = ns_St_ZigToZag;
      nr = nr_St_ZigToZag;
      break;
    case Adacrus__St_MaintainWhite:
      zz_St_MaintainWhite = self->zz_5;
      r_10 = r;
      if (r_10) {
        Adacrus__isLine_reset(&self->isLine_1);
      };
      Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                           &Adacrus__isLine_out_st, &self->isLine_1);
      v_227 = Adacrus__isLine_out_st.out;
      if (v_227) {
        nr_St_MaintainWhite = true;
        ns_St_MaintainWhite = Adacrus__St_MaintainBlack;
      } else {
        nr_St_MaintainWhite = false;
        ns_St_MaintainWhite = Adacrus__St_MaintainWhite;
      };
      zz = zz_St_MaintainWhite;
      ns = ns_St_MaintainWhite;
      nr = nr_St_MaintainWhite;
      break;
    case Adacrus__St_MaintainBlack:
      zz_St_MaintainBlack = self->zz_5;
      r_9 = r;
      if (r_9) {
        Adacrus__isAllWhite_reset(&self->isAllWhite);
      };
      Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 35,
                               &Adacrus__isAllWhite_out_st, &self->isAllWhite);
      v_226 = Adacrus__isAllWhite_out_st.out;
      if (v_226) {
        nr_St_MaintainBlack = true;
        ns_St_MaintainBlack = Adacrus__St_ZigToZag;
      } else {
        nr_St_MaintainBlack = false;
        ns_St_MaintainBlack = Adacrus__St_MaintainBlack;
      };
      zz = zz_St_MaintainBlack;
      ns = ns_St_MaintainBlack;
      nr = nr_St_MaintainBlack;
      break;
    default:
      break;
  };
  switch (self->ck) {
    case Adacrus__St_1_In:
      Adacrus__determineLineLoc_step(left_wl, center_wl, right_wl,
                                     &Adacrus__determineLineLoc_out_st);
      curr_ll_St_1_In = Adacrus__determineLineLoc_out_st.l;
      r_8 = r_1;
      if (r_8) {
        Adacrus__isInverted_reset(&self->isInverted);
      };
      Adacrus__isInverted_step(left_wl, center_wl, right_wl,
                               &Adacrus__isInverted_out_st, &self->isInverted);
      v_224 = Adacrus__isInverted_out_st.out;
      v_225 = (inverted&&v_224);
      if (v_225) {
        nr_1_St_1_In = true;
        ns_1_St_1_In = Adacrus__St_1_Inv;
      } else {
        nr_1_St_1_In = false;
        ns_1_St_1_In = Adacrus__St_1_In;
      };
      curr_ll = curr_ll_St_1_In;
      ns_1 = ns_1_St_1_In;
      nr_1 = nr_1_St_1_In;
      break;
    case Adacrus__St_1_Inv:
      Adacrus__determineLineLocInverted_step(left_wl, center_wl, right_wl,
                                             &Adacrus__determineLineLocInverted_out_st);
      curr_ll_St_1_Inv = Adacrus__determineLineLocInverted_out_st.l;
      r_7 = r_1;
      if (r_7) {
        Adacrus__isLine_reset(&self->isLine);
      };
      Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                           &Adacrus__isLine_out_st, &self->isLine);
      v_223 = Adacrus__isLine_out_st.out;
      if (v_223) {
        nr_1_St_1_Inv = true;
        ns_1_St_1_Inv = Adacrus__St_1_In;
      } else {
        nr_1_St_1_Inv = false;
        ns_1_St_1_Inv = Adacrus__St_1_Inv;
      };
      curr_ll = curr_ll_St_1_Inv;
      ns_1 = ns_1_St_1_Inv;
      nr_1 = nr_1_St_1_Inv;
      break;
    default:
      break;
  };
  v_185 = (curr_ll==Adacrus__NoLine);
  v_187 = (v_185&&v_186);
  if (v_187) {
    v_196 = 0;
    v_195 = 200;
  } else {
    v_196 = v_194;
    v_195 = v_193;
  };
  v_182 = (curr_ll==Adacrus__NoLine);
  v_184 = (v_182&&v_183);
  if (v_184) {
    v_198 = 0;
    v_197 = 200;
  } else {
    v_198 = v_196;
    v_197 = v_195;
  };
  v_179 = (curr_ll==Adacrus__NoLine);
  v_181 = (v_179&&v_180);
  if (v_181) {
    v_200 = 200;
    v_199 = 0;
  } else {
    v_200 = v_198;
    v_199 = v_197;
  };
  v_176 = (curr_ll==Adacrus__NoLine);
  v_178 = (v_176&&v_177);
  if (v_178) {
    v_202 = 200;
    v_201 = 0;
  } else {
    v_202 = v_200;
    v_201 = v_199;
  };
  v_173 = (curr_ll==Adacrus__NoLine);
  v_175 = (v_173&&v_174);
  if (v_175) {
    v_204 = 50;
    v_203 = 50;
  } else {
    v_204 = v_202;
    v_203 = v_201;
  };
  v_171 = (zz==2);
  v_169 = (curr_ll==Adacrus__NoLine);
  v_170 = (v_169&&zigzagb);
  v_172 = (v_170&&v_171);
  if (v_172) {
    v_206 = 200;
    v_205 = 0;
  } else {
    v_206 = v_204;
    v_205 = v_203;
  };
  v_167 = (zz==1);
  v_165 = (curr_ll==Adacrus__NoLine);
  v_166 = (v_165&&zigzagb);
  v_168 = (v_166&&v_167);
  if (v_168) {
    v_208 = 0;
    v_207 = 200;
  } else {
    v_208 = v_206;
    v_207 = v_205;
  };
  v_163 = (zz==2);
  v_161 = (curr_ll==Adacrus__NoLine);
  v_162 = (v_161&&zigzagt);
  v_164 = (v_162&&v_163);
  if (v_164) {
    v_210 = 0;
    v_209 = 200;
  } else {
    v_210 = v_208;
    v_209 = v_207;
  };
  v_159 = (zz==1);
  v_157 = (curr_ll==Adacrus__NoLine);
  v_158 = (v_157&&zigzagt);
  v_160 = (v_158&&v_159);
  if (v_160) {
    v_212 = 200;
    v_211 = 0;
  } else {
    v_212 = v_210;
    v_211 = v_209;
  };
  v_156 = (curr_ll==Adacrus__Node);
  if (v_156) {
    v_214 = 50;
    v_213 = 50;
  } else {
    v_214 = v_212;
    v_213 = v_211;
  };
  v_155 = (curr_ll==Adacrus__LOTooRight);
  if (v_155) {
    v_216 = 0;
    v_215 = 200;
  } else {
    v_216 = v_214;
    v_215 = v_213;
  };
  v_154 = (curr_ll==Adacrus__LORight);
  if (v_154) {
    v_218 = 50;
    v_217 = 200;
  } else {
    v_218 = v_216;
    v_217 = v_215;
  };
  v_153 = (curr_ll==Adacrus__LOTooLeft);
  if (v_153) {
    v_220 = 200;
    v_219 = 0;
  } else {
    v_220 = v_218;
    v_219 = v_217;
  };
  v_152 = (curr_ll==Adacrus__LOLeft);
  if (v_152) {
    v_222 = 200;
    v_221 = 50;
  } else {
    v_222 = v_220;
    v_221 = v_219;
  };
  v_151 = (curr_ll==Adacrus__OnLine);
  if (v_151) {
    _out->v_r = 100;
    _out->v_l = 100;
  } else {
    _out->v_r = v_222;
    _out->v_l = v_221;
  };
  v_148 = (curr_ll==Adacrus__Node);
  v = (curr_ll==Adacrus__NoLine);
  v_149 = (v||v_148);
  v_150 = !(v_149);
  if (v_150) {
    past_ll = curr_ll;
  } else {
    past_ll = self->past_ll_5;
  };
  self->zz_5 = zz;
  self->past_ll_5 = past_ll;
  self->pnr = nr;
  self->ck_1 = ns;
  self->pnr_1 = nr_1;
  self->ck = ns_1;
  self->v_190 = _out->v_r;
  self->v_189 = _out->v_l;
  self->v_188 = false;;
}

void Adacrus__calcOrientation_step(Adacrus__states current_state,
                                   Adacrus__orientation last_oriented,
                                   Adacrus__calcOrientation_out* _out) {
  
  Adacrus__orientation v_277;
  Adacrus__orientation v_276;
  Adacrus__orientation v_275;
  Adacrus__orientation v_274;
  Adacrus__orientation v_273;
  Adacrus__orientation v_272;
  Adacrus__orientation v_271;
  Adacrus__orientation v_270;
  Adacrus__orientation v_269;
  Adacrus__orientation v_268;
  Adacrus__orientation v_267;
  int v_266;
  int v_265;
  int v_264;
  int v_263;
  int v_262;
  int v_261;
  int v_260;
  int v_259;
  int v_258;
  int v_257;
  int v_256;
  int v_255;
  int v_254;
  int v_253;
  int v_252;
  int v_251;
  int v_250;
  int v_249;
  int v_248;
  int v_247;
  int v_246;
  int v_245;
  int v_244;
  int v_243;
  int v_242;
  int v_241;
  int v_240;
  int v_239;
  int v_238;
  int v_237;
  int v_236;
  int v_235;
  int v_234;
  int v_233;
  int v_232;
  int v;
  v_265 = (current_state==Adacrus__Rot180);
  v_264 = (last_oriented==Adacrus__B);
  v_266 = (v_264&&v_265);
  if (v_266) {
    v_267 = Adacrus__T;
  } else {
    v_267 = last_oriented;
  };
  v_262 = (current_state==Adacrus__RotR);
  v_261 = (last_oriented==Adacrus__B);
  v_263 = (v_261&&v_262);
  if (v_263) {
    v_268 = Adacrus__L;
  } else {
    v_268 = v_267;
  };
  v_259 = (current_state==Adacrus__RotL);
  v_258 = (last_oriented==Adacrus__B);
  v_260 = (v_258&&v_259);
  if (v_260) {
    v_269 = Adacrus__R;
  } else {
    v_269 = v_268;
  };
  v_256 = (current_state==Adacrus__Rot180);
  v_255 = (last_oriented==Adacrus__L);
  v_257 = (v_255&&v_256);
  if (v_257) {
    v_270 = Adacrus__R;
  } else {
    v_270 = v_269;
  };
  v_253 = (current_state==Adacrus__RotR);
  v_252 = (last_oriented==Adacrus__L);
  v_254 = (v_252&&v_253);
  if (v_254) {
    v_271 = Adacrus__T;
  } else {
    v_271 = v_270;
  };
  v_250 = (current_state==Adacrus__RotL);
  v_249 = (last_oriented==Adacrus__L);
  v_251 = (v_249&&v_250);
  if (v_251) {
    v_272 = Adacrus__B;
  } else {
    v_272 = v_271;
  };
  v_247 = (current_state==Adacrus__Rot180);
  v_246 = (last_oriented==Adacrus__R);
  v_248 = (v_246&&v_247);
  if (v_248) {
    v_273 = Adacrus__L;
  } else {
    v_273 = v_272;
  };
  v_244 = (current_state==Adacrus__RotR);
  v_243 = (last_oriented==Adacrus__R);
  v_245 = (v_243&&v_244);
  if (v_245) {
    v_274 = Adacrus__B;
  } else {
    v_274 = v_273;
  };
  v_241 = (current_state==Adacrus__RotL);
  v_240 = (last_oriented==Adacrus__R);
  v_242 = (v_240&&v_241);
  if (v_242) {
    v_275 = Adacrus__T;
  } else {
    v_275 = v_274;
  };
  v_238 = (current_state==Adacrus__Rot180);
  v_237 = (last_oriented==Adacrus__T);
  v_239 = (v_237&&v_238);
  if (v_239) {
    v_276 = Adacrus__B;
  } else {
    v_276 = v_275;
  };
  v_235 = (current_state==Adacrus__RotR);
  v_234 = (last_oriented==Adacrus__T);
  v_236 = (v_234&&v_235);
  if (v_236) {
    v_277 = Adacrus__R;
  } else {
    v_277 = v_276;
  };
  v_232 = (current_state==Adacrus__RotL);
  v = (last_oriented==Adacrus__T);
  v_233 = (v&&v_232);
  if (v_233) {
    _out->new_orientation = Adacrus__L;
  } else {
    _out->new_orientation = v_277;
  };;
}

void Adacrus__getNextNodeAndState_reset(Adacrus__getNextNodeAndState_mem* self) {
  self->v_434 = true;
  self->v_424 = true;
  self->v_414 = true;
  self->v_404 = true;
  self->v_389 = true;
  self->v_305 = true;
}

void Adacrus__getNextNodeAndState_step(Adacrus__coordinates current_node,
                                       Adacrus__coordinates goal_node,
                                       Adacrus__orientation oriented,
                                       int ir_prox,
                                       Adacrus__getNextNodeAndState_out* _out,
                                       Adacrus__getNextNodeAndState_mem* self) {
  
  Adacrus__coordinates v_446;
  Adacrus__coordinates v_445;
  Adacrus__coordinates v_444;
  Adacrus__coordinates v_443;
  Adacrus__coordinates v_442;
  int v_441;
  int v_440;
  int v_439;
  int v_438;
  int v_437;
  int v_436;
  int v_433;
  Adacrus__coordinates v_432;
  int v_431;
  int v_430;
  int v_429;
  int v_428;
  int v_427;
  int v_426;
  int v_423;
  Adacrus__coordinates v_422;
  int v_421;
  int v_420;
  int v_419;
  int v_418;
  int v_417;
  int v_416;
  int v_413;
  Adacrus__coordinates v_412;
  int v_411;
  int v_410;
  int v_409;
  int v_408;
  int v_407;
  int v_406;
  int v_403;
  int v_402;
  int v_401;
  int v_400;
  int v_399;
  int v_398;
  Adacrus__states v_397;
  int v_396;
  int v_395;
  int v_394;
  int v_393;
  int v_392;
  int v_391;
  int v_388;
  Adacrus__states v_387;
  Adacrus__states v_386;
  Adacrus__states v_385;
  Adacrus__states v_384;
  Adacrus__states v_383;
  Adacrus__states v_382;
  Adacrus__states v_381;
  Adacrus__states v_380;
  Adacrus__states v_379;
  Adacrus__states v_378;
  Adacrus__states v_377;
  Adacrus__states v_376;
  Adacrus__states v_375;
  Adacrus__states v_374;
  Adacrus__states v_373;
  int v_372;
  int v_371;
  int v_370;
  int v_369;
  int v_368;
  int v_367;
  int v_366;
  int v_365;
  int v_364;
  int v_363;
  int v_362;
  int v_361;
  int v_360;
  int v_359;
  int v_358;
  int v_357;
  int v_356;
  int v_355;
  int v_354;
  int v_353;
  int v_352;
  int v_351;
  int v_350;
  int v_349;
  int v_348;
  int v_347;
  int v_346;
  int v_345;
  int v_344;
  int v_343;
  int v_342;
  int v_341;
  int v_340;
  int v_339;
  int v_338;
  int v_337;
  int v_336;
  int v_335;
  int v_334;
  int v_333;
  int v_332;
  int v_331;
  int v_330;
  int v_329;
  int v_328;
  int v_327;
  int v_326;
  int v_325;
  int v_324;
  int v_323;
  int v_322;
  int v_321;
  int v_320;
  int v_319;
  int v_318;
  int v_317;
  int v_316;
  int v_315;
  int v_314;
  int v_313;
  int v_312;
  int v_311;
  int v_310;
  int v_309;
  int v_308;
  int v_307;
  int v_304;
  Adacrus__coordinates v_303;
  Adacrus__coordinates v_302;
  Adacrus__coordinates v_301;
  Adacrus__coordinates v_300;
  int v_299;
  int v_298;
  int v_297;
  int v_296;
  Adacrus__coordinates v_295;
  int v_294;
  int v_293;
  int v_292;
  int v_291;
  Adacrus__coordinates v_290;
  int v_289;
  int v_288;
  int v_287;
  int v_286;
  Adacrus__coordinates v_285;
  int v_284;
  int v_283;
  int v_282;
  int v_281;
  int v_280;
  int v_279;
  int v_278;
  int v;
  int x_diff;
  int y_diff;
  int x_abs_diff;
  int y_abs_diff;
  int prox_count;
  Adacrus__coordinates inter_node;
  Adacrus__states inter_state;
  v_441 = (current_node.x+1);
  v_439 = (oriented==Adacrus__R);
  if (self->v_434) {
    v_436 = 0;
  } else {
    v_436 = self->v_435;
  };
  v_437 = (v_436>0);
  v_431 = (current_node.x-1);
  v_429 = (oriented==Adacrus__L);
  if (self->v_424) {
    v_426 = 0;
  } else {
    v_426 = self->v_425;
  };
  v_427 = (v_426>0);
  v_421 = (current_node.y-1);
  v_419 = (oriented==Adacrus__B);
  if (self->v_414) {
    v_416 = 0;
  } else {
    v_416 = self->v_415;
  };
  v_417 = (v_416>0);
  v_411 = (current_node.y+1);
  v_409 = (oriented==Adacrus__T);
  if (self->v_404) {
    v_406 = 0;
  } else {
    v_406 = self->v_405;
  };
  v_407 = (v_406>0);
  if (self->v_389) {
    v_391 = 0;
  } else {
    v_391 = self->v_390;
  };
  v_392 = (v_391>0);
  v_371 = (oriented==Adacrus__B);
  v_367 = (oriented==Adacrus__T);
  v_363 = (oriented==Adacrus__L);
  v_359 = (oriented==Adacrus__R);
  v_355 = (oriented==Adacrus__B);
  v_351 = (oriented==Adacrus__T);
  v_347 = (oriented==Adacrus__L);
  v_343 = (oriented==Adacrus__R);
  v_339 = (oriented==Adacrus__B);
  v_335 = (oriented==Adacrus__T);
  v_331 = (oriented==Adacrus__L);
  v_327 = (oriented==Adacrus__R);
  v_323 = (oriented==Adacrus__B);
  v_319 = (oriented==Adacrus__L);
  v_315 = (oriented==Adacrus__T);
  v_311 = (oriented==Adacrus__R);
  if (self->v_305) {
    v_307 = 0;
  } else {
    v_307 = self->v_306;
  };
  v_308 = (v_307+1);
  v_304 = (ir_prox<190);
  if (v_304) {
    prox_count = v_308;
  } else {
    prox_count = 0;
  };
  v_433 = (prox_count==0);
  v_438 = (v_433&&v_437);
  v_440 = (v_438&&v_439);
  v_423 = (prox_count==0);
  v_428 = (v_423&&v_427);
  v_430 = (v_428&&v_429);
  v_413 = (prox_count==0);
  v_418 = (v_413&&v_417);
  v_420 = (v_418&&v_419);
  v_403 = (prox_count==0);
  v_408 = (v_403&&v_407);
  v_410 = (v_408&&v_409);
  v_394 = (prox_count>0);
  v_388 = (prox_count==0);
  v_393 = (v_388&&v_392);
  v_299 = (current_node.x-1);
  v_294 = (current_node.x+1);
  v_289 = (current_node.y+1);
  v_284 = (current_node.y-1);
  y_diff = (goal_node.y-current_node.y);
  x_diff = (goal_node.x-current_node.x);
  v_297 = (x_diff<0);
  v_292 = (x_diff>0);
  v_287 = (y_diff>0);
  v_282 = (y_diff<0);
  v_280 = -(y_diff);
  v_279 = (y_diff<0);
  if (v_279) {
    y_abs_diff = v_280;
  } else {
    y_abs_diff = y_diff;
  };
  v_286 = (y_abs_diff>0);
  v_288 = (v_286&&v_287);
  v_281 = (y_abs_diff>0);
  v_283 = (v_281&&v_282);
  v_278 = -(x_diff);
  v = (x_diff<0);
  if (v) {
    x_abs_diff = v_278;
  } else {
    x_abs_diff = x_diff;
  };
  v_296 = (x_abs_diff>0);
  v_298 = (v_296&&v_297);
  v_291 = (x_abs_diff>0);
  v_293 = (v_291&&v_292);
  v_442 = current_node;
  v_442.x = v_441;
  v_432 = current_node;
  v_432.x = v_431;
  v_422 = current_node;
  v_422.y = v_421;
  v_412 = current_node;
  v_412.y = v_411;
  v_300 = current_node;
  v_300.x = v_299;
  if (v_298) {
    v_301 = v_300;
  } else {
    v_301 = current_node;
  };
  v_295 = current_node;
  v_295.x = v_294;
  if (v_293) {
    v_302 = v_295;
  } else {
    v_302 = v_301;
  };
  v_290 = current_node;
  v_290.y = v_289;
  if (v_288) {
    v_303 = v_290;
  } else {
    v_303 = v_302;
  };
  v_285 = current_node;
  v_285.y = v_284;
  if (v_283) {
    inter_node = v_285;
  } else {
    inter_node = v_303;
  };
  if (v_440) {
    v_443 = v_442;
  } else {
    v_443 = inter_node;
  };
  if (v_430) {
    v_444 = v_432;
  } else {
    v_444 = v_443;
  };
  if (v_420) {
    v_445 = v_422;
  } else {
    v_445 = v_444;
  };
  if (v_410) {
    v_446 = v_412;
  } else {
    v_446 = v_445;
  };
  v_369 = (inter_node.y-current_node.y);
  v_370 = (v_369==-1);
  v_372 = (v_370&&v_371);
  if (v_372) {
    v_373 = Adacrus__Moving;
  } else {
    v_373 = Adacrus__Exit;
  };
  v_365 = (inter_node.y-current_node.y);
  v_366 = (v_365==-1);
  v_368 = (v_366&&v_367);
  if (v_368) {
    v_374 = Adacrus__Rot180;
  } else {
    v_374 = v_373;
  };
  v_361 = (inter_node.y-current_node.y);
  v_362 = (v_361==-1);
  v_364 = (v_362&&v_363);
  if (v_364) {
    v_375 = Adacrus__RotL;
  } else {
    v_375 = v_374;
  };
  v_357 = (inter_node.y-current_node.y);
  v_358 = (v_357==-1);
  v_360 = (v_358&&v_359);
  if (v_360) {
    v_376 = Adacrus__RotR;
  } else {
    v_376 = v_375;
  };
  v_353 = (inter_node.y-current_node.y);
  v_354 = (v_353==1);
  v_356 = (v_354&&v_355);
  if (v_356) {
    v_377 = Adacrus__Rot180;
  } else {
    v_377 = v_376;
  };
  v_349 = (inter_node.y-current_node.y);
  v_350 = (v_349==1);
  v_352 = (v_350&&v_351);
  if (v_352) {
    v_378 = Adacrus__Moving;
  } else {
    v_378 = v_377;
  };
  v_345 = (inter_node.y-current_node.y);
  v_346 = (v_345==1);
  v_348 = (v_346&&v_347);
  if (v_348) {
    v_379 = Adacrus__RotR;
  } else {
    v_379 = v_378;
  };
  v_341 = (inter_node.y-current_node.y);
  v_342 = (v_341==1);
  v_344 = (v_342&&v_343);
  if (v_344) {
    v_380 = Adacrus__RotL;
  } else {
    v_380 = v_379;
  };
  v_337 = (inter_node.x-current_node.x);
  v_338 = (v_337==-1);
  v_340 = (v_338&&v_339);
  if (v_340) {
    v_381 = Adacrus__RotR;
  } else {
    v_381 = v_380;
  };
  v_333 = (inter_node.x-current_node.x);
  v_334 = (v_333==-1);
  v_336 = (v_334&&v_335);
  if (v_336) {
    v_382 = Adacrus__RotL;
  } else {
    v_382 = v_381;
  };
  v_329 = (inter_node.x-current_node.x);
  v_330 = (v_329==-1);
  v_332 = (v_330&&v_331);
  if (v_332) {
    v_383 = Adacrus__Moving;
  } else {
    v_383 = v_382;
  };
  v_325 = (inter_node.x-current_node.x);
  v_326 = (v_325==-1);
  v_328 = (v_326&&v_327);
  if (v_328) {
    v_384 = Adacrus__Rot180;
  } else {
    v_384 = v_383;
  };
  v_321 = (inter_node.x-current_node.x);
  v_322 = (v_321==1);
  v_324 = (v_322&&v_323);
  if (v_324) {
    v_385 = Adacrus__RotL;
  } else {
    v_385 = v_384;
  };
  v_317 = (inter_node.x-current_node.x);
  v_318 = (v_317==1);
  v_320 = (v_318&&v_319);
  if (v_320) {
    v_386 = Adacrus__Rot180;
  } else {
    v_386 = v_385;
  };
  v_313 = (inter_node.x-current_node.x);
  v_309 = (inter_node.x-current_node.x);
  v_314 = (v_313==1);
  v_316 = (v_314&&v_315);
  if (v_316) {
    v_387 = Adacrus__RotR;
  } else {
    v_387 = v_386;
  };
  v_310 = (v_309==1);
  v_312 = (v_310&&v_311);
  if (v_312) {
    inter_state = Adacrus__Moving;
  } else {
    inter_state = v_387;
  };
  v_395 = (inter_state==Adacrus__Moving);
  v_396 = (v_394&&v_395);
  if (v_396) {
    v_397 = Adacrus__RotR;
  } else {
    v_397 = inter_state;
  };
  if (v_393) {
    _out->next_state = Adacrus__Moving;
  } else {
    _out->next_state = v_397;
  };
  v_401 = (_out->next_state==Adacrus__Rot180);
  v_399 = (_out->next_state==Adacrus__RotL);
  v_398 = (_out->next_state==Adacrus__RotR);
  v_400 = (v_398||v_399);
  v_402 = (v_400||v_401);
  if (v_402) {
    _out->next_node = current_node;
  } else {
    _out->next_node = v_446;
  };
  self->v_435 = prox_count;
  self->v_434 = false;
  self->v_425 = prox_count;
  self->v_424 = false;
  self->v_415 = prox_count;
  self->v_414 = false;
  self->v_405 = prox_count;
  self->v_404 = false;
  self->v_390 = prox_count;
  self->v_389 = false;
  self->v_306 = prox_count;
  self->v_305 = false;;
}

void Adacrus__decideAction_reset(Adacrus__decideAction_mem* self) {
  Adacrus__getNextNodeAndState_reset(&self->getNextNodeAndState_1);
  Adacrus__getNextNodeAndState_reset(&self->getNextNodeAndState);
  self->v_454 = true;
  self->v_448 = true;
}

void Adacrus__decideAction_step(Adacrus__coordinates current_node,
                                Adacrus__states last_state,
                                Adacrus__orientation oriented, int ir_prox,
                                Adacrus__decideAction_out* _out,
                                Adacrus__decideAction_mem* self) {
  Adacrus__getNextNodeAndState_out Adacrus__getNextNodeAndState_out_st;
  
  Adacrus__states v_462;
  Adacrus__coordinates v_461;
  Adacrus__coordinates v_460;
  Adacrus__states v_459;
  Adacrus__coordinates v_458;
  Adacrus__states v_457;
  Adacrus__coordinates v_456;
  int v_455;
  int v_453;
  int v_452;
  int v_451;
  int v_450;
  int v_447;
  int v;
  int is_goal;
  int start_reached;
  v_451 = (current_node.y==Adacrus__start.y);
  v_450 = (current_node.x==Adacrus__start.x);
  v_452 = (v_450&&v_451);
  if (self->v_449) {
    v_453 = true;
  } else {
    v_453 = v_452;
  };
  if (self->v_448) {
    start_reached = false;
  } else {
    start_reached = v_453;
  };
  v_455 = !(start_reached);
  v_447 = (current_node.y==Adacrus__goal.y);
  v = (current_node.x==Adacrus__goal.x);
  is_goal = (v&&v_447);
  v_460.y = 1;
  v_460.x = 4;
  Adacrus__getNextNodeAndState_step(current_node, Adacrus__goal, oriented,
                                    ir_prox,
                                    &Adacrus__getNextNodeAndState_out_st,
                                    &self->getNextNodeAndState_1);
  v_458 = Adacrus__getNextNodeAndState_out_st.next_node;
  v_459 = Adacrus__getNextNodeAndState_out_st.next_state;
  Adacrus__getNextNodeAndState_step(current_node, Adacrus__start, oriented,
                                    ir_prox,
                                    &Adacrus__getNextNodeAndState_out_st,
                                    &self->getNextNodeAndState);
  v_456 = Adacrus__getNextNodeAndState_out_st.next_node;
  v_457 = Adacrus__getNextNodeAndState_out_st.next_state;
  if (v_455) {
    v_461 = v_456;
  } else {
    v_461 = v_458;
  };
  if (self->v_454) {
    _out->next_node = v_460;
  } else {
    _out->next_node = v_461;
  };
  if (v_455) {
    v_462 = v_457;
  } else {
    v_462 = v_459;
  };
  if (self->v_454) {
    _out->next_state = Adacrus__RotL;
  } else {
    _out->next_state = v_462;
  };
  self->v_454 = false;
  self->v_449 = start_reached;
  self->v_448 = false;;
}

void Adacrus__adacrus_params_35__reset(Adacrus__adacrus_params_35__mem* self) {
  Adacrus__move_reset(&self->move_4);
  Adacrus__isNode_reset(&self->isNode);
  Adacrus__move_reset(&self->move);
  Adacrus__move_reset(&self->move_1);
  Adacrus__move_reset(&self->move_2);
  Adacrus__move_reset(&self->move_3);
  Adacrus__isLine_reset(&self->isLine_5);
  Adacrus__isAllWhite_reset(&self->isAllWhite_2);
  Adacrus__isLine_reset(&self->isLine_4);
  Adacrus__isAllWhite_reset(&self->isAllWhite);
  Adacrus__isLine_reset(&self->isLine_3);
  Adacrus__isLine_reset(&self->isLine_2);
  Adacrus__isLine_reset(&self->isLine);
  Adacrus__decideAction_reset(&self->decideAction);
  self->debug_state_1 = Adacrus__Initial;
  self->current_state_2 = Adacrus__Initial;
  self->oriented_4 = Adacrus__T;
  self->next_node_5.y = 1;
  self->next_node_5.x = 3;
  self->pnr_6 = false;
  self->v_579 = true;
  self->v_572 = false;
  self->v_571 = false;
  self->v_570 = Adacrus__St_3_Decidado;
  self->v_532 = false;
  self->v_531 = false;
  self->v_530 = Adacrus__St_4_GoAhead;
  self->v_509 = false;
  self->v_508 = false;
  self->v_507 = Adacrus__St_5_GoAhead;
  self->v_486 = false;
  self->v_485 = false;
  self->v_484 = Adacrus__St_6_GoAhead;
  self->v_568 = false;
  self->v_566 = Adacrus__St_2_TryLeft;
  self->v_559 = true;
  self->v_552 = true;
  self->v_525 = true;
  self->v_519 = true;
  self->v_513 = true;
  self->v_502 = true;
  self->v_496 = true;
  self->v_490 = true;
  self->v_479 = true;
  self->v_473 = true;
  self->v_465 = true;
  self->ck = Adacrus__St_7_Initial;
}

void Adacrus__adacrus_params_35__step(int left_wl, int center_wl,
                                      int right_wl, int ir_prox,
                                      Adacrus__adacrus_params_35__out* _out,
                                      Adacrus__adacrus_params_35__mem* self) {
  Adacrus__halt_out Adacrus__halt_out_st;
  Adacrus__calcOrientation_out Adacrus__calcOrientation_out_st;
  Adacrus__isLine_out Adacrus__isLine_out_st;
  Adacrus__notIsNode_out Adacrus__notIsNode_out_st;
  Adacrus__isAllWhite_out Adacrus__isAllWhite_out_st;
  Adacrus__isNode_out Adacrus__isNode_out_st;
  Adacrus__move_out Adacrus__move_out_st;
  Adacrus__decideAction_out Adacrus__decideAction_out_st;
  
  int v_469;
  int v_467;
  int v_466;
  int v_464;
  int v_463;
  int v;
  int r_12;
  int t_right_again;
  int v_477;
  int v_475;
  int v_474;
  int v_472;
  int v_471;
  int v_470;
  int r_13;
  int t_right_3;
  int v_483;
  int v_481;
  int v_480;
  int v_478;
  int t_forward_2;
  int nr_5_St_6_Exit;
  Adacrus__st_6 ns_5_St_6_Exit;
  int exit_3_St_6_Exit;
  Adacrus__states debug_state_St_7_Rot180_St_6_Exit;
  Adacrus__direction dir_St_7_Rot180_St_6_Exit;
  int v_r_St_7_Rot180_St_6_Exit;
  int v_l_St_7_Rot180_St_6_Exit;
  int nr_5_St_6_TurnRightAgain;
  Adacrus__st_6 ns_5_St_6_TurnRightAgain;
  int exit_3_St_6_TurnRightAgain;
  Adacrus__states debug_state_St_7_Rot180_St_6_TurnRightAgain;
  Adacrus__direction dir_St_7_Rot180_St_6_TurnRightAgain;
  int v_r_St_7_Rot180_St_6_TurnRightAgain;
  int v_l_St_7_Rot180_St_6_TurnRightAgain;
  int nr_5_St_6_TurnRight;
  Adacrus__st_6 ns_5_St_6_TurnRight;
  int exit_3_St_6_TurnRight;
  Adacrus__states debug_state_St_7_Rot180_St_6_TurnRight;
  Adacrus__direction dir_St_7_Rot180_St_6_TurnRight;
  int v_r_St_7_Rot180_St_6_TurnRight;
  int v_l_St_7_Rot180_St_6_TurnRight;
  int nr_5_St_6_GoAhead;
  Adacrus__st_6 ns_5_St_6_GoAhead;
  int exit_3_St_6_GoAhead;
  Adacrus__states debug_state_St_7_Rot180_St_6_GoAhead;
  Adacrus__direction dir_St_7_Rot180_St_6_GoAhead;
  int v_r_St_7_Rot180_St_6_GoAhead;
  int v_l_St_7_Rot180_St_6_GoAhead;
  Adacrus__st_6 ck_6;
  Adacrus__st_6 ns_5;
  int r_5;
  int nr_5;
  int pnr_5;
  int exit_3_1;
  int exit_3;
  int v_494;
  int v_492;
  int v_491;
  int v_489;
  int v_488;
  int v_487;
  int r_14;
  int t_right_2;
  int v_500;
  int v_498;
  int v_497;
  int v_495;
  int r_15;
  int t_right_1;
  int v_506;
  int v_504;
  int v_503;
  int v_501;
  int t_forward_1;
  int nr_4_St_5_Exit;
  Adacrus__st_5 ns_4_St_5_Exit;
  int exit_2_St_5_Exit;
  Adacrus__states debug_state_St_7_RotR_St_5_Exit;
  Adacrus__direction dir_St_7_RotR_St_5_Exit;
  int v_r_St_7_RotR_St_5_Exit;
  int v_l_St_7_RotR_St_5_Exit;
  int nr_4_St_5_TurnRight;
  Adacrus__st_5 ns_4_St_5_TurnRight;
  int exit_2_St_5_TurnRight;
  Adacrus__states debug_state_St_7_RotR_St_5_TurnRight;
  Adacrus__direction dir_St_7_RotR_St_5_TurnRight;
  int v_r_St_7_RotR_St_5_TurnRight;
  int v_l_St_7_RotR_St_5_TurnRight;
  int nr_4_St_5_BlackToWhite;
  Adacrus__st_5 ns_4_St_5_BlackToWhite;
  int exit_2_St_5_BlackToWhite;
  Adacrus__states debug_state_St_7_RotR_St_5_BlackToWhite;
  Adacrus__direction dir_St_7_RotR_St_5_BlackToWhite;
  int v_r_St_7_RotR_St_5_BlackToWhite;
  int v_l_St_7_RotR_St_5_BlackToWhite;
  int nr_4_St_5_GoAhead;
  Adacrus__st_5 ns_4_St_5_GoAhead;
  int exit_2_St_5_GoAhead;
  Adacrus__states debug_state_St_7_RotR_St_5_GoAhead;
  Adacrus__direction dir_St_7_RotR_St_5_GoAhead;
  int v_r_St_7_RotR_St_5_GoAhead;
  int v_l_St_7_RotR_St_5_GoAhead;
  Adacrus__st_5 ck_5;
  Adacrus__st_5 ns_4;
  int r_4;
  int nr_4;
  int pnr_4;
  int exit_2_1;
  int exit_2;
  int v_517;
  int v_515;
  int v_514;
  int v_512;
  int v_511;
  int v_510;
  int r_16;
  int t_left_2;
  int v_523;
  int v_521;
  int v_520;
  int v_518;
  int r_17;
  int t_left_1;
  int v_529;
  int v_527;
  int v_526;
  int v_524;
  int t_forward;
  int nr_3_St_4_Exit;
  Adacrus__st_4 ns_3_St_4_Exit;
  int exit_1_St_4_Exit;
  Adacrus__states debug_state_St_7_RotL_St_4_Exit;
  Adacrus__direction dir_St_7_RotL_St_4_Exit;
  int v_r_St_7_RotL_St_4_Exit;
  int v_l_St_7_RotL_St_4_Exit;
  int nr_3_St_4_TurnLeft;
  Adacrus__st_4 ns_3_St_4_TurnLeft;
  int exit_1_St_4_TurnLeft;
  Adacrus__states debug_state_St_7_RotL_St_4_TurnLeft;
  Adacrus__direction dir_St_7_RotL_St_4_TurnLeft;
  int v_r_St_7_RotL_St_4_TurnLeft;
  int v_l_St_7_RotL_St_4_TurnLeft;
  int nr_3_St_4_BlackToWhite;
  Adacrus__st_4 ns_3_St_4_BlackToWhite;
  int exit_1_St_4_BlackToWhite;
  Adacrus__states debug_state_St_7_RotL_St_4_BlackToWhite;
  Adacrus__direction dir_St_7_RotL_St_4_BlackToWhite;
  int v_r_St_7_RotL_St_4_BlackToWhite;
  int v_l_St_7_RotL_St_4_BlackToWhite;
  int nr_3_St_4_GoAhead;
  Adacrus__st_4 ns_3_St_4_GoAhead;
  int exit_1_St_4_GoAhead;
  Adacrus__states debug_state_St_7_RotL_St_4_GoAhead;
  Adacrus__direction dir_St_7_RotL_St_4_GoAhead;
  int v_r_St_7_RotL_St_4_GoAhead;
  int v_l_St_7_RotL_St_4_GoAhead;
  Adacrus__st_4 ck_4;
  Adacrus__st_4 ns_3;
  int r_3;
  int nr_3;
  int pnr_3;
  int exit_1_1;
  int exit_1;
  int v_557;
  int v_555;
  int v_554;
  int v_553;
  int v_551;
  int t_right;
  int v_564;
  int v_562;
  int v_561;
  int v_560;
  int v_558;
  int t_left;
  int v_565;
  int nr_St_2_TryRight;
  Adacrus__st_2 ns_St_2_TryRight;
  Adacrus__direction dir_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight;
  int v_r_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight;
  int v_l_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight;
  int nr_St_2_TryLeft;
  Adacrus__st_2 ns_St_2_TryLeft;
  Adacrus__direction dir_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft;
  int v_r_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft;
  int v_l_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft;
  Adacrus__st_2 ck_3;
  int v_567;
  int r_18;
  Adacrus__st_2 ns;
  int r;
  int nr;
  int pnr;
  int v_569;
  int r_19;
  int nr_2_St_3_CenterAlign;
  Adacrus__st_3 ns_2_St_3_CenterAlign;
  Adacrus__states next_state_St_3_CenterAlign;
  int out_of_node_St_3_CenterAlign;
  Adacrus__states debug_state_St_7_DecideAction_St_3_CenterAlign;
  Adacrus__orientation oriented_St_7_DecideAction_St_3_CenterAlign;
  Adacrus__coordinates next_node_St_7_DecideAction_St_3_CenterAlign;
  Adacrus__direction dir_St_7_DecideAction_St_3_CenterAlign;
  int v_r_St_7_DecideAction_St_3_CenterAlign;
  int v_l_St_7_DecideAction_St_3_CenterAlign;
  int nr_2_St_3_LeaveNode;
  Adacrus__st_3 ns_2_St_3_LeaveNode;
  Adacrus__states next_state_St_3_LeaveNode;
  int out_of_node_St_3_LeaveNode;
  Adacrus__states debug_state_St_7_DecideAction_St_3_LeaveNode;
  Adacrus__orientation oriented_St_7_DecideAction_St_3_LeaveNode;
  Adacrus__coordinates next_node_St_7_DecideAction_St_3_LeaveNode;
  Adacrus__direction dir_St_7_DecideAction_St_3_LeaveNode;
  int v_r_St_7_DecideAction_St_3_LeaveNode;
  int v_l_St_7_DecideAction_St_3_LeaveNode;
  int nr_2_St_3_Decidado;
  Adacrus__st_3 ns_2_St_3_Decidado;
  Adacrus__states next_state_St_3_Decidado;
  int out_of_node_St_3_Decidado;
  Adacrus__states debug_state_St_7_DecideAction_St_3_Decidado;
  Adacrus__orientation oriented_St_7_DecideAction_St_3_Decidado;
  Adacrus__coordinates next_node_St_7_DecideAction_St_3_Decidado;
  Adacrus__direction dir_St_7_DecideAction_St_3_Decidado;
  int v_r_St_7_DecideAction_St_3_Decidado;
  int v_l_St_7_DecideAction_St_3_Decidado;
  Adacrus__st_3 ck_2;
  int v_550;
  Adacrus__st_7 v_549;
  int v_548;
  Adacrus__st_7 v_547;
  int v_546;
  Adacrus__st_7 v_545;
  int v_544;
  Adacrus__st_7 v_543;
  int v_542;
  int v_541;
  int v_540;
  int v_539;
  int v_538;
  int v_537;
  int v_536;
  int v_535;
  int v_534;
  int v_533;
  Adacrus__st_3 ns_2;
  int r_2;
  int nr_2;
  int pnr_2;
  int out_of_node_1;
  int out_of_node;
  Adacrus__states next_state;
  int v_612;
  int v_611;
  int v_610;
  int v_609;
  int v_608;
  int v_607;
  int v_606;
  int v_605;
  int v_604;
  int v_603;
  int v_602;
  int v_601;
  int v_600;
  int v_599;
  int v_598;
  int v_597;
  int v_596;
  int v_595;
  int v_594;
  int v_593;
  int v_592;
  int v_591;
  int v_590;
  int v_589;
  int v_588;
  int v_587;
  int v_586;
  int v_585;
  int v_584;
  int v_583;
  int v_582;
  int v_580;
  int v_578;
  int v_577;
  int v_576;
  int v_575;
  int v_574;
  int v_573;
  int r_24;
  int r_23;
  int r_22;
  int r_21;
  int r_20;
  int inverted_section;
  int exit;
  int inverted_t;
  int v_613;
  int r_25;
  int nr_6_St_7_Rot180;
  Adacrus__st_7 ns_6_St_7_Rot180;
  Adacrus__states debug_state_St_7_Rot180;
  Adacrus__states current_state_St_7_Rot180;
  Adacrus__orientation oriented_St_7_Rot180;
  Adacrus__coordinates next_node_St_7_Rot180;
  Adacrus__direction dir_St_7_Rot180;
  int v_r_St_7_Rot180;
  int v_l_St_7_Rot180;
  int nr_6_St_7_RotR;
  Adacrus__st_7 ns_6_St_7_RotR;
  Adacrus__states debug_state_St_7_RotR;
  Adacrus__states current_state_St_7_RotR;
  Adacrus__orientation oriented_St_7_RotR;
  Adacrus__coordinates next_node_St_7_RotR;
  Adacrus__direction dir_St_7_RotR;
  int v_r_St_7_RotR;
  int v_l_St_7_RotR;
  int nr_6_St_7_RotL;
  Adacrus__st_7 ns_6_St_7_RotL;
  Adacrus__states debug_state_St_7_RotL;
  Adacrus__states current_state_St_7_RotL;
  Adacrus__orientation oriented_St_7_RotL;
  Adacrus__coordinates next_node_St_7_RotL;
  Adacrus__direction dir_St_7_RotL;
  int v_r_St_7_RotL;
  int v_l_St_7_RotL;
  int nr_6_St_7_DecideAction;
  Adacrus__st_7 ns_6_St_7_DecideAction;
  Adacrus__states debug_state_St_7_DecideAction;
  Adacrus__states current_state_St_7_DecideAction;
  Adacrus__orientation oriented_St_7_DecideAction;
  Adacrus__coordinates next_node_St_7_DecideAction;
  Adacrus__direction dir_St_7_DecideAction;
  int v_r_St_7_DecideAction;
  int v_l_St_7_DecideAction;
  int nr_6_St_7_Exit;
  Adacrus__st_7 ns_6_St_7_Exit;
  Adacrus__states debug_state_St_7_Exit;
  Adacrus__states current_state_St_7_Exit;
  Adacrus__orientation oriented_St_7_Exit;
  Adacrus__coordinates next_node_St_7_Exit;
  Adacrus__direction dir_St_7_Exit;
  int v_r_St_7_Exit;
  int v_l_St_7_Exit;
  int nr_6_St_7_Moving;
  Adacrus__st_7 ns_6_St_7_Moving;
  Adacrus__states debug_state_St_7_Moving;
  Adacrus__states current_state_St_7_Moving;
  Adacrus__orientation oriented_St_7_Moving;
  Adacrus__coordinates next_node_St_7_Moving;
  Adacrus__direction dir_St_7_Moving;
  int v_r_St_7_Moving;
  int v_l_St_7_Moving;
  int nr_6_St_7_Initial;
  Adacrus__st_7 ns_6_St_7_Initial;
  Adacrus__states debug_state_St_7_Initial;
  Adacrus__states current_state_St_7_Initial;
  Adacrus__orientation oriented_St_7_Initial;
  Adacrus__coordinates next_node_St_7_Initial;
  Adacrus__direction dir_St_7_Initial;
  int v_r_St_7_Initial;
  int v_l_St_7_Initial;
  Adacrus__st_7 ns_6;
  int r_6;
  int nr_6;
  Adacrus__coordinates next_node;
  Adacrus__orientation oriented;
  Adacrus__states current_state;
  Adacrus__states debug_state;
  r_6 = self->pnr_6;
  switch (self->ck) {
    case Adacrus__St_7_Initial:
      oriented_St_7_Initial = self->oriented_4;
      current_state_St_7_Initial = Adacrus__Initial;
      dir_St_7_Initial = Adacrus__Forward;
      Adacrus__notIsNode_step(left_wl, center_wl, right_wl,
                              &Adacrus__notIsNode_out_st);
      v_613 = Adacrus__notIsNode_out_st.out;
      if (v_613) {
        nr_6_St_7_Initial = true;
        ns_6_St_7_Initial = Adacrus__St_7_Moving;
      } else {
        nr_6_St_7_Initial = false;
        ns_6_St_7_Initial = Adacrus__St_7_Initial;
      };
      r_25 = r_6;
      if (r_25) {
        Adacrus__move_reset(&self->move_4);
      };
      Adacrus__move_step(left_wl, center_wl, right_wl, false, false, false,
                         false, &Adacrus__move_out_st, &self->move_4);
      v_l_St_7_Initial = Adacrus__move_out_st.v_l;
      v_r_St_7_Initial = Adacrus__move_out_st.v_r;
      current_state = current_state_St_7_Initial;
      debug_state_St_7_Initial = current_state;
      oriented = oriented_St_7_Initial;
      _out->dir = dir_St_7_Initial;
      debug_state = debug_state_St_7_Initial;
      break;
    case Adacrus__St_7_Moving:
      oriented_St_7_Moving = self->oriented_4;
      current_state_St_7_Moving = Adacrus__Moving;
      dir_St_7_Moving = Adacrus__Forward;
      v_582 = (self->v_581+1);
      if (self->v_579) {
        v_580 = true;
      } else {
        v_580 = r_6;
      };
      if (v_580) {
        inverted_t = 0;
      } else {
        inverted_t = v_582;
      };
      v_583 = (inverted_t<300);
      r_20 = r_6;
      if (r_20) {
        Adacrus__isNode_reset(&self->isNode);
      };
      Adacrus__isNode_step(left_wl, center_wl, right_wl, 15,
                           &Adacrus__isNode_out_st, &self->isNode);
      v_585 = Adacrus__isNode_out_st.out;
      r_21 = r_6;
      if (r_21) {
        Adacrus__move_reset(&self->move);
      };
      Adacrus__move_step(left_wl, center_wl, right_wl, true, false, false,
                         false, &Adacrus__move_out_st, &self->move);
      v_593 = Adacrus__move_out_st.v_l;
      v_594 = Adacrus__move_out_st.v_r;
      r_22 = r_6;
      if (r_22) {
        Adacrus__move_reset(&self->move_1);
      };
      Adacrus__move_step(left_wl, center_wl, right_wl, false, false, true,
                         false, &Adacrus__move_out_st, &self->move_1);
      v_598 = Adacrus__move_out_st.v_l;
      v_599 = Adacrus__move_out_st.v_r;
      r_23 = r_6;
      if (r_23) {
        Adacrus__move_reset(&self->move_2);
      };
      Adacrus__move_step(left_wl, center_wl, right_wl, false, false, false,
                         true, &Adacrus__move_out_st, &self->move_2);
      v_603 = Adacrus__move_out_st.v_l;
      v_604 = Adacrus__move_out_st.v_r;
      r_24 = r_6;
      if (r_24) {
        Adacrus__move_reset(&self->move_3);
      };
      Adacrus__move_step(left_wl, center_wl, right_wl, false, false, false,
                         false, &Adacrus__move_out_st, &self->move_3);
      v_605 = Adacrus__move_out_st.v_l;
      v_606 = Adacrus__move_out_st.v_r;
      current_state = current_state_St_7_Moving;
      debug_state_St_7_Moving = current_state;
      oriented = oriented_St_7_Moving;
      v_600 = (oriented==Adacrus__B);
      v_595 = (oriented==Adacrus__T);
      v_589 = (oriented==Adacrus__B);
      v_586 = (oriented==Adacrus__T);
      v_576 = (oriented==Adacrus__B);
      v_573 = (oriented==Adacrus__T);
      _out->dir = dir_St_7_Moving;
      debug_state = debug_state_St_7_Moving;
      break;
    case Adacrus__St_7_Exit:
      oriented_St_7_Exit = self->oriented_4;
      current_state_St_7_Exit = Adacrus__Exit;
      Adacrus__halt_step(&Adacrus__halt_out_st);
      v_l_St_7_Exit = Adacrus__halt_out_st.v_l;
      v_r_St_7_Exit = Adacrus__halt_out_st.v_r;
      dir_St_7_Exit = Adacrus__halt_out_st.dir;
      if (false) {
        nr_6_St_7_Exit = true;
      } else {
        nr_6_St_7_Exit = false;
      };
      if (false) {
        ns_6_St_7_Exit = Adacrus__St_7_Exit;
      } else {
        ns_6_St_7_Exit = Adacrus__St_7_Exit;
      };
      current_state = current_state_St_7_Exit;
      debug_state_St_7_Exit = current_state;
      oriented = oriented_St_7_Exit;
      _out->dir = dir_St_7_Exit;
      debug_state = debug_state_St_7_Exit;
      break;
    case Adacrus__St_7_DecideAction:
      if (r_6) {
        out_of_node_1 = false;
      } else {
        out_of_node_1 = self->v_572;
      };
      current_state_St_7_DecideAction = self->current_state_2;
      if (r_6) {
        pnr_2 = false;
      } else {
        pnr_2 = self->v_571;
      };
      r_2 = pnr_2;
      if (r_6) {
        ck_2 = Adacrus__St_3_Decidado;
      } else {
        ck_2 = self->v_570;
      };
      current_state = current_state_St_7_DecideAction;
      switch (ck_2) {
        case Adacrus__St_3_Decidado:
          out_of_node_St_3_Decidado = false;
          debug_state_St_7_DecideAction_St_3_Decidado = Adacrus__Decidado;
          Adacrus__calcOrientation_step(self->current_state_2,
                                        self->oriented_4,
                                        &Adacrus__calcOrientation_out_st);
          oriented_St_7_DecideAction_St_3_Decidado = Adacrus__calcOrientation_out_st.new_orientation;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_7_DecideAction_St_3_Decidado = Adacrus__halt_out_st.v_l;
          v_r_St_7_DecideAction_St_3_Decidado = Adacrus__halt_out_st.v_r;
          dir_St_7_DecideAction_St_3_Decidado = Adacrus__halt_out_st.dir;
          if (true) {
            nr_2_St_3_Decidado = true;
          } else {
            nr_2_St_3_Decidado = false;
          };
          if (true) {
            ns_2_St_3_Decidado = Adacrus__St_3_LeaveNode;
          } else {
            ns_2_St_3_Decidado = Adacrus__St_3_Decidado;
          };
          r_19 = (r_6||r_2);
          oriented_St_7_DecideAction = oriented_St_7_DecideAction_St_3_Decidado;
          debug_state_St_7_DecideAction = debug_state_St_7_DecideAction_St_3_Decidado;
          out_of_node = out_of_node_St_3_Decidado;
          ns_2 = ns_2_St_3_Decidado;
          nr_2 = nr_2_St_3_Decidado;
          v_l_St_7_DecideAction = v_l_St_7_DecideAction_St_3_Decidado;
          v_r_St_7_DecideAction = v_r_St_7_DecideAction_St_3_Decidado;
          dir_St_7_DecideAction = dir_St_7_DecideAction_St_3_Decidado;
          break;
        case Adacrus__St_3_LeaveNode:
          next_state_St_3_LeaveNode = self->next_state_4;
          oriented_St_7_DecideAction_St_3_LeaveNode = self->oriented_4;
          out_of_node_St_3_LeaveNode = false;
          debug_state_St_7_DecideAction_St_3_LeaveNode = Adacrus__LeaveNode;
          dir_St_7_DecideAction_St_3_LeaveNode = Adacrus__Forward;
          v_r_St_7_DecideAction_St_3_LeaveNode = 100;
          v_l_St_7_DecideAction_St_3_LeaveNode = 100;
          Adacrus__notIsNode_step(left_wl, center_wl, right_wl,
                                  &Adacrus__notIsNode_out_st);
          v_569 = Adacrus__notIsNode_out_st.out;
          if (v_569) {
            nr_2_St_3_LeaveNode = true;
            ns_2_St_3_LeaveNode = Adacrus__St_3_CenterAlign;
          } else {
            nr_2_St_3_LeaveNode = false;
            ns_2_St_3_LeaveNode = Adacrus__St_3_LeaveNode;
          };
          oriented_St_7_DecideAction = oriented_St_7_DecideAction_St_3_LeaveNode;
          debug_state_St_7_DecideAction = debug_state_St_7_DecideAction_St_3_LeaveNode;
          out_of_node = out_of_node_St_3_LeaveNode;
          ns_2 = ns_2_St_3_LeaveNode;
          nr_2 = nr_2_St_3_LeaveNode;
          v_l_St_7_DecideAction = v_l_St_7_DecideAction_St_3_LeaveNode;
          v_r_St_7_DecideAction = v_r_St_7_DecideAction_St_3_LeaveNode;
          dir_St_7_DecideAction = dir_St_7_DecideAction_St_3_LeaveNode;
          break;
        case Adacrus__St_3_CenterAlign:
          next_state_St_3_CenterAlign = self->next_state_4;
          oriented_St_7_DecideAction_St_3_CenterAlign = self->oriented_4;
          v_567 = (r_6||r_2);
          if (v_567) {
            pnr = false;
          } else {
            pnr = self->v_568;
          };
          r = pnr;
          v_565 = (r_6||r_2);
          if (v_565) {
            ck_3 = Adacrus__St_2_TryLeft;
          } else {
            ck_3 = self->v_566;
          };
          debug_state_St_7_DecideAction_St_3_CenterAlign = Adacrus__CenterAlign;
          r_18 = (r_6||r_2);
          if (r_18) {
            Adacrus__isLine_reset(&self->isLine_5);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                               &Adacrus__isLine_out_st, &self->isLine_5);
          out_of_node_St_3_CenterAlign = Adacrus__isLine_out_st.out;
          oriented_St_7_DecideAction = oriented_St_7_DecideAction_St_3_CenterAlign;
          debug_state_St_7_DecideAction = debug_state_St_7_DecideAction_St_3_CenterAlign;
          out_of_node = out_of_node_St_3_CenterAlign;
          if (out_of_node) {
            nr_2_St_3_CenterAlign = false;
            ns_2_St_3_CenterAlign = Adacrus__St_3_Decidado;
          } else {
            nr_2_St_3_CenterAlign = false;
            ns_2_St_3_CenterAlign = Adacrus__St_3_CenterAlign;
          };
          ns_2 = ns_2_St_3_CenterAlign;
          nr_2 = nr_2_St_3_CenterAlign;
          switch (ck_3) {
            case Adacrus__St_2_TryLeft:
              dir_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft = Adacrus__Left;
              v_r_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft = 100;
              v_l_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft = -100;
              v_564 = (self->v_563+1);
              v_560 = (r_6||r_2);
              v_561 = (v_560||r);
              if (self->v_559) {
                v_562 = true;
              } else {
                v_562 = v_561;
              };
              if (v_562) {
                t_left = 0;
              } else {
                t_left = v_564;
              };
              v_558 = (t_left>30);
              if (v_558) {
                nr_St_2_TryLeft = true;
                ns_St_2_TryLeft = Adacrus__St_2_TryRight;
              } else {
                nr_St_2_TryLeft = false;
                ns_St_2_TryLeft = Adacrus__St_2_TryLeft;
              };
              v_l_St_7_DecideAction_St_3_CenterAlign = v_l_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft;
              v_r_St_7_DecideAction_St_3_CenterAlign = v_r_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft;
              dir_St_7_DecideAction_St_3_CenterAlign = dir_St_7_DecideAction_St_3_CenterAlign_St_2_TryLeft;
              ns = ns_St_2_TryLeft;
              nr = nr_St_2_TryLeft;
              break;
            case Adacrus__St_2_TryRight:
              dir_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight = Adacrus__Right;
              v_r_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight = -100;
              v_l_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight = 100;
              v_557 = (self->v_556+1);
              v_553 = (r_6||r_2);
              v_554 = (v_553||r);
              if (self->v_552) {
                v_555 = true;
              } else {
                v_555 = v_554;
              };
              if (v_555) {
                t_right = 0;
              } else {
                t_right = v_557;
              };
              v_551 = (t_right>60);
              if (v_551) {
                nr_St_2_TryRight = true;
                ns_St_2_TryRight = Adacrus__St_2_TryLeft;
              } else {
                nr_St_2_TryRight = false;
                ns_St_2_TryRight = Adacrus__St_2_TryRight;
              };
              v_l_St_7_DecideAction_St_3_CenterAlign = v_l_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight;
              v_r_St_7_DecideAction_St_3_CenterAlign = v_r_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight;
              dir_St_7_DecideAction_St_3_CenterAlign = dir_St_7_DecideAction_St_3_CenterAlign_St_2_TryRight;
              ns = ns_St_2_TryRight;
              nr = nr_St_2_TryRight;
              break;
            default:
              break;
          };
          v_l_St_7_DecideAction = v_l_St_7_DecideAction_St_3_CenterAlign;
          v_r_St_7_DecideAction = v_r_St_7_DecideAction_St_3_CenterAlign;
          dir_St_7_DecideAction = dir_St_7_DecideAction_St_3_CenterAlign;
          break;
        default:
          break;
      };
      oriented = oriented_St_7_DecideAction;
      _out->dir = dir_St_7_DecideAction;
      debug_state = debug_state_St_7_DecideAction;
      break;
    case Adacrus__St_7_RotL:
      if (r_6) {
        exit_1_1 = false;
      } else {
        exit_1_1 = self->v_532;
      };
      oriented_St_7_RotL = self->oriented_4;
      if (r_6) {
        pnr_3 = false;
      } else {
        pnr_3 = self->v_531;
      };
      r_3 = pnr_3;
      if (r_6) {
        ck_4 = Adacrus__St_4_GoAhead;
      } else {
        ck_4 = self->v_530;
      };
      current_state_St_7_RotL = Adacrus__RotL;
      current_state = current_state_St_7_RotL;
      switch (ck_4) {
        case Adacrus__St_4_GoAhead:
          exit_1_St_4_GoAhead = exit_1_1;
          debug_state_St_7_RotL_St_4_GoAhead = Adacrus__GoAhead;
          v_529 = (self->v_528+1);
          v_526 = (r_6||r_3);
          if (self->v_525) {
            v_527 = true;
          } else {
            v_527 = v_526;
          };
          if (v_527) {
            t_forward = 0;
          } else {
            t_forward = v_529;
          };
          dir_St_7_RotL_St_4_GoAhead = Adacrus__Forward;
          v_r_St_7_RotL_St_4_GoAhead = 200;
          v_l_St_7_RotL_St_4_GoAhead = 200;
          v_524 = (t_forward>35);
          if (v_524) {
            nr_3_St_4_GoAhead = true;
            ns_3_St_4_GoAhead = Adacrus__St_4_TurnLeft;
          } else {
            nr_3_St_4_GoAhead = false;
            ns_3_St_4_GoAhead = Adacrus__St_4_GoAhead;
          };
          v_l_St_7_RotL = v_l_St_7_RotL_St_4_GoAhead;
          v_r_St_7_RotL = v_r_St_7_RotL_St_4_GoAhead;
          dir_St_7_RotL = dir_St_7_RotL_St_4_GoAhead;
          debug_state_St_7_RotL = debug_state_St_7_RotL_St_4_GoAhead;
          exit_1 = exit_1_St_4_GoAhead;
          ns_3 = ns_3_St_4_GoAhead;
          nr_3 = nr_3_St_4_GoAhead;
          break;
        case Adacrus__St_4_BlackToWhite:
          exit_1_St_4_BlackToWhite = exit_1_1;
          debug_state_St_7_RotL_St_4_BlackToWhite = Adacrus__BlackToWhite;
          v_523 = (self->v_522+1);
          v_520 = (r_6||r_3);
          if (self->v_519) {
            v_521 = true;
          } else {
            v_521 = v_520;
          };
          if (v_521) {
            t_left_1 = 0;
          } else {
            t_left_1 = v_523;
          };
          dir_St_7_RotL_St_4_BlackToWhite = Adacrus__Left;
          v_r_St_7_RotL_St_4_BlackToWhite = 100;
          v_l_St_7_RotL_St_4_BlackToWhite = -100;
          r_17 = (r_6||r_3);
          if (r_17) {
            Adacrus__isAllWhite_reset(&self->isAllWhite_2);
          };
          Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 40,
                                   &Adacrus__isAllWhite_out_st,
                                   &self->isAllWhite_2);
          v_518 = Adacrus__isAllWhite_out_st.out;
          if (v_518) {
            nr_3_St_4_BlackToWhite = true;
            ns_3_St_4_BlackToWhite = Adacrus__St_4_TurnLeft;
          } else {
            nr_3_St_4_BlackToWhite = false;
            ns_3_St_4_BlackToWhite = Adacrus__St_4_BlackToWhite;
          };
          v_l_St_7_RotL = v_l_St_7_RotL_St_4_BlackToWhite;
          v_r_St_7_RotL = v_r_St_7_RotL_St_4_BlackToWhite;
          dir_St_7_RotL = dir_St_7_RotL_St_4_BlackToWhite;
          debug_state_St_7_RotL = debug_state_St_7_RotL_St_4_BlackToWhite;
          exit_1 = exit_1_St_4_BlackToWhite;
          ns_3 = ns_3_St_4_BlackToWhite;
          nr_3 = nr_3_St_4_BlackToWhite;
          break;
        case Adacrus__St_4_TurnLeft:
          exit_1_St_4_TurnLeft = exit_1_1;
          debug_state_St_7_RotL_St_4_TurnLeft = Adacrus__TurnLeft;
          v_517 = (self->v_516+1);
          v_514 = (r_6||r_3);
          if (self->v_513) {
            v_515 = true;
          } else {
            v_515 = v_514;
          };
          if (v_515) {
            t_left_2 = 0;
          } else {
            t_left_2 = v_517;
          };
          dir_St_7_RotL_St_4_TurnLeft = Adacrus__Left;
          v_r_St_7_RotL_St_4_TurnLeft = 100;
          v_l_St_7_RotL_St_4_TurnLeft = -100;
          v_510 = (t_left_2>35);
          r_16 = (r_6||r_3);
          if (r_16) {
            Adacrus__isLine_reset(&self->isLine_4);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                               &Adacrus__isLine_out_st, &self->isLine_4);
          v_511 = Adacrus__isLine_out_st.out;
          v_512 = (v_510&&v_511);
          if (v_512) {
            nr_3_St_4_TurnLeft = true;
            ns_3_St_4_TurnLeft = Adacrus__St_4_Exit;
          } else {
            nr_3_St_4_TurnLeft = false;
            ns_3_St_4_TurnLeft = Adacrus__St_4_TurnLeft;
          };
          v_l_St_7_RotL = v_l_St_7_RotL_St_4_TurnLeft;
          v_r_St_7_RotL = v_r_St_7_RotL_St_4_TurnLeft;
          dir_St_7_RotL = dir_St_7_RotL_St_4_TurnLeft;
          debug_state_St_7_RotL = debug_state_St_7_RotL_St_4_TurnLeft;
          exit_1 = exit_1_St_4_TurnLeft;
          ns_3 = ns_3_St_4_TurnLeft;
          nr_3 = nr_3_St_4_TurnLeft;
          break;
        case Adacrus__St_4_Exit:
          debug_state_St_7_RotL_St_4_Exit = Adacrus__Exit;
          exit_1_St_4_Exit = true;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_7_RotL_St_4_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_7_RotL_St_4_Exit = Adacrus__halt_out_st.v_r;
          dir_St_7_RotL_St_4_Exit = Adacrus__halt_out_st.dir;
          nr_3_St_4_Exit = false;
          ns_3_St_4_Exit = Adacrus__St_4_Exit;
          v_l_St_7_RotL = v_l_St_7_RotL_St_4_Exit;
          v_r_St_7_RotL = v_r_St_7_RotL_St_4_Exit;
          dir_St_7_RotL = dir_St_7_RotL_St_4_Exit;
          debug_state_St_7_RotL = debug_state_St_7_RotL_St_4_Exit;
          exit_1 = exit_1_St_4_Exit;
          ns_3 = ns_3_St_4_Exit;
          nr_3 = nr_3_St_4_Exit;
          break;
        default:
          break;
      };
      if (exit_1) {
        nr_6_St_7_RotL = false;
        ns_6_St_7_RotL = Adacrus__St_7_DecideAction;
      } else {
        nr_6_St_7_RotL = false;
        ns_6_St_7_RotL = Adacrus__St_7_RotL;
      };
      oriented = oriented_St_7_RotL;
      _out->dir = dir_St_7_RotL;
      debug_state = debug_state_St_7_RotL;
      break;
    case Adacrus__St_7_RotR:
      if (r_6) {
        exit_2_1 = false;
      } else {
        exit_2_1 = self->v_509;
      };
      oriented_St_7_RotR = self->oriented_4;
      if (r_6) {
        pnr_4 = false;
      } else {
        pnr_4 = self->v_508;
      };
      r_4 = pnr_4;
      if (r_6) {
        ck_5 = Adacrus__St_5_GoAhead;
      } else {
        ck_5 = self->v_507;
      };
      current_state_St_7_RotR = Adacrus__RotR;
      current_state = current_state_St_7_RotR;
      oriented = oriented_St_7_RotR;
      switch (ck_5) {
        case Adacrus__St_5_GoAhead:
          exit_2_St_5_GoAhead = exit_2_1;
          debug_state_St_7_RotR_St_5_GoAhead = Adacrus__GoAhead;
          v_506 = (self->v_505+1);
          v_503 = (r_6||r_4);
          if (self->v_502) {
            v_504 = true;
          } else {
            v_504 = v_503;
          };
          if (v_504) {
            t_forward_1 = 0;
          } else {
            t_forward_1 = v_506;
          };
          dir_St_7_RotR_St_5_GoAhead = Adacrus__Forward;
          v_r_St_7_RotR_St_5_GoAhead = 200;
          v_l_St_7_RotR_St_5_GoAhead = 200;
          v_501 = (t_forward_1>35);
          if (v_501) {
            nr_4_St_5_GoAhead = true;
            ns_4_St_5_GoAhead = Adacrus__St_5_BlackToWhite;
          } else {
            nr_4_St_5_GoAhead = false;
            ns_4_St_5_GoAhead = Adacrus__St_5_GoAhead;
          };
          v_l_St_7_RotR = v_l_St_7_RotR_St_5_GoAhead;
          v_r_St_7_RotR = v_r_St_7_RotR_St_5_GoAhead;
          dir_St_7_RotR = dir_St_7_RotR_St_5_GoAhead;
          debug_state_St_7_RotR = debug_state_St_7_RotR_St_5_GoAhead;
          exit_2 = exit_2_St_5_GoAhead;
          ns_4 = ns_4_St_5_GoAhead;
          nr_4 = nr_4_St_5_GoAhead;
          break;
        case Adacrus__St_5_BlackToWhite:
          exit_2_St_5_BlackToWhite = exit_2_1;
          debug_state_St_7_RotR_St_5_BlackToWhite = Adacrus__BlackToWhite;
          v_500 = (self->v_499+1);
          v_497 = (r_6||r_4);
          if (self->v_496) {
            v_498 = true;
          } else {
            v_498 = v_497;
          };
          if (v_498) {
            t_right_1 = 0;
          } else {
            t_right_1 = v_500;
          };
          dir_St_7_RotR_St_5_BlackToWhite = Adacrus__Right;
          v_r_St_7_RotR_St_5_BlackToWhite = -100;
          v_l_St_7_RotR_St_5_BlackToWhite = 100;
          r_15 = (r_6||r_4);
          if (r_15) {
            Adacrus__isAllWhite_reset(&self->isAllWhite);
          };
          Adacrus__isAllWhite_step(left_wl, center_wl, right_wl, 40,
                                   &Adacrus__isAllWhite_out_st,
                                   &self->isAllWhite);
          v_495 = Adacrus__isAllWhite_out_st.out;
          if (v_495) {
            nr_4_St_5_BlackToWhite = true;
            ns_4_St_5_BlackToWhite = Adacrus__St_5_TurnRight;
          } else {
            nr_4_St_5_BlackToWhite = false;
            ns_4_St_5_BlackToWhite = Adacrus__St_5_BlackToWhite;
          };
          v_l_St_7_RotR = v_l_St_7_RotR_St_5_BlackToWhite;
          v_r_St_7_RotR = v_r_St_7_RotR_St_5_BlackToWhite;
          dir_St_7_RotR = dir_St_7_RotR_St_5_BlackToWhite;
          debug_state_St_7_RotR = debug_state_St_7_RotR_St_5_BlackToWhite;
          exit_2 = exit_2_St_5_BlackToWhite;
          ns_4 = ns_4_St_5_BlackToWhite;
          nr_4 = nr_4_St_5_BlackToWhite;
          break;
        case Adacrus__St_5_TurnRight:
          exit_2_St_5_TurnRight = exit_2_1;
          debug_state_St_7_RotR_St_5_TurnRight = Adacrus__TurnRight;
          v_494 = (self->v_493+1);
          v_491 = (r_6||r_4);
          if (self->v_490) {
            v_492 = true;
          } else {
            v_492 = v_491;
          };
          if (v_492) {
            t_right_2 = 0;
          } else {
            t_right_2 = v_494;
          };
          dir_St_7_RotR_St_5_TurnRight = Adacrus__Right;
          v_r_St_7_RotR_St_5_TurnRight = -100;
          v_l_St_7_RotR_St_5_TurnRight = 100;
          v_487 = (t_right_2>35);
          r_14 = (r_6||r_4);
          if (r_14) {
            Adacrus__isLine_reset(&self->isLine_3);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 3,
                               &Adacrus__isLine_out_st, &self->isLine_3);
          v_488 = Adacrus__isLine_out_st.out;
          v_489 = (v_487&&v_488);
          if (v_489) {
            nr_4_St_5_TurnRight = true;
            ns_4_St_5_TurnRight = Adacrus__St_5_Exit;
          } else {
            nr_4_St_5_TurnRight = false;
            ns_4_St_5_TurnRight = Adacrus__St_5_TurnRight;
          };
          v_l_St_7_RotR = v_l_St_7_RotR_St_5_TurnRight;
          v_r_St_7_RotR = v_r_St_7_RotR_St_5_TurnRight;
          dir_St_7_RotR = dir_St_7_RotR_St_5_TurnRight;
          debug_state_St_7_RotR = debug_state_St_7_RotR_St_5_TurnRight;
          exit_2 = exit_2_St_5_TurnRight;
          ns_4 = ns_4_St_5_TurnRight;
          nr_4 = nr_4_St_5_TurnRight;
          break;
        case Adacrus__St_5_Exit:
          debug_state_St_7_RotR_St_5_Exit = Adacrus__Exit;
          exit_2_St_5_Exit = true;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_7_RotR_St_5_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_7_RotR_St_5_Exit = Adacrus__halt_out_st.v_r;
          dir_St_7_RotR_St_5_Exit = Adacrus__halt_out_st.dir;
          nr_4_St_5_Exit = false;
          ns_4_St_5_Exit = Adacrus__St_5_Exit;
          v_l_St_7_RotR = v_l_St_7_RotR_St_5_Exit;
          v_r_St_7_RotR = v_r_St_7_RotR_St_5_Exit;
          dir_St_7_RotR = dir_St_7_RotR_St_5_Exit;
          debug_state_St_7_RotR = debug_state_St_7_RotR_St_5_Exit;
          exit_2 = exit_2_St_5_Exit;
          ns_4 = ns_4_St_5_Exit;
          nr_4 = nr_4_St_5_Exit;
          break;
        default:
          break;
      };
      if (exit_2) {
        nr_6_St_7_RotR = false;
        ns_6_St_7_RotR = Adacrus__St_7_DecideAction;
      } else {
        nr_6_St_7_RotR = false;
        ns_6_St_7_RotR = Adacrus__St_7_RotR;
      };
      _out->dir = dir_St_7_RotR;
      debug_state = debug_state_St_7_RotR;
      break;
    case Adacrus__St_7_Rot180:
      if (r_6) {
        exit_3_1 = false;
      } else {
        exit_3_1 = self->v_486;
      };
      oriented_St_7_Rot180 = self->oriented_4;
      if (r_6) {
        pnr_5 = false;
      } else {
        pnr_5 = self->v_485;
      };
      r_5 = pnr_5;
      if (r_6) {
        ck_6 = Adacrus__St_6_GoAhead;
      } else {
        ck_6 = self->v_484;
      };
      current_state_St_7_Rot180 = Adacrus__Rot180;
      current_state = current_state_St_7_Rot180;
      oriented = oriented_St_7_Rot180;
      switch (ck_6) {
        case Adacrus__St_6_GoAhead:
          exit_3_St_6_GoAhead = exit_3_1;
          debug_state_St_7_Rot180_St_6_GoAhead = Adacrus__GoAhead;
          v_483 = (self->v_482+1);
          v_480 = (r_6||r_5);
          if (self->v_479) {
            v_481 = true;
          } else {
            v_481 = v_480;
          };
          if (v_481) {
            t_forward_2 = 0;
          } else {
            t_forward_2 = v_483;
          };
          dir_St_7_Rot180_St_6_GoAhead = Adacrus__Forward;
          v_r_St_7_Rot180_St_6_GoAhead = 200;
          v_l_St_7_Rot180_St_6_GoAhead = 200;
          v_478 = (t_forward_2>35);
          if (v_478) {
            nr_5_St_6_GoAhead = true;
            ns_5_St_6_GoAhead = Adacrus__St_6_TurnRight;
          } else {
            nr_5_St_6_GoAhead = false;
            ns_5_St_6_GoAhead = Adacrus__St_6_GoAhead;
          };
          v_l_St_7_Rot180 = v_l_St_7_Rot180_St_6_GoAhead;
          v_r_St_7_Rot180 = v_r_St_7_Rot180_St_6_GoAhead;
          dir_St_7_Rot180 = dir_St_7_Rot180_St_6_GoAhead;
          debug_state_St_7_Rot180 = debug_state_St_7_Rot180_St_6_GoAhead;
          exit_3 = exit_3_St_6_GoAhead;
          ns_5 = ns_5_St_6_GoAhead;
          nr_5 = nr_5_St_6_GoAhead;
          break;
        case Adacrus__St_6_TurnRight:
          exit_3_St_6_TurnRight = exit_3_1;
          debug_state_St_7_Rot180_St_6_TurnRight = Adacrus__TurnRight;
          v_477 = (self->v_476+1);
          v_474 = (r_6||r_5);
          if (self->v_473) {
            v_475 = true;
          } else {
            v_475 = v_474;
          };
          if (v_475) {
            t_right_3 = 0;
          } else {
            t_right_3 = v_477;
          };
          dir_St_7_Rot180_St_6_TurnRight = Adacrus__Right;
          v_r_St_7_Rot180_St_6_TurnRight = -100;
          v_l_St_7_Rot180_St_6_TurnRight = 100;
          v_470 = (t_right_3>35);
          r_13 = (r_6||r_5);
          if (r_13) {
            Adacrus__isLine_reset(&self->isLine_2);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 5,
                               &Adacrus__isLine_out_st, &self->isLine_2);
          v_471 = Adacrus__isLine_out_st.out;
          v_472 = (v_470&&v_471);
          if (v_472) {
            nr_5_St_6_TurnRight = true;
            ns_5_St_6_TurnRight = Adacrus__St_6_TurnRightAgain;
          } else {
            nr_5_St_6_TurnRight = false;
            ns_5_St_6_TurnRight = Adacrus__St_6_TurnRight;
          };
          v_l_St_7_Rot180 = v_l_St_7_Rot180_St_6_TurnRight;
          v_r_St_7_Rot180 = v_r_St_7_Rot180_St_6_TurnRight;
          dir_St_7_Rot180 = dir_St_7_Rot180_St_6_TurnRight;
          debug_state_St_7_Rot180 = debug_state_St_7_Rot180_St_6_TurnRight;
          exit_3 = exit_3_St_6_TurnRight;
          ns_5 = ns_5_St_6_TurnRight;
          nr_5 = nr_5_St_6_TurnRight;
          break;
        case Adacrus__St_6_TurnRightAgain:
          exit_3_St_6_TurnRightAgain = exit_3_1;
          debug_state_St_7_Rot180_St_6_TurnRightAgain = Adacrus__TurnRight;
          v_469 = (self->v_468+1);
          v_466 = (r_6||r_5);
          if (self->v_465) {
            v_467 = true;
          } else {
            v_467 = v_466;
          };
          if (v_467) {
            t_right_again = 0;
          } else {
            t_right_again = v_469;
          };
          dir_St_7_Rot180_St_6_TurnRightAgain = Adacrus__Right;
          v_r_St_7_Rot180_St_6_TurnRightAgain = -100;
          v_l_St_7_Rot180_St_6_TurnRightAgain = 100;
          v = (t_right_again>35);
          r_12 = (r_6||r_5);
          if (r_12) {
            Adacrus__isLine_reset(&self->isLine);
          };
          Adacrus__isLine_step(left_wl, center_wl, right_wl, 5,
                               &Adacrus__isLine_out_st, &self->isLine);
          v_463 = Adacrus__isLine_out_st.out;
          v_464 = (v&&v_463);
          if (v_464) {
            nr_5_St_6_TurnRightAgain = true;
            ns_5_St_6_TurnRightAgain = Adacrus__St_6_Exit;
          } else {
            nr_5_St_6_TurnRightAgain = false;
            ns_5_St_6_TurnRightAgain = Adacrus__St_6_TurnRightAgain;
          };
          v_l_St_7_Rot180 = v_l_St_7_Rot180_St_6_TurnRightAgain;
          v_r_St_7_Rot180 = v_r_St_7_Rot180_St_6_TurnRightAgain;
          dir_St_7_Rot180 = dir_St_7_Rot180_St_6_TurnRightAgain;
          debug_state_St_7_Rot180 = debug_state_St_7_Rot180_St_6_TurnRightAgain;
          exit_3 = exit_3_St_6_TurnRightAgain;
          ns_5 = ns_5_St_6_TurnRightAgain;
          nr_5 = nr_5_St_6_TurnRightAgain;
          break;
        case Adacrus__St_6_Exit:
          exit_3_St_6_Exit = true;
          debug_state_St_7_Rot180_St_6_Exit = Adacrus__Exit;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_7_Rot180_St_6_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_7_Rot180_St_6_Exit = Adacrus__halt_out_st.v_r;
          dir_St_7_Rot180_St_6_Exit = Adacrus__halt_out_st.dir;
          nr_5_St_6_Exit = false;
          ns_5_St_6_Exit = Adacrus__St_6_Exit;
          v_l_St_7_Rot180 = v_l_St_7_Rot180_St_6_Exit;
          v_r_St_7_Rot180 = v_r_St_7_Rot180_St_6_Exit;
          dir_St_7_Rot180 = dir_St_7_Rot180_St_6_Exit;
          debug_state_St_7_Rot180 = debug_state_St_7_Rot180_St_6_Exit;
          exit_3 = exit_3_St_6_Exit;
          ns_5 = ns_5_St_6_Exit;
          nr_5 = nr_5_St_6_Exit;
          break;
        default:
          break;
      };
      if (exit_3) {
        nr_6_St_7_Rot180 = false;
        ns_6_St_7_Rot180 = Adacrus__St_7_DecideAction;
      } else {
        nr_6_St_7_Rot180 = false;
        ns_6_St_7_Rot180 = Adacrus__St_7_Rot180;
      };
      _out->dir = dir_St_7_Rot180;
      debug_state = debug_state_St_7_Rot180;
      break;
    default:
      break;
  };
  _out->o = oriented;
  _out->d_s = debug_state;
  _out->s = current_state;
  switch (self->ck) {
    case Adacrus__St_7_Initial:
      next_node_St_7_Initial = self->next_node_5;
      next_node = next_node_St_7_Initial;
      _out->v_l = v_l_St_7_Initial;
      _out->v_r = v_r_St_7_Initial;
      ns_6 = ns_6_St_7_Initial;
      nr_6 = nr_6_St_7_Initial;
      break;
    case Adacrus__St_7_Moving:
      next_node_St_7_Moving = self->next_node_5;
      next_node = next_node_St_7_Moving;
      v_601 = (next_node.y==3);
      v_602 = (v_600&&v_601);
      if (v_602) {
        v_608 = v_604;
        v_607 = v_603;
      } else {
        v_608 = v_606;
        v_607 = v_605;
      };
      v_596 = (next_node.y==4);
      v_597 = (v_595&&v_596);
      if (v_597) {
        v_610 = v_599;
        v_609 = v_598;
      } else {
        v_610 = v_608;
        v_609 = v_607;
      };
      v_590 = (next_node.y==1);
      v_591 = (v_589&&v_590);
      v_587 = (next_node.y==2);
      v_588 = (v_586&&v_587);
      v_592 = (v_588||v_591);
      v_577 = (next_node.y==5);
      v_578 = (v_576&&v_577);
      v_574 = (next_node.y==6);
      v_575 = (v_573&&v_574);
      inverted_section = (v_575||v_578);
      if (inverted_section) {
        v_612 = 200;
      } else {
        v_612 = v_610;
      };
      if (v_592) {
        v_r_St_7_Moving = v_594;
      } else {
        v_r_St_7_Moving = v_612;
      };
      if (inverted_section) {
        v_611 = 200;
      } else {
        v_611 = v_609;
      };
      if (v_592) {
        v_l_St_7_Moving = v_593;
      } else {
        v_l_St_7_Moving = v_611;
      };
      v_584 = (inverted_section&&v_583);
      if (v_584) {
        exit = false;
      } else {
        exit = v_585;
      };
      if (exit) {
        nr_6_St_7_Moving = false;
        ns_6_St_7_Moving = Adacrus__St_7_DecideAction;
      } else {
        nr_6_St_7_Moving = false;
        ns_6_St_7_Moving = Adacrus__St_7_Moving;
      };
      _out->v_l = v_l_St_7_Moving;
      _out->v_r = v_r_St_7_Moving;
      ns_6 = ns_6_St_7_Moving;
      nr_6 = nr_6_St_7_Moving;
      break;
    case Adacrus__St_7_Exit:
      next_node_St_7_Exit = self->next_node_5;
      next_node = next_node_St_7_Exit;
      _out->v_l = v_l_St_7_Exit;
      _out->v_r = v_r_St_7_Exit;
      ns_6 = ns_6_St_7_Exit;
      nr_6 = nr_6_St_7_Exit;
      break;
    case Adacrus__St_7_RotL:
      next_node_St_7_RotL = self->next_node_5;
      next_node = next_node_St_7_RotL;
      _out->v_l = v_l_St_7_RotL;
      _out->v_r = v_r_St_7_RotL;
      ns_6 = ns_6_St_7_RotL;
      nr_6 = nr_6_St_7_RotL;
      break;
    case Adacrus__St_7_RotR:
      next_node_St_7_RotR = self->next_node_5;
      next_node = next_node_St_7_RotR;
      _out->v_l = v_l_St_7_RotR;
      _out->v_r = v_r_St_7_RotR;
      ns_6 = ns_6_St_7_RotR;
      nr_6 = nr_6_St_7_RotR;
      break;
    case Adacrus__St_7_Rot180:
      next_node_St_7_Rot180 = self->next_node_5;
      next_node = next_node_St_7_Rot180;
      _out->v_l = v_l_St_7_Rot180;
      _out->v_r = v_r_St_7_Rot180;
      ns_6 = ns_6_St_7_Rot180;
      nr_6 = nr_6_St_7_Rot180;
      break;
    case Adacrus__St_7_DecideAction:
      switch (ck_2) {
        case Adacrus__St_3_Decidado:
          if (r_19) {
            Adacrus__decideAction_reset(&self->decideAction);
          };
          Adacrus__decideAction_step(self->next_node_5,
                                     self->current_state_2, oriented,
                                     ir_prox, &Adacrus__decideAction_out_st,
                                     &self->decideAction);
          next_node_St_7_DecideAction_St_3_Decidado = Adacrus__decideAction_out_st.next_node;
          next_state_St_3_Decidado = Adacrus__decideAction_out_st.next_state;
          next_state = next_state_St_3_Decidado;
          break;
        case Adacrus__St_3_CenterAlign:
          next_state = next_state_St_3_CenterAlign;
          break;
        case Adacrus__St_3_LeaveNode:
          next_state = next_state_St_3_LeaveNode;
          break;
        default:
          break;
      };
      v_541 = (next_state==Adacrus__Exit);
      v_542 = (out_of_node&&v_541);
      if (v_542) {
        v_544 = true;
        v_543 = Adacrus__St_7_Exit;
      } else {
        v_544 = false;
        v_543 = Adacrus__St_7_DecideAction;
      };
      v_539 = (next_state==Adacrus__Moving);
      v_540 = (out_of_node&&v_539);
      if (v_540) {
        v_546 = true;
        v_545 = Adacrus__St_7_Moving;
      } else {
        v_546 = v_544;
        v_545 = v_543;
      };
      v_537 = (next_state==Adacrus__Rot180);
      v_538 = (out_of_node&&v_537);
      if (v_538) {
        v_548 = true;
        v_547 = Adacrus__St_7_Rot180;
      } else {
        v_548 = v_546;
        v_547 = v_545;
      };
      v_535 = (next_state==Adacrus__RotR);
      v_536 = (out_of_node&&v_535);
      if (v_536) {
        v_550 = true;
        v_549 = Adacrus__St_7_RotR;
      } else {
        v_550 = v_548;
        v_549 = v_547;
      };
      v_533 = (next_state==Adacrus__RotL);
      v_534 = (out_of_node&&v_533);
      if (v_534) {
        nr_6_St_7_DecideAction = true;
        ns_6_St_7_DecideAction = Adacrus__St_7_RotL;
      } else {
        nr_6_St_7_DecideAction = v_550;
        ns_6_St_7_DecideAction = v_549;
      };
      switch (ck_2) {
        case Adacrus__St_3_LeaveNode:
          next_node_St_7_DecideAction_St_3_LeaveNode = self->next_node_5;
          next_node_St_7_DecideAction = next_node_St_7_DecideAction_St_3_LeaveNode;
          break;
        case Adacrus__St_3_CenterAlign:
          next_node_St_7_DecideAction_St_3_CenterAlign = self->next_node_5;
          next_node_St_7_DecideAction = next_node_St_7_DecideAction_St_3_CenterAlign;
          break;
        case Adacrus__St_3_Decidado:
          next_node_St_7_DecideAction = next_node_St_7_DecideAction_St_3_Decidado;
          break;
        default:
          break;
      };
      next_node = next_node_St_7_DecideAction;
      _out->v_l = v_l_St_7_DecideAction;
      _out->v_r = v_r_St_7_DecideAction;
      ns_6 = ns_6_St_7_DecideAction;
      nr_6 = nr_6_St_7_DecideAction;
      break;
    default:
      break;
  };
  _out->nnode = next_node;
  self->debug_state_1 = debug_state;
  self->current_state_2 = current_state;
  self->oriented_4 = oriented;
  self->next_node_5 = next_node;
  self->pnr_6 = nr_6;
  switch (self->ck) {
    case Adacrus__St_7_Moving:
      self->v_581 = inverted_t;
      self->v_579 = false;
      break;
    case Adacrus__St_7_DecideAction:
      self->next_state_4 = next_state;
      self->v_572 = out_of_node;
      self->v_571 = nr_2;
      self->v_570 = ns_2;
      switch (ck_2) {
        case Adacrus__St_3_CenterAlign:
          self->v_568 = nr;
          self->v_566 = ns;
          switch (ck_3) {
            case Adacrus__St_2_TryLeft:
              self->v_563 = t_left;
              self->v_559 = false;
              break;
            case Adacrus__St_2_TryRight:
              self->v_556 = t_right;
              self->v_552 = false;
              break;
            default:
              break;
          };
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_7_RotL:
      self->v_532 = exit_1;
      self->v_531 = nr_3;
      self->v_530 = ns_3;
      switch (ck_4) {
        case Adacrus__St_4_GoAhead:
          self->v_528 = t_forward;
          self->v_525 = false;
          break;
        case Adacrus__St_4_BlackToWhite:
          self->v_522 = t_left_1;
          self->v_519 = false;
          break;
        case Adacrus__St_4_TurnLeft:
          self->v_516 = t_left_2;
          self->v_513 = false;
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_7_RotR:
      self->v_509 = exit_2;
      self->v_508 = nr_4;
      self->v_507 = ns_4;
      switch (ck_5) {
        case Adacrus__St_5_GoAhead:
          self->v_505 = t_forward_1;
          self->v_502 = false;
          break;
        case Adacrus__St_5_BlackToWhite:
          self->v_499 = t_right_1;
          self->v_496 = false;
          break;
        case Adacrus__St_5_TurnRight:
          self->v_493 = t_right_2;
          self->v_490 = false;
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_7_Rot180:
      self->v_486 = exit_3;
      self->v_485 = nr_5;
      self->v_484 = ns_5;
      switch (ck_6) {
        case Adacrus__St_6_GoAhead:
          self->v_482 = t_forward_2;
          self->v_479 = false;
          break;
        case Adacrus__St_6_TurnRight:
          self->v_476 = t_right_3;
          self->v_473 = false;
          break;
        case Adacrus__St_6_TurnRightAgain:
          self->v_468 = t_right_again;
          self->v_465 = false;
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };
  self->ck = ns_6;;
}

void Adacrus__main_reset(Adacrus__main_mem* self) {
  Adacrus__adacrus_params_35__reset(&self->adacrus);
}

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self) {
  Adacrus__adacrus_params_35__out Adacrus__adacrus_params_35__out_st;
  Adacrus__adacrus_params_35__step(left_wl, center_wl, right_wl, ir_prox,
                                   &Adacrus__adacrus_params_35__out_st,
                                   &self->adacrus);
  _out->v_l = Adacrus__adacrus_params_35__out_st.v_l;
  _out->v_r = Adacrus__adacrus_params_35__out_st.v_r;
  _out->o = Adacrus__adacrus_params_35__out_st.o;
  _out->dir = Adacrus__adacrus_params_35__out_st.dir;
  _out->s = Adacrus__adacrus_params_35__out_st.s;
  _out->d_s = Adacrus__adacrus_params_35__out_st.d_s;
  _out->next_node = Adacrus__adacrus_params_35__out_st.nnode;
}

