#include <Arduino.h>

// define common function for Task1 & Task2
void vTaskFunction( void *pvParameters );

// define Handles for two tasks: Task1 & Task2
TaskHandle_t Handle_vTask1;
TaskHandle_t Handle_vTask2;

/* Define the strings that will be passedin as the task parameters. These are
   defined const and not onthe stack to ensure they remain valid when the tasks are
   executing.
*/
static const char *pcTextForTask1 = "Task 1 is running via vTaskFunction\r\n";
static const char *pcTextForTask2 = "Task 2 is running via vTaskFunction\r\n";


void setup() {
  
  // initialize serial communication at 115200 bits per second:
  Serial.begin(115200);
  
  // Now set up two tasks to run independently.
  xTaskCreate(
    vTaskFunction,
    "Task_1",                   // A name just for humans
    configMINIMAL_STACK_SIZE,   // This stack size can be checked & adjusted by reading the Stack Highwater
    (void *) pcTextForTask1,     // Parameters to pass
    1,                          // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    &Handle_vTask1              // Task Handle
  );
  
  /*
  // Experimenting with equal priority between the Tasks
  // cretaing the "Task_2" with equal priority as "Task_1"
  xTaskCreate( vTaskFunction, "Task_2", configMINIMAL_STACK_SIZE, (void *) pcTextForTask2, 1, &Handle_vTask2 );
  */

  //
  // Experimenting with un-equal priority between the Tasks
  // cretaing the "Task_2" with un-equal priority as "Task_1"
  xTaskCreate( vTaskFunction, "Task_2", configMINIMAL_STACK_SIZE, (void *) pcTextForTask2, 2, &Handle_vTask2 );
  //
  
  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
}

void loop() {
  // Empty. Things are done in Tasks.
}


/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/

// =========== Using for loop to create delay in TaskFunction ===========
// Task function with delay using the crude polling for loop
// where the Task consumes most of the processors time
// by just doing nothing.
// Tasks of this nature are called "continuous processing" tasks,
// as they always have work to do.
// Such tasks are in either the Ready or the Running state.
/*
void vTaskFunction(void *pvParameters) {

  char *pcTaskName;

  pcTaskName = (char *) pvParameters;
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the name of this task.
    Serial.print(pcTaskName);
    
    // Delay for a period.
    for( int i = 0; i < 10000; i++ )
    {
      // This loop is just a very crude delay implementation. There is
      // nothing to do in here.  Later examples will replace this crude
      // loop with a proper delay/sleep function.
    }
  }
}
*/


// =========== Using vTaskDelay() to create delay in TaskFunction ===========
// The function with delay specified in number of tick interrupts
// that places the calling task into the Blocked state.
// The task does not use any processing time while it is in the Blocked state,
// so the task uses processing time when there is actually work to be done.
// But, the time at which the task leaves the blocked state is relative to the time
// at which the vTaskDelay() was called.
/*
void vTaskFunction(void *pvParameters) {

  char *pcTaskName;
  const TickType_t xDelay500ms = pdMS_TO_TICKS( 500 );

  pcTaskName = (char *) pvParameters;
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the name of this task.
    Serial.print(pcTaskName);
    
    // Delay for a period.
    // This time a call to vTaskDelay() is used which places
    // the task into the Blocked state until the delay period has expired.
    // The parameter takes a time specified in ‘ticks’, andthe pdMS_TO_TICKS() macro is used
    // (where the xDelay500ms constant is declared) to convert 500 milliseconds into an equivalent time in ticks.
    vTaskDelay( xDelay500ms );
  }
}
*/


// =========== Using vTaskDelayUntil() to create delay in TaskFunction ===========
// The time at which the task leaves the blocked state is relative to the time
// at which the vTaskDelay() was called.
// The parameters to vTaskDelayUntil() specify the exact tick count value at which the
// calling task should be moved from the Blocked state into the Ready state.
// vTaskDelayUntil() should be used when a fixed execution period is required
// (where we want the task to execute periodically with a fixed frequency),
// as the time at which the calling task is unblocked is absolute, rather than
// relative to when the function was called (as is the case with vTaskDelay()).
//
void vTaskFunction(void *pvParameters) {

  char *pcTaskName;
  TickType_t xLastWakeTime;

  pcTaskName = (char *) pvParameters;

  // The xLastWakeTime variable needs to be initialized with the current tickcount.
  // Note that this is the only time the variable is written to explicitly.
  // After this xLastWakeTime is automatically updated within vTaskDelayUntil().
  xLastWakeTime = xTaskGetTickCount();
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the name of this task.
    Serial.print(pcTaskName);
    
    // Delay for a period.
    // This task should execute every 500 milliseconds exactly.
    // As perthe vTaskDelay() function, time is measured in ticks, and the
    // pdMS_TO_TICKS() macrois used to convert milliseconds into ticks.
    // xLastWakeTime is automatically updated within vTaskDelayUntil(),
    // so is not explicitly updated by the task.
    vTaskDelayUntil( &xLastWakeTime, pdMS_TO_TICKS( 500 ));
  }
}
//

