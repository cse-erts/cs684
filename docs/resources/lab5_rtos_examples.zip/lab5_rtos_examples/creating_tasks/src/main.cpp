#include <Arduino.h>

// define two functions for Task1 & Task2
void vTask1( void *pvParameters );
void vTask2( void *pvParameters );

// define Handles for two tasks: Task1 & Task2
TaskHandle_t Handle_vTask1;
TaskHandle_t Handle_vTask2;

void setup() {
  
  // initialize serial communication at 115200 bits per second:
  Serial.begin(115200);
  
  // Now set up two tasks to run independently.
  xTaskCreate(
    vTask1,
    "Task_1",                   // A name just for humans
    configMINIMAL_STACK_SIZE,   // This stack size can be checked & adjusted by reading the Stack Highwater
    NULL,                       // Parameters to pass
    1,                          // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    &Handle_vTask1              // Task Handle
  );
  
  // creating the "Task_2" with equal priority as "Task_1"
  xTaskCreate( vTask2, "Task_2", configMINIMAL_STACK_SIZE, NULL, 1, &Handle_vTask2 );
  
  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
}

void loop() {
  // Empty. Things are done in Tasks.
}


/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/


void vTask1(void *pvParameters) {

  const char *pcTaskName = "Task 1 is running\r\n";
  
  /* As per most tasks, this task is implemented in an infinite loop. */
  for( ;; ) {

    /* Print out the name of this task. */
    Serial.print(pcTaskName);
    
    /* Delay for a period. */
    for( int i = 0; i < 1000; i++ )
    {
      /* This loop is just a very crude delay implementation. There is
      nothing to do in here.  Later examples will replace this crude
      loop with a proper delay/sleep function. */
    }
  }
}


void vTask2(void *pvParameters) {

  const char *pcTaskName = "Task 2 is running\r\n";
  
  /* As per most tasks, this task is implemented in an infinite loop. */
  for( ;; ) {

    /* Print out the name of this task. */
    Serial.print(pcTaskName);
    
    /* Delay for a period. */
    for( int i = 0; i < 1000; i++ )
    {
      /* This loop is just a very crude delay implementation. There is
      nothing to do in here.  Later examples will replace this crude
      loop with a proper delay/sleep function. */
    }
  }
}

