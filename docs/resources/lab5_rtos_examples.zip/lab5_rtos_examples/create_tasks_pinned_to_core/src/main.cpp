#include <Arduino.h>


#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif

// define two tasks for Blink & SerialPrint
void vTaskBlink( void *pvParameters );
void vTaskSerialPrint( void *pvParameters );

// define Handles for two tasks: Blink & SerialPrint
TaskHandle_t Handle_vTaskBlink;
TaskHandle_t Handle_vTaskSerialPrint;


// the setup function runs once when you press reset or power the board
void setup() {
  
  // initialize serial communication at 115200 bits per second:
  Serial.begin(115200);
  
  // Now set up two tasks to run independently.
  xTaskCreatePinnedToCore(
    vTaskBlink,
    "TaskBlink",          // A name just for humans
    600,                 // This stack size can be checked & adjusted by reading the Stack Highwater
    NULL,                 // Parameters to pass
    2,                    // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    &Handle_vTaskBlink,     // Task Handle
    1                     // Core on where the Task should run
  );
  
  xTaskCreatePinnedToCore(
    vTaskSerialPrint,
    "Serial Print",
    configMINIMAL_STACK_SIZE,
    NULL,
    1,
    &Handle_vTaskSerialPrint,
    0
  );
  
  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
}


void loop()
{
  // Empty. Things are done in Tasks.
}

/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/


void vTaskBlink(void *pvParameters)  // This is a task.
{
/*
  Blink
  Turns on an LED on for one second, then off for one second, repeatedly.
    
  If you want to know what pin the on-board LED is connected to on your ESP32 model, check
  the Technical Specs of your board.
*/

  // initialize digital LED_BUILTIN on pin 2 as an output.
  pinMode(LED_BUILTIN, OUTPUT);

  for (;;) // A Task shall never return or exit.
  {
    Serial.println("======================================");

    Serial.print("vTaskBlink running on core ");
    Serial.println(xPortGetCoreID());
    
    Serial.print("vTaskBlink stack usage: ");
    Serial.println(uxTaskGetStackHighWaterMark( NULL ));

    Serial.print("vTaskBlink Priority set to: ");
    Serial.println(uxTaskPriorityGet( NULL ));

    Serial.println("======================================");
    
    digitalWrite(LED_BUILTIN, HIGH);    // turn the LED on (HIGH is the voltage level)
    vTaskDelay(1000 / portTICK_PERIOD_MS );                   // one tick delay (15ms) in between reads for stability
    digitalWrite(LED_BUILTIN, LOW);     // turn the LED off by making the voltage LOW
    vTaskDelay(1000);                   // one tick delay (15ms) in between reads for stability
  }
}

void vTaskSerialPrint(void *pvParameters)  // This is a task.
{
  for (;;)
  {
    Serial.print("vTaskSerialPrint running on core ");
    Serial.println(xPortGetCoreID());

    Serial.print("vTaskSerialPrint stack usage: ");
    Serial.println(uxTaskGetStackHighWaterMark( NULL ));

    Serial.print("vTaskSerialPrint Priority set to: ");
    Serial.println(uxTaskPriorityGet( NULL ));

    vTaskDelay(500);                   // one tick delay (15ms) in between reads for stability
  }
}