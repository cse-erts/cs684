#include <Arduino.h>

// define common function for Continuous Processing Task1 & Task2
void vContinuousProcessingTask( void *pvParameters );
// define the function for Periodic Task
void vPeriodicTask( void *pvParameters );

// define Handles for two tasks: Task1 & Task2
TaskHandle_t Handle_vTask1;
TaskHandle_t Handle_vTask2;
TaskHandle_t Handle_vPeriodicTask;

/* Define the strings that will be passedin as the task parameters. These are
   defined const and not onthe stack to ensure they remain valid when the tasks are
   executing.
*/
static const char *pcTextForTask1 = "Task 1 is running via vContinuousProcessingTask\r\n";
static const char *pcTextForTask2 = "Task 2 is running via vContinuousProcessingTask\r\n";


void setup() {
  
  // initialize serial communication at 115200 bits per second:
  Serial.begin(115200);
  
  // Now set up two tasks to run independently.
  // cretaing the Continuous Processing "Task_1" with equal priority as "Task_2"
  xTaskCreate(
    vContinuousProcessingTask,
    "Task_1",                   // A name just for humans
    configMINIMAL_STACK_SIZE,   // This stack size can be checked & adjusted by reading the Stack Highwater
    (void *) pcTextForTask1,     // Parameters to pass
    1,                          // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    &Handle_vTask1              // Task Handle
  );
  
  //
  // Experimenting with equal priority between the Tasks
  // cretaing the Continuous Processing "Task_2" with equal priority as "Task_1"
  xTaskCreate( vContinuousProcessingTask, "Task_2", configMINIMAL_STACK_SIZE, (void *) pcTextForTask2, 1, &Handle_vTask2 );
  //

  // creating the "Periodic Task" with priority greater than "Task_1" and "Task_2"
  xTaskCreate( vPeriodicTask, "Periodic_Task", configMINIMAL_STACK_SIZE, NULL, 2, &Handle_vPeriodicTask );
  
  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
}

void loop() {
  // Empty. Things are done in Tasks.
}


/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/

// =========== Using for loop to create delay in ContinuousProcessingTask ===========
// Task function with delay using the crude polling for loop
// where the Task consumes most of the processors time
// by just doing nothing.
// Tasks of this nature are called "continuous processing" tasks,
// as they always have work to do.
// Such tasks are in either the Ready or the Running state.
//
void vContinuousProcessingTask(void *pvParameters) {

  char *pcTaskName;

  pcTaskName = (char *) pvParameters;
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the name of this task.
    Serial.print(pcTaskName);
    
  }
}
//


// =========== Using vTaskDelayUntil() to create delay in PeriodicTask ===========
// The time at which the Periodic task leaves the blocked state is relative to the time
// at which the vTaskDelay() was called.
//
void vPeriodicTask(void *pvParameters) {

  TickType_t xLastWakeTime;
  const TickType_t xDelay2ms = pdMS_TO_TICKS( 2 );

  // The xLastWakeTime variable needs to be initialized with the current tickcount.
  // Note that this is the only time the variable is written to explicitly.
  // After this xLastWakeTime is automatically updated within vTaskDelayUntil().
  xLastWakeTime = xTaskGetTickCount();
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the name of this task.
    Serial.println("Periodic task is running");
    
    // Delay for a period.
    // This task should execute every 2 milliseconds exactly.
    vTaskDelayUntil( &xLastWakeTime, xDelay2ms );
  }
}
//

