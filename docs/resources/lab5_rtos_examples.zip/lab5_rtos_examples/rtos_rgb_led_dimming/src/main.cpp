#include <Arduino.h>

#define RED_LED_PIN 5
#define GREEN_LED_PIN 4
#define BLUE_LED_PIN 15

// define functions for Blinking RGB LEDs
void vBlinkRed( void *pvParameters );
void vBlinkGreen( void *pvParameters );
void vBlinkBlue( void *pvParameters );

// define Handles for three tasks: BlinkRed, BlinkGreen and BlinkBlue
TaskHandle_t Handle_vBlinkRed;
TaskHandle_t Handle_vBlinkGreen;
TaskHandle_t Handle_vBlinkBlue;


void setup() {
  
  // initialize serial communication at 115200 bits per second:
  Serial.begin(115200);
  
  // Now set up three tasks to run independently.
  xTaskCreate( vBlinkRed, "BlinkRed", configMINIMAL_STACK_SIZE, NULL, 1, &Handle_vBlinkRed );
  xTaskCreate( vBlinkGreen, "BlinkGreen", configMINIMAL_STACK_SIZE, NULL, 1, &Handle_vBlinkGreen );
  xTaskCreate( vBlinkBlue, "BlinkBlue", configMINIMAL_STACK_SIZE, NULL, 1, &Handle_vBlinkBlue );
  
  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
}

void loop() {
  // Empty. Things are done in Tasks.
}


/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/


//
void vBlinkRed(void *pvParameters) {

  TickType_t xLastWakeTime;
  const TickType_t xDelay500ms = pdMS_TO_TICKS( 500 );

  pinMode(RED_LED_PIN, OUTPUT);

  // The xLastWakeTime variable needs to be initialized with the current tickcount.
  // Note that this is the only time the variable is written to explicitly.
  // After this xLastWakeTime is automatically updated within vTaskDelayUntil().
  xLastWakeTime = xTaskGetTickCount();
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the Color of LED
    Serial.println("Turning ON the LED of Color RED");
    digitalWrite( RED_LED_PIN, LOW );
    vTaskDelayUntil( &xLastWakeTime, xDelay500ms);

    Serial.println("Turning OFF the LED of Color RED");
    digitalWrite( RED_LED_PIN, HIGH );
    vTaskDelayUntil( &xLastWakeTime, xDelay500ms);
  }
}
//


//
void vBlinkGreen(void *pvParameters) {

  TickType_t xLastWakeTime;
  const TickType_t xDelay1000ms = pdMS_TO_TICKS( 1000 );

  pinMode(GREEN_LED_PIN, OUTPUT);

  // The xLastWakeTime variable needs to be initialized with the current tickcount.
  // Note that this is the only time the variable is written to explicitly.
  // After this xLastWakeTime is automatically updated within vTaskDelayUntil().
  xLastWakeTime = xTaskGetTickCount();
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the Color of LED
    Serial.println("Turning ON the LED of Color GREEN");
    digitalWrite( GREEN_LED_PIN, LOW );
    vTaskDelayUntil( &xLastWakeTime, xDelay1000ms);

    Serial.println("Turning OFF the LED of Color GREEN");
    digitalWrite( GREEN_LED_PIN, HIGH );
    vTaskDelayUntil( &xLastWakeTime, xDelay1000ms);
  }
}
//


//
void vBlinkBlue(void *pvParameters) {

  TickType_t xLastWakeTime;
  const TickType_t xDelay250ms = pdMS_TO_TICKS( 250 );

  pinMode(BLUE_LED_PIN, OUTPUT);

  // The xLastWakeTime variable needs to be initialized with the current tickcount.
  // Note that this is the only time the variable is written to explicitly.
  // After this xLastWakeTime is automatically updated within vTaskDelayUntil().
  xLastWakeTime = xTaskGetTickCount();
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Print out the Color of LED
    Serial.println("Turning ON the LED of Color BLUE");
    digitalWrite( BLUE_LED_PIN, LOW );
    vTaskDelayUntil( &xLastWakeTime, xDelay250ms);

    Serial.println("Turning OFF the LED of Color BLUE");
    digitalWrite( BLUE_LED_PIN, HIGH );
    vTaskDelayUntil( &xLastWakeTime, xDelay250ms);
  }
}
//

