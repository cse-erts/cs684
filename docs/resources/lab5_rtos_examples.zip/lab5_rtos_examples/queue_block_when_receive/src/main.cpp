#include <Arduino.h>

// define common function for two Senders
static void vSenderTask( void *pvParameters );

// define function for one Receiver
static void vReceiverTask( void *pvParameters );

// define Handles for two Sender tasks: SenderTask1 & SenderTask2
TaskHandle_t Handle_vSenderTask1;
TaskHandle_t Handle_vSenderTask2;

// define handles for one Receiver task: ReceiverTask
TaskHandle_t Handle_vReceiverTask;

// declare a variable of type QueueHandle_t
// this is used to store the handle to the queue that is accessed
// by all three tasks
QueueHandle_t xQueue;

void setup() {
  
  // initialize serial communication at 115200 bits per second
  Serial.begin(115200);

  // the queue is created to hold a maximum of 5 values,
  // each of which is large enough to hold a variable of type int32_t
  xQueue = xQueueCreate( 5, sizeof( int32_t ) );

  if ( xQueue != NULL ) {

    // Create two instances of the task that will send data to the queue.
    // The task parameter is used to pass the value that the task will write
    // to the queue, so one task will continuously write 100 to the queue while
    // the other task will continuously write 200 to the queue.
    // Both tasks are created at priority 1.
    xTaskCreate( vSenderTask, "Sender_Task1", 1000, (void *) 100, 1, &Handle_vSenderTask1 );
    xTaskCreate( vSenderTask, "Sender_Task2", 1000, (void *) 200, 1, &Handle_vSenderTask2 );

    // Create the task that will read from the queue.
    // The task is created with priority 2, so above the priority of the sender tasks
    xTaskCreate( vReceiverTask, "Receiver_Task", 1000, NULL, 2, &Handle_vReceiverTask );

  }
  else {
    // The queue could not be created
  }

  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
  for( ;; );
}

void loop() {
  // Empty. Things are done in Tasks.
}


/*--------------------------------------------------*/
/*---------------------- Tasks ---------------------*/
/*--------------------------------------------------*/


// =========== SenderTask function to write data onto the queue ===========
//
static void vSenderTask( void *pvParameters ) {

  int32_t lValueToSend;
  BaseType_t xStatus;

  // Two instances of this task are created so the value that is sent to the
  // queue is pass in via the task parameter - this way each instance can use
  // a different value. The queue was created to hold values of type int32_t.
  lValueToSend = ( int32_t ) pvParameters;
  
  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // Send the value to the queue.

    // The first parameter is the queue to which data is being sent.
    // The queue was created before the schedule was started,
    // so before this task started to execute.

    // The second parameter is the address of the data to be sent,
    // in this case the address of lValueToSend.

    // The third parameter is the Block time - the time the task should be
    // kept in the Blocked state to wait for the space to become available
    // on the queue should the queue already be full.
    // In this case a block time is not specified because the queue should
    // never contain more than one item, and therefore never be full.
    xStatus = xQueueSendToBack( xQueue, &lValueToSend, 0 );

    if ( xStatus != pdPASS ) {

      // The send operation could not complete because the queue was full -
      // this must be an error as the queue should never contain more than one item
      Serial.println("Could not send data to the queue!");

    }
    
  }
}
//


// =========== ReceiverTask function to receive data from the queue ===========
//
static void vReceiverTask( void *pvParameters ) {

  // declare the variable that will hold the values received from the queue
  int32_t lReceivedValue;
  BaseType_t xStatus;
  const TickType_t xTicksToWait = pdMS_TO_TICKS( 100 );

  // As per most tasks, this task is implemented in an infinite loop.
  for( ;; ) {

    // This call should always find the queue empty because this task will
    // immediately remove any data that is written to the queue.
    if ( uxQueueMessagesWaiting( xQueue ) != 0 ) {

      // Serial.println("Queue should have been empty!");
      Serial.print("Number of items currently in the queue: ");
      Serial.println( uxQueueMessagesWaiting( xQueue ) );

    }

    // Receive the value from the queue.

    // The first parameter is the queue to which data is being sent.
    // The queue was created before the schedule was started,
    // and therefore before this task runs for the first time.

    // The second parameter is the buffer into which the received data
    // will be placed. In this case the buffer is simply the address
    // of a variable that has the required size to hold the received data.

    // The third parameter is the Block time - the maximum amount of time
    // that the task will remain in the Blocked state to wait for data
    // to be available should the queue already be empty.
    xStatus = xQueueReceive( xQueue, &lReceivedValue, xTicksToWait );

    if ( xStatus == pdPASS ) {

      // Data was successfully received from the queue,
      // print out the received value
      Serial.print("Received value = ");
      Serial.println(lReceivedValue);

    }
    else {

      // Data was not received from the queue even after waiting for 100ms.
      // This must be an error as the sending tasks are free running and will
      // be continuously writing to the queue.
      Serial.println("Could not receive data from the queue!");

    }
  }
}
//

