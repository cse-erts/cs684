#include <Arduino.h>
#include <U8g2lib.h>

#ifdef U8X8_HAVE_HW_SPI
#include <SPI.h>
#endif
#ifdef U8X8_HAVE_HW_I2C
#include <Wire.h>
#endif

// U8g2 Contructor List (Frame Buffer)
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);

// define handle for Mutex
SemaphoreHandle_t xMutex;

// define handle for PrintTask1 and PrintTask2
TaskHandle_t Handle_vPrintTask1;
TaskHandle_t Handle_vPrintTask2;

// declare a function to print string on the guarded resource, i.e. OLED
static void vPrintStringOLED( const char *pcString );
static void vPrintTask( void *pvParameters );

void setup() {
  
  // initialize the OLED SH1106
  u8g2.begin();
  delay(1000);

  Serial.begin(115200);

  // before a semaphore is used it must be explicitly created
  xMutex = xSemaphoreCreateMutex();

  // check whether the semaphore was created successfully before creating the tasks
  if ( xMutex != NULL ) {

    // Create two instances of the tasks that write to OLED.
    // The string they write is passed in to the Task as the Task's parameter.
    // The tasks are created at different priorities so pre-emption will occur.
    xTaskCreate( vPrintTask, "Print_Task1", 2048, (void *) "*** Task 1 ***", 1, &Handle_vPrintTask1 );
    xTaskCreate( vPrintTask, "Print_Task2", 2048, (void *) "### Task 2 ###", 2, &Handle_vPrintTask2 );

  }
}

void loop() {
  // put your main code here, to run repeatedly:
}


static void vPrintTask( void *pvParameters ) {

  char *pcStringToPrint;
  const TickType_t xMaxBlockTimeTicks = 0x20;

  // Two instances of this task are created. The string printed by the task
  // is passed into the task using the Task's parameter.
  // The paramter is cast to the requireed type.
  pcStringToPrint = (char *) pvParameters;

  // As per most tasks, this task is implemented in an infinite loop.
  for ( ;; ) {

    // Print out the string using the vPrintStringOLED function
    vPrintStringOLED( pcStringToPrint );

    // Wait for a pseudo random time.
    vTaskDelay( rand() % xMaxBlockTimeTicks );

  }

}


static void vPrintStringOLED( const char *pcString ) {

  // The mutex is created before the scheduler is started,
  // so already exists by the time this task executes.

  // Attempt to take the mutex, blocking indefinitely to wait
  // for the mutex if it is not available straight away.
  // The call to xSemaphoreTake() will only return when the mutex
  // has been successfully obtained, so there is no need to check
  // the function return value.
  // If any other delay period was used then the code must check that
  // xSemaphoreTake() returns pdTRUE before accessing the shared resource
  // (which in this case is OLED).
  xSemaphoreTake( xMutex, portMAX_DELAY );

  Serial.println( pcString );

  // The following line will only execute once the mutex has been
  // successfully obtained.
  // OLED can be accessed freely now as only one task can have the mutex
  // at any one time.
  //
  u8g2.clearBuffer();					        // clear the internal memory
  u8g2.setFont(u8g2_font_ncenB08_tr);	// choose a suitable font
  u8g2.drawStr(0, 10, pcString);	    // write something to the internal memory
  u8g2.sendBuffer();					        // transfer internal memory to the display
  //
  delay(1000);

  // The Mutex MUST be given back
  xSemaphoreGive( xMutex );

}

