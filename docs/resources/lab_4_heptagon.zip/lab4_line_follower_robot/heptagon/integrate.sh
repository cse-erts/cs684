#!/usr/bin/env bash
(simulate.sh -s main -p adacrus.ept -k 1) >> /dev/null

dest_src="/home/rutuja/Desktop/test2/lab4_line_follower_robot/src"
dest_include="/home/rutuja/Desktop/test2/lab4_line_follower_robot/include"
src="adacrus_c"
cp "$src/adacrus.c" "$dest_src"
cp "$src/adacrus_types.c" "$dest_src"
cp "$src/adacrus_types.h" "$dest_include"
cp "$src/adacrus.h" "$dest_include"

begin="#ifdef __cplusplus
extern \"C\" {
#endif
"
end="\n#ifdef __cplusplus\n}\n#endif
"
yourfile="$dest_include/adacrus.h"
exec 3<> "$yourfile" && awk -v TEXT="$begin" 'BEGIN {print TEXT}{print}' "$yourfile" >&3
echo -e $end >> "$yourfile"
