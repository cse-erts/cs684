/* --- Generated the 6/4/2022 at 17:12 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 15 3:31:18 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef _MAIN_H
#define _MAIN_H

#include "adacrus.h"
#endif // _MAIN_H
