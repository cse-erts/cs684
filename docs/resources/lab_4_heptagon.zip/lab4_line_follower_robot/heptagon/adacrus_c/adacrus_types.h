/* --- Generated the 6/4/2022 at 17:12 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 15 3:31:18 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_TYPES_H
#define ADACRUS_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
static const float Adacrus__kp = 1.000000;

static const float Adacrus__ki = 0.000000;

static const float Adacrus__kd = 0.217000;

static const int Adacrus__max_velocity = 250;

#endif // ADACRUS_TYPES_H
