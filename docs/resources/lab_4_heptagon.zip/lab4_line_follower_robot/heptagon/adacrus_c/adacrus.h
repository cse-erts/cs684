/* --- Generated the 6/4/2022 at 17:12 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 15 3:31:18 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_H
#define ADACRUS_H

#include "adacrus_types.h"
typedef struct Adacrus__find_velocities_out {
  int v_l;
  int v_r;
} Adacrus__find_velocities_out;

void Adacrus__find_velocities_step(int speed,
                                   Adacrus__find_velocities_out* _out);

typedef struct Adacrus__adacrus_mem {
  int v_25;
  int v_24;
  int v_22;
  int v_21;
  int v_15;
  int v_14;
} Adacrus__adacrus_mem;

typedef struct Adacrus__adacrus_out {
  int v_l;
  int v_r;
} Adacrus__adacrus_out;

void Adacrus__adacrus_reset(Adacrus__adacrus_mem* self);

void Adacrus__adacrus_step(int left_wl, int center_wl, int right_wl,
                           Adacrus__adacrus_out* _out,
                           Adacrus__adacrus_mem* self);

typedef struct Adacrus__main_mem {
  Adacrus__adacrus_mem adacrus;
} Adacrus__main_mem;

typedef struct Adacrus__main_out {
  int v_l;
  int v_r;
} Adacrus__main_out;

void Adacrus__main_reset(Adacrus__main_mem* self);

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        Adacrus__main_out* _out, Adacrus__main_mem* self);

#endif // ADACRUS_H
