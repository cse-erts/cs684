/* --- Generated the 6/4/2022 at 17:12 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. jan. 15 3:31:18 CET 2022) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "adacrus.h"

void Adacrus__find_velocities_step(int speed,
                                   Adacrus__find_velocities_out* _out) {
  
  int v_9;
  int v_8;
  int v_7;
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int v;
  v_4 = -(speed);
  v_5 = (200-v_4);
  v_3 = (200-speed);
  v_2 = (speed>0);
  if (v_2) {
    v_7 = 200;
    v_6 = v_3;
  } else {
    v_7 = v_5;
    v_6 = 200;
  };
  v_1 = (speed<-200);
  if (v_1) {
    v_9 = 0;
    v_8 = 200;
  } else {
    v_9 = v_7;
    v_8 = v_6;
  };
  v = (speed>200);
  if (v) {
    _out->v_r = 200;
    _out->v_l = 0;
  } else {
    _out->v_r = v_9;
    _out->v_l = v_8;
  };;
}

void Adacrus__adacrus_reset(Adacrus__adacrus_mem* self) {
  self->v_24 = true;
  self->v_21 = true;
  self->v_14 = true;
}

void Adacrus__adacrus_step(int left_wl, int center_wl, int right_wl,
                           Adacrus__adacrus_out* _out,
                           Adacrus__adacrus_mem* self) {
  Adacrus__find_velocities_out Adacrus__find_velocities_out_st;
  
  int v_26;
  int v_23;
  int v_20;
  int v_19;
  int v_18;
  int v_17;
  int v_16;
  int v_13;
  int v_12;
  int v_11;
  int v_10;
  int v;
  int error;
  int difference_error;
  int integration_error;
  int speed;
  v_18 = (right_wl-left_wl);
  v_19 = (150*v_18);
  v_16 = -(self->v_15);
  if (self->v_14) {
    v_17 = 0;
  } else {
    v_17 = v_16;
  };
  v_12 = (center_wl==1);
  v_10 = (right_wl-left_wl);
  v_11 = (v_10==0);
  v_13 = (v_11&&v_12);
  if (v_13) {
    v_20 = v_17;
  } else {
    v_20 = v_19;
  };
  v = (center_wl==0);
  if (v) {
    error = 0;
  } else {
    error = v_20;
  };
  speed = (1*error);
  Adacrus__find_velocities_step(speed, &Adacrus__find_velocities_out_st);
  _out->v_l = Adacrus__find_velocities_out_st.v_l;
  _out->v_r = Adacrus__find_velocities_out_st.v_r;
  v_26 = (self->v_25+error);
  if (self->v_24) {
    integration_error = 0;
  } else {
    integration_error = v_26;
  };
  v_23 = (error-self->v_22);
  if (self->v_21) {
    difference_error = error;
  } else {
    difference_error = v_23;
  };
  self->v_25 = integration_error;
  self->v_24 = false;
  self->v_22 = error;
  self->v_21 = false;
  self->v_15 = error;
  self->v_14 = false;;
}

void Adacrus__main_reset(Adacrus__main_mem* self) {
  Adacrus__adacrus_reset(&self->adacrus);
}

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        Adacrus__main_out* _out, Adacrus__main_mem* self) {
  Adacrus__adacrus_out Adacrus__adacrus_out_st;
  Adacrus__adacrus_step(left_wl, center_wl, right_wl,
                        &Adacrus__adacrus_out_st, &self->adacrus);
  _out->v_l = Adacrus__adacrus_out_st.v_l;
  _out->v_r = Adacrus__adacrus_out_st.v_r;
}

