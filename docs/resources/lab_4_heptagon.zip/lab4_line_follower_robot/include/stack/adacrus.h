/* --- Generated the 11/3/2021 at 15:41 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sun. feb. 7 23:0:23 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_H
#define ADACRUS_H

#include "adacrus_types.h"
typedef struct Adacrus__move_out {
  int v_l;
  int v_r;
} Adacrus__move_out;

void Adacrus__move_step(int left_wl, int center_wl, int right_wl,
                        Adacrus__move_out* _out);

typedef struct Adacrus__move_curve_mem {
  int v_21;
  int v_20;
  int v_17;
  int v_16;
  int v_12;
  int v_11;
} Adacrus__move_curve_mem;

typedef struct Adacrus__move_curve_out {
  int v_l;
  int v_r;
} Adacrus__move_curve_out;

void Adacrus__move_curve_reset(Adacrus__move_curve_mem* self);

void Adacrus__move_curve_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__move_curve_out* _out,
                              Adacrus__move_curve_mem* self);

typedef struct Adacrus__isnode_out {
  int out;
} Adacrus__isnode_out;

void Adacrus__isnode_step(int left_wl, int center_wl, int right_wl,
                          Adacrus__isnode_out* _out);

typedef struct Adacrus__isallwhite_out {
  int out;
} Adacrus__isallwhite_out;

void Adacrus__isallwhite_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__isallwhite_out* _out);

typedef struct Adacrus__isline_out {
  int out;
} Adacrus__isline_out;

void Adacrus__isline_step(int left_wl, int center_wl, int right_wl,
                          Adacrus__isline_out* _out);

typedef struct Adacrus__halt_out {
  int v_l;
  int v_r;
  Adacrus__direction dir;
} Adacrus__halt_out;

void Adacrus__halt_step(Adacrus__halt_out* _out);

typedef struct Adacrus__calcOrientation_out {
  Adacrus__orientation new_orientation;
} Adacrus__calcOrientation_out;

void Adacrus__calcOrientation_step(Adacrus__states current_state,
                                   Adacrus__orientation last_oriented,
                                   Adacrus__calcOrientation_out* _out);

typedef struct Adacrus__getNextNode_out {
  Adacrus__coordinates next_node;
} Adacrus__getNextNode_out;

void Adacrus__getNextNode_step(Adacrus__coordinates current_node,
                               Adacrus__states next_state,
                               Adacrus__orientation oriented,
                               Adacrus__getNextNode_out* _out);

typedef struct Adacrus__decideAction_mem {
  int v_117;
} Adacrus__decideAction_mem;

typedef struct Adacrus__decideAction_out {
  Adacrus__coordinates next_node;
  Adacrus__states next_state;
} Adacrus__decideAction_out;

void Adacrus__decideAction_reset(Adacrus__decideAction_mem* self);

void Adacrus__decideAction_step(Adacrus__coordinates current_node,
                                Adacrus__states last_state,
                                Adacrus__orientation oriented, int ir_prox,
                                Adacrus__decideAction_out* _out,
                                Adacrus__decideAction_mem* self);

typedef struct Adacrus__adacrus_params_35__mem {
  int v_138;
  int v_135;
  int v_146;
  int v_143;
  int v_152;
  int v_149;
  Adacrus__st_2 v_154;
  int v_156;
  int v_155;
  int v_163;
  int v_160;
  int v_169;
  int v_166;
  Adacrus__st_1 v_171;
  int v_173;
  int v_172;
  int v_180;
  int v_177;
  int v_186;
  int v_183;
  Adacrus__st v_188;
  int v_190;
  int v_189;
  Adacrus__st_3 ck;
  int pnr_3;
  Adacrus__states debug_state_1;
  Adacrus__states current_state_2;
  Adacrus__orientation oriented_3;
  Adacrus__coordinates next_node_3;
  Adacrus__decideAction_mem decideAction;
  Adacrus__move_curve_mem move_curve;
} Adacrus__adacrus_params_35__mem;

typedef struct Adacrus__adacrus_params_35__out {
  int v_l;
  int v_r;
  Adacrus__orientation o;
  Adacrus__direction dir;
  Adacrus__states s;
  Adacrus__states d_s;
} Adacrus__adacrus_params_35__out;

void Adacrus__adacrus_params_35__reset(Adacrus__adacrus_params_35__mem* self);

void Adacrus__adacrus_params_35__step(int left_wl, int center_wl,
                                      int right_wl, int ir_prox,
                                      Adacrus__adacrus_params_35__out* _out,
                                      Adacrus__adacrus_params_35__mem* self);

typedef struct Adacrus__main_mem {
  Adacrus__adacrus_params_35__mem adacrus;
} Adacrus__main_mem;

typedef struct Adacrus__main_out {
  int v_l;
  int v_r;
  Adacrus__orientation o;
  Adacrus__direction dir;
  Adacrus__states s;
  Adacrus__states d_s;
} Adacrus__main_out;

void Adacrus__main_reset(Adacrus__main_mem* self);

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self);

#endif // ADACRUS_H
