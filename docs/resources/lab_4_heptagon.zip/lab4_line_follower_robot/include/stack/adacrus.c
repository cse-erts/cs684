/* --- Generated the 11/3/2021 at 15:41 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sun. feb. 7 23:0:23 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "adacrus.h"

void Adacrus__move_step(int left_wl, int center_wl, int right_wl,
                        Adacrus__move_out* _out) {
  
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int v;
  v_2 = (right_wl>200);
  if (v_2) {
    v_4 = 50;
    v_3 = 200;
  } else {
    v_4 = 100;
    v_3 = 100;
  };
  v_1 = (left_wl>200);
  if (v_1) {
    v_6 = 200;
    v_5 = 50;
  } else {
    v_6 = v_4;
    v_5 = v_3;
  };
  v = (center_wl>200);
  if (v) {
    _out->v_r = 150;
    _out->v_l = 150;
  } else {
    _out->v_r = v_6;
    _out->v_l = v_5;
  };;
}

void Adacrus__move_curve_reset(Adacrus__move_curve_mem* self) {
  self->v_20 = true;
  self->v_16 = true;
  self->v_11 = true;
}

void Adacrus__move_curve_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__move_curve_out* _out,
                              Adacrus__move_curve_mem* self) {
  
  int v_43;
  int v_42;
  int v_41;
  int v_40;
  int v_39;
  int v_38;
  int v_37;
  int v_36;
  int v_35;
  int v_34;
  int v_33;
  int v_32;
  int v_31;
  int v_30;
  int v_29;
  int v_28;
  int v_27;
  int v_26;
  int v_25;
  int v_24;
  int v_23;
  int v_22;
  int v_19;
  int v_18;
  int v_15;
  int v_14;
  int v_13;
  int v_10;
  int v_9;
  int v_8;
  int v_7;
  int v;
  int curve_count;
  int saw_all_white;
  v_35 = (right_wl>200);
  if (v_35) {
    v_37 = 0;
    v_36 = 10;
  } else {
    v_37 = 0;
    v_36 = 50;
  };
  v_34 = (left_wl>200);
  if (v_34) {
    v_39 = 10;
    v_38 = 0;
  } else {
    v_39 = v_37;
    v_38 = v_36;
  };
  v_33 = (center_wl>200);
  if (v_33) {
    v_41 = 50;
    v_40 = 50;
  } else {
    v_41 = v_39;
    v_40 = v_38;
  };
  v_31 = (right_wl>200);
  v_29 = (left_wl<200);
  v_28 = (center_wl>200);
  v_30 = (v_28&&v_29);
  v_32 = (v_30&&v_31);
  if (v_32) {
    v_43 = 0;
    v_42 = 10;
  } else {
    v_43 = v_41;
    v_42 = v_40;
  };
  v_26 = (right_wl<200);
  v_24 = (left_wl>200);
  v_23 = (center_wl>200);
  v_25 = (v_23&&v_24);
  v_27 = (v_25&&v_26);
  if (v_27) {
    _out->v_r = 10;
    _out->v_l = 0;
  } else {
    _out->v_r = v_43;
    _out->v_l = v_42;
  };
  if (self->v_20) {
    v_22 = 0;
  } else {
    v_22 = self->v_21;
  };
  if (self->v_16) {
    v_18 = 0;
  } else {
    v_18 = self->v_17;
  };
  v_19 = (v_18+1);
  if (self->v_11) {
    v_13 = false;
  } else {
    v_13 = self->v_12;
  };
  v_14 = !(v_13);
  v_9 = (left_wl>200);
  v_7 = (right_wl>200);
  v = (center_wl>200);
  v_8 = (v||v_7);
  v_10 = (v_8||v_9);
  saw_all_white = !(v_10);
  v_15 = (saw_all_white&&v_14);
  if (v_15) {
    curve_count = v_19;
  } else {
    curve_count = v_22;
  };
  self->v_21 = curve_count;
  self->v_20 = false;
  self->v_17 = curve_count;
  self->v_16 = false;
  self->v_12 = saw_all_white;
  self->v_11 = false;;
}

void Adacrus__isnode_step(int left_wl, int center_wl, int right_wl,
                          Adacrus__isnode_out* _out) {
  
  int v_46;
  int v_45;
  int v_44;
  int v;
  v_46 = (right_wl>200);
  v_44 = (left_wl>200);
  v = (center_wl>200);
  v_45 = (v&&v_44);
  _out->out = (v_45&&v_46);;
}

void Adacrus__isallwhite_step(int left_wl, int center_wl, int right_wl,
                              Adacrus__isallwhite_out* _out) {
  
  int v_49;
  int v_48;
  int v_47;
  int v;
  v_49 = (right_wl<100);
  v_47 = (left_wl<100);
  v = (center_wl<100);
  v_48 = (v&&v_47);
  _out->out = (v_48&&v_49);;
}

void Adacrus__isline_step(int left_wl, int center_wl, int right_wl,
                          Adacrus__isline_out* _out) {
  _out->out = (center_wl>200);
}

void Adacrus__halt_step(Adacrus__halt_out* _out) {
  _out->dir = Adacrus__Stop;
  _out->v_r = 0;
  _out->v_l = 0;
}

void Adacrus__calcOrientation_step(Adacrus__states current_state,
                                   Adacrus__orientation last_oriented,
                                   Adacrus__calcOrientation_out* _out) {
  
  Adacrus__orientation v_95;
  Adacrus__orientation v_94;
  Adacrus__orientation v_93;
  Adacrus__orientation v_92;
  Adacrus__orientation v_91;
  Adacrus__orientation v_90;
  Adacrus__orientation v_89;
  Adacrus__orientation v_88;
  Adacrus__orientation v_87;
  Adacrus__orientation v_86;
  Adacrus__orientation v_85;
  int v_84;
  int v_83;
  int v_82;
  int v_81;
  int v_80;
  int v_79;
  int v_78;
  int v_77;
  int v_76;
  int v_75;
  int v_74;
  int v_73;
  int v_72;
  int v_71;
  int v_70;
  int v_69;
  int v_68;
  int v_67;
  int v_66;
  int v_65;
  int v_64;
  int v_63;
  int v_62;
  int v_61;
  int v_60;
  int v_59;
  int v_58;
  int v_57;
  int v_56;
  int v_55;
  int v_54;
  int v_53;
  int v_52;
  int v_51;
  int v_50;
  int v;
  v_83 = (current_state==Adacrus__Rot180);
  v_82 = (last_oriented==Adacrus__B);
  v_84 = (v_82&&v_83);
  if (v_84) {
    v_85 = Adacrus__T;
  } else {
    v_85 = last_oriented;
  };
  v_80 = (current_state==Adacrus__RotR);
  v_79 = (last_oriented==Adacrus__B);
  v_81 = (v_79&&v_80);
  if (v_81) {
    v_86 = Adacrus__L;
  } else {
    v_86 = v_85;
  };
  v_77 = (current_state==Adacrus__RotL);
  v_76 = (last_oriented==Adacrus__B);
  v_78 = (v_76&&v_77);
  if (v_78) {
    v_87 = Adacrus__R;
  } else {
    v_87 = v_86;
  };
  v_74 = (current_state==Adacrus__Rot180);
  v_73 = (last_oriented==Adacrus__L);
  v_75 = (v_73&&v_74);
  if (v_75) {
    v_88 = Adacrus__R;
  } else {
    v_88 = v_87;
  };
  v_71 = (current_state==Adacrus__RotR);
  v_70 = (last_oriented==Adacrus__L);
  v_72 = (v_70&&v_71);
  if (v_72) {
    v_89 = Adacrus__T;
  } else {
    v_89 = v_88;
  };
  v_68 = (current_state==Adacrus__RotL);
  v_67 = (last_oriented==Adacrus__L);
  v_69 = (v_67&&v_68);
  if (v_69) {
    v_90 = Adacrus__B;
  } else {
    v_90 = v_89;
  };
  v_65 = (current_state==Adacrus__Rot180);
  v_64 = (last_oriented==Adacrus__R);
  v_66 = (v_64&&v_65);
  if (v_66) {
    v_91 = Adacrus__L;
  } else {
    v_91 = v_90;
  };
  v_62 = (current_state==Adacrus__RotR);
  v_61 = (last_oriented==Adacrus__R);
  v_63 = (v_61&&v_62);
  if (v_63) {
    v_92 = Adacrus__B;
  } else {
    v_92 = v_91;
  };
  v_59 = (current_state==Adacrus__RotL);
  v_58 = (last_oriented==Adacrus__R);
  v_60 = (v_58&&v_59);
  if (v_60) {
    v_93 = Adacrus__T;
  } else {
    v_93 = v_92;
  };
  v_56 = (current_state==Adacrus__Rot180);
  v_55 = (last_oriented==Adacrus__T);
  v_57 = (v_55&&v_56);
  if (v_57) {
    v_94 = Adacrus__B;
  } else {
    v_94 = v_93;
  };
  v_53 = (current_state==Adacrus__RotR);
  v_52 = (last_oriented==Adacrus__T);
  v_54 = (v_52&&v_53);
  if (v_54) {
    v_95 = Adacrus__R;
  } else {
    v_95 = v_94;
  };
  v_50 = (current_state==Adacrus__RotL);
  v = (last_oriented==Adacrus__T);
  v_51 = (v&&v_50);
  if (v_51) {
    _out->new_orientation = Adacrus__L;
  } else {
    _out->new_orientation = v_95;
  };;
}

void Adacrus__getNextNode_step(Adacrus__coordinates current_node,
                               Adacrus__states next_state,
                               Adacrus__orientation oriented,
                               Adacrus__getNextNode_out* _out) {
  
  Adacrus__coordinates v_115;
  Adacrus__coordinates v_114;
  Adacrus__coordinates v_113;
  Adacrus__coordinates v_112;
  int v_111;
  Adacrus__coordinates v_110;
  int v_109;
  Adacrus__coordinates v_108;
  int v_107;
  Adacrus__coordinates v_106;
  int v_105;
  int v_104;
  int v_103;
  int v_102;
  int v_101;
  int v_100;
  int v_99;
  int v_98;
  int v_97;
  int v_96;
  int v;
  int moving_left;
  int moving_right;
  int moving_bottom;
  int same_place;
  v_111 = (current_node.y+1);
  v_109 = (current_node.y-1);
  v_107 = (current_node.x+1);
  v_105 = (current_node.x-1);
  v_104 = (oriented==Adacrus__B);
  v_103 = (next_state==Adacrus__Moving);
  moving_bottom = (v_103&&v_104);
  v_102 = (oriented==Adacrus__R);
  v_101 = (next_state==Adacrus__Moving);
  moving_right = (v_101&&v_102);
  v_100 = (oriented==Adacrus__L);
  v_99 = (next_state==Adacrus__Moving);
  moving_left = (v_99&&v_100);
  v_98 = (next_state==Adacrus__Rot180);
  v_96 = (next_state==Adacrus__RotR);
  v = (next_state==Adacrus__RotL);
  v_97 = (v||v_96);
  same_place = (v_97||v_98);
  v_112 = current_node;
  v_112.y = v_111;
  v_110 = current_node;
  v_110.y = v_109;
  if (moving_bottom) {
    v_113 = v_110;
  } else {
    v_113 = v_112;
  };
  v_108 = current_node;
  v_108.x = v_107;
  if (moving_right) {
    v_114 = v_108;
  } else {
    v_114 = v_113;
  };
  v_106 = current_node;
  v_106.x = v_105;
  if (moving_left) {
    v_115 = v_106;
  } else {
    v_115 = v_114;
  };
  if (same_place) {
    _out->next_node = current_node;
  } else {
    _out->next_node = v_115;
  };;
}

void Adacrus__decideAction_reset(Adacrus__decideAction_mem* self) {
  self->v_117 = true;
}

void Adacrus__decideAction_step(Adacrus__coordinates current_node,
                                Adacrus__states last_state,
                                Adacrus__orientation oriented, int ir_prox,
                                Adacrus__decideAction_out* _out,
                                Adacrus__decideAction_mem* self) {
  Adacrus__getNextNode_out Adacrus__getNextNode_out_st;
  
  Adacrus__states v_132;
  Adacrus__states v_131;
  Adacrus__states v_130;
  Adacrus__states v_129;
  int v_128;
  int v_127;
  int v_126;
  int v_125;
  int v_124;
  int v_123;
  int v_122;
  int v_121;
  int v_120;
  int v_119;
  int v_118;
  int v_116;
  int v;
  int is_goal;
  v_127 = (oriented==Adacrus__R);
  v_126 = (last_state==Adacrus__Moving);
  v_128 = (v_126&&v_127);
  if (v_128) {
    v_129 = Adacrus__RotL;
  } else {
    v_129 = Adacrus__Moving;
  };
  v_124 = (oriented==Adacrus__L);
  v_123 = (last_state==Adacrus__Moving);
  v_125 = (v_123&&v_124);
  if (v_125) {
    v_130 = Adacrus__RotR;
  } else {
    v_130 = v_129;
  };
  v_121 = (last_state==Adacrus__Rot180);
  v_119 = (last_state==Adacrus__RotR);
  v_118 = (last_state==Adacrus__RotL);
  v_120 = (v_118||v_119);
  v_122 = (v_120||v_121);
  if (v_122) {
    v_131 = Adacrus__Moving;
  } else {
    v_131 = v_130;
  };
  v_116 = (current_node.y==Adacrus__goal.y);
  v = (current_node.x==Adacrus__goal.x);
  is_goal = (v&&v_116);
  if (is_goal) {
    v_132 = Adacrus__Exit;
  } else {
    v_132 = v_131;
  };
  if (self->v_117) {
    _out->next_state = Adacrus__RotL;
  } else {
    _out->next_state = v_132;
  };
  Adacrus__getNextNode_step(current_node, _out->next_state, oriented,
                            &Adacrus__getNextNode_out_st);
  _out->next_node = Adacrus__getNextNode_out_st.next_node;
  self->v_117 = false;;
}

void Adacrus__adacrus_params_35__reset(Adacrus__adacrus_params_35__mem* self) {
  Adacrus__move_curve_reset(&self->move_curve);
  Adacrus__decideAction_reset(&self->decideAction);
  self->v_190 = false;
  self->v_189 = false;
  self->v_188 = Adacrus__St_GoAhead;
  self->v_173 = false;
  self->v_172 = false;
  self->v_171 = Adacrus__St_1_GoAhead;
  self->v_156 = false;
  self->v_155 = false;
  self->v_154 = Adacrus__St_2_GoAhead;
  self->debug_state_1 = Adacrus__Initial;
  self->current_state_2 = Adacrus__Initial;
  self->oriented_3 = Adacrus__T;
  self->next_node_3.y = 1;
  self->next_node_3.x = 4;
  self->pnr_3 = false;
  self->v_183 = true;
  self->v_177 = true;
  self->v_166 = true;
  self->v_160 = true;
  self->v_149 = true;
  self->v_143 = true;
  self->v_135 = true;
  self->ck = Adacrus__St_3_Initial;
}

void Adacrus__adacrus_params_35__step(int left_wl, int center_wl,
                                      int right_wl, int ir_prox,
                                      Adacrus__adacrus_params_35__out* _out,
                                      Adacrus__adacrus_params_35__mem* self) {
  Adacrus__halt_out Adacrus__halt_out_st;
  Adacrus__isnode_out Adacrus__isnode_out_st;
  Adacrus__move_out Adacrus__move_out_st;
  Adacrus__move_curve_out Adacrus__move_curve_out_st;
  Adacrus__decideAction_out Adacrus__decideAction_out_st;
  Adacrus__calcOrientation_out Adacrus__calcOrientation_out_st;
  Adacrus__isline_out Adacrus__isline_out_st;
  
  int v_139;
  int v_137;
  int v_136;
  int v_134;
  int v_133;
  int v;
  int t_right_again;
  int v_147;
  int v_145;
  int v_144;
  int v_142;
  int v_141;
  int v_140;
  int t_right_1;
  int v_153;
  int v_151;
  int v_150;
  int v_148;
  int t_forward_2;
  int nr_2_St_2_Exit;
  Adacrus__st_2 ns_2_St_2_Exit;
  int exit_2_St_2_Exit;
  Adacrus__states debug_state_St_3_Rot180_St_2_Exit;
  Adacrus__direction dir_St_3_Rot180_St_2_Exit;
  int v_r_St_3_Rot180_St_2_Exit;
  int v_l_St_3_Rot180_St_2_Exit;
  int nr_2_St_2_TurnRightAgain;
  Adacrus__st_2 ns_2_St_2_TurnRightAgain;
  int exit_2_St_2_TurnRightAgain;
  Adacrus__states debug_state_St_3_Rot180_St_2_TurnRightAgain;
  Adacrus__direction dir_St_3_Rot180_St_2_TurnRightAgain;
  int v_r_St_3_Rot180_St_2_TurnRightAgain;
  int v_l_St_3_Rot180_St_2_TurnRightAgain;
  int nr_2_St_2_TurnRight;
  Adacrus__st_2 ns_2_St_2_TurnRight;
  int exit_2_St_2_TurnRight;
  Adacrus__states debug_state_St_3_Rot180_St_2_TurnRight;
  Adacrus__direction dir_St_3_Rot180_St_2_TurnRight;
  int v_r_St_3_Rot180_St_2_TurnRight;
  int v_l_St_3_Rot180_St_2_TurnRight;
  int nr_2_St_2_GoAhead;
  Adacrus__st_2 ns_2_St_2_GoAhead;
  int exit_2_St_2_GoAhead;
  Adacrus__states debug_state_St_3_Rot180_St_2_GoAhead;
  Adacrus__direction dir_St_3_Rot180_St_2_GoAhead;
  int v_r_St_3_Rot180_St_2_GoAhead;
  int v_l_St_3_Rot180_St_2_GoAhead;
  Adacrus__st_2 ck_3;
  Adacrus__st_2 ns_2;
  int r_2;
  int nr_2;
  int pnr_2;
  int exit_2_1;
  int exit_2;
  int v_164;
  int v_162;
  int v_161;
  int v_159;
  int v_158;
  int v_157;
  int t_right;
  int v_170;
  int v_168;
  int v_167;
  int v_165;
  int t_forward_1;
  int nr_1_St_1_Exit;
  Adacrus__st_1 ns_1_St_1_Exit;
  int exit_1_St_1_Exit;
  Adacrus__states debug_state_St_3_RotR_St_1_Exit;
  Adacrus__direction dir_St_3_RotR_St_1_Exit;
  int v_r_St_3_RotR_St_1_Exit;
  int v_l_St_3_RotR_St_1_Exit;
  int nr_1_St_1_TurnRight;
  Adacrus__st_1 ns_1_St_1_TurnRight;
  int exit_1_St_1_TurnRight;
  Adacrus__states debug_state_St_3_RotR_St_1_TurnRight;
  Adacrus__direction dir_St_3_RotR_St_1_TurnRight;
  int v_r_St_3_RotR_St_1_TurnRight;
  int v_l_St_3_RotR_St_1_TurnRight;
  int nr_1_St_1_GoAhead;
  Adacrus__st_1 ns_1_St_1_GoAhead;
  int exit_1_St_1_GoAhead;
  Adacrus__states debug_state_St_3_RotR_St_1_GoAhead;
  Adacrus__direction dir_St_3_RotR_St_1_GoAhead;
  int v_r_St_3_RotR_St_1_GoAhead;
  int v_l_St_3_RotR_St_1_GoAhead;
  Adacrus__st_1 ck_2;
  Adacrus__st_1 ns_1;
  int r_1;
  int nr_1;
  int pnr_1;
  int exit_1_1;
  int exit_1;
  int v_181;
  int v_179;
  int v_178;
  int v_176;
  int v_175;
  int v_174;
  int t_left;
  int v_187;
  int v_185;
  int v_184;
  int v_182;
  int t_forward;
  int nr_St_Exit;
  Adacrus__st ns_St_Exit;
  int exit_St_Exit;
  Adacrus__states debug_state_St_3_RotL_St_Exit;
  Adacrus__direction dir_St_3_RotL_St_Exit;
  int v_r_St_3_RotL_St_Exit;
  int v_l_St_3_RotL_St_Exit;
  int nr_St_TurnLeft;
  Adacrus__st ns_St_TurnLeft;
  int exit_St_TurnLeft;
  Adacrus__states debug_state_St_3_RotL_St_TurnLeft;
  Adacrus__direction dir_St_3_RotL_St_TurnLeft;
  int v_r_St_3_RotL_St_TurnLeft;
  int v_l_St_3_RotL_St_TurnLeft;
  int nr_St_GoAhead;
  Adacrus__st ns_St_GoAhead;
  int exit_St_GoAhead;
  Adacrus__states debug_state_St_3_RotL_St_GoAhead;
  Adacrus__direction dir_St_3_RotL_St_GoAhead;
  int v_r_St_3_RotL_St_GoAhead;
  int v_l_St_3_RotL_St_GoAhead;
  Adacrus__st ck_1;
  Adacrus__st ns;
  int r;
  int nr;
  int pnr;
  int exit_3;
  int exit;
  int v_203;
  Adacrus__st_3 v_202;
  int v_201;
  Adacrus__st_3 v_200;
  int v_199;
  Adacrus__st_3 v_198;
  int v_197;
  Adacrus__st_3 v_196;
  int v_195;
  int v_194;
  int v_193;
  int v_192;
  int v_191;
  int r_4;
  Adacrus__states next_state;
  int v_211;
  int v_210;
  int v_209;
  int v_208;
  int v_207;
  int v_206;
  int v_205;
  int v_204;
  int r_5;
  int v_213;
  int v_212;
  int nr_3_St_3_Rot180;
  Adacrus__st_3 ns_3_St_3_Rot180;
  Adacrus__states debug_state_St_3_Rot180;
  Adacrus__states current_state_St_3_Rot180;
  Adacrus__orientation oriented_St_3_Rot180;
  Adacrus__coordinates next_node_St_3_Rot180;
  Adacrus__direction dir_St_3_Rot180;
  int v_r_St_3_Rot180;
  int v_l_St_3_Rot180;
  int nr_3_St_3_RotR;
  Adacrus__st_3 ns_3_St_3_RotR;
  Adacrus__states debug_state_St_3_RotR;
  Adacrus__states current_state_St_3_RotR;
  Adacrus__orientation oriented_St_3_RotR;
  Adacrus__coordinates next_node_St_3_RotR;
  Adacrus__direction dir_St_3_RotR;
  int v_r_St_3_RotR;
  int v_l_St_3_RotR;
  int nr_3_St_3_RotL;
  Adacrus__st_3 ns_3_St_3_RotL;
  Adacrus__states debug_state_St_3_RotL;
  Adacrus__states current_state_St_3_RotL;
  Adacrus__orientation oriented_St_3_RotL;
  Adacrus__coordinates next_node_St_3_RotL;
  Adacrus__direction dir_St_3_RotL;
  int v_r_St_3_RotL;
  int v_l_St_3_RotL;
  int nr_3_St_3_DecideAction;
  Adacrus__st_3 ns_3_St_3_DecideAction;
  Adacrus__states debug_state_St_3_DecideAction;
  Adacrus__states current_state_St_3_DecideAction;
  Adacrus__orientation oriented_St_3_DecideAction;
  Adacrus__coordinates next_node_St_3_DecideAction;
  Adacrus__direction dir_St_3_DecideAction;
  int v_r_St_3_DecideAction;
  int v_l_St_3_DecideAction;
  int nr_3_St_3_Exit;
  Adacrus__st_3 ns_3_St_3_Exit;
  Adacrus__states debug_state_St_3_Exit;
  Adacrus__states current_state_St_3_Exit;
  Adacrus__orientation oriented_St_3_Exit;
  Adacrus__coordinates next_node_St_3_Exit;
  Adacrus__direction dir_St_3_Exit;
  int v_r_St_3_Exit;
  int v_l_St_3_Exit;
  int nr_3_St_3_Moving;
  Adacrus__st_3 ns_3_St_3_Moving;
  Adacrus__states debug_state_St_3_Moving;
  Adacrus__states current_state_St_3_Moving;
  Adacrus__orientation oriented_St_3_Moving;
  Adacrus__coordinates next_node_St_3_Moving;
  Adacrus__direction dir_St_3_Moving;
  int v_r_St_3_Moving;
  int v_l_St_3_Moving;
  int nr_3_St_3_Initial;
  Adacrus__st_3 ns_3_St_3_Initial;
  Adacrus__states debug_state_St_3_Initial;
  Adacrus__states current_state_St_3_Initial;
  Adacrus__orientation oriented_St_3_Initial;
  Adacrus__coordinates next_node_St_3_Initial;
  Adacrus__direction dir_St_3_Initial;
  int v_r_St_3_Initial;
  int v_l_St_3_Initial;
  Adacrus__st_3 ns_3;
  int r_3;
  int nr_3;
  Adacrus__coordinates next_node;
  Adacrus__orientation oriented;
  Adacrus__states current_state;
  Adacrus__states debug_state;
  r_3 = self->pnr_3;
  switch (self->ck) {
    case Adacrus__St_3_Initial:
      oriented_St_3_Initial = self->oriented_3;
      current_state_St_3_Initial = Adacrus__Initial;
      dir_St_3_Initial = Adacrus__Forward;
      Adacrus__move_step(left_wl, center_wl, right_wl, &Adacrus__move_out_st);
      v_l_St_3_Initial = Adacrus__move_out_st.v_l;
      v_r_St_3_Initial = Adacrus__move_out_st.v_r;
      Adacrus__isnode_step(left_wl, center_wl, right_wl,
                           &Adacrus__isnode_out_st);
      v_212 = Adacrus__isnode_out_st.out;
      v_213 = !(v_212);
      if (v_213) {
        nr_3_St_3_Initial = true;
        ns_3_St_3_Initial = Adacrus__St_3_Moving;
      } else {
        nr_3_St_3_Initial = false;
        ns_3_St_3_Initial = Adacrus__St_3_Initial;
      };
      oriented = oriented_St_3_Initial;
      current_state = current_state_St_3_Initial;
      debug_state_St_3_Initial = current_state;
      _out->dir = dir_St_3_Initial;
      debug_state = debug_state_St_3_Initial;
      break;
    case Adacrus__St_3_Moving:
      oriented_St_3_Moving = self->oriented_3;
      current_state_St_3_Moving = Adacrus__Moving;
      dir_St_3_Moving = Adacrus__Forward;
      Adacrus__move_step(left_wl, center_wl, right_wl, &Adacrus__move_out_st);
      v_210 = Adacrus__move_out_st.v_l;
      v_211 = Adacrus__move_out_st.v_r;
      Adacrus__isnode_step(left_wl, center_wl, right_wl,
                           &Adacrus__isnode_out_st);
      v_204 = Adacrus__isnode_out_st.out;
      if (v_204) {
        nr_3_St_3_Moving = false;
        ns_3_St_3_Moving = Adacrus__St_3_DecideAction;
      } else {
        nr_3_St_3_Moving = false;
        ns_3_St_3_Moving = Adacrus__St_3_Moving;
      };
      r_5 = r_3;
      if (r_5) {
        Adacrus__move_curve_reset(&self->move_curve);
      };
      Adacrus__move_curve_step(left_wl, center_wl, right_wl,
                               &Adacrus__move_curve_out_st, &self->move_curve);
      v_208 = Adacrus__move_curve_out_st.v_l;
      v_209 = Adacrus__move_curve_out_st.v_r;
      oriented = oriented_St_3_Moving;
      v_205 = (oriented==Adacrus__T);
      current_state = current_state_St_3_Moving;
      debug_state_St_3_Moving = current_state;
      _out->dir = dir_St_3_Moving;
      debug_state = debug_state_St_3_Moving;
      break;
    case Adacrus__St_3_Exit:
      oriented_St_3_Exit = self->oriented_3;
      current_state_St_3_Exit = Adacrus__Exit;
      Adacrus__halt_step(&Adacrus__halt_out_st);
      v_l_St_3_Exit = Adacrus__halt_out_st.v_l;
      v_r_St_3_Exit = Adacrus__halt_out_st.v_r;
      dir_St_3_Exit = Adacrus__halt_out_st.dir;
      if (false) {
        nr_3_St_3_Exit = true;
      } else {
        nr_3_St_3_Exit = false;
      };
      if (false) {
        ns_3_St_3_Exit = Adacrus__St_3_Exit;
      } else {
        ns_3_St_3_Exit = Adacrus__St_3_Exit;
      };
      oriented = oriented_St_3_Exit;
      current_state = current_state_St_3_Exit;
      debug_state_St_3_Exit = current_state;
      _out->dir = dir_St_3_Exit;
      debug_state = debug_state_St_3_Exit;
      break;
    case Adacrus__St_3_DecideAction:
      current_state_St_3_DecideAction = self->current_state_2;
      debug_state_St_3_DecideAction = Adacrus__DecideAction;
      Adacrus__calcOrientation_step(self->current_state_2, self->oriented_3,
                                    &Adacrus__calcOrientation_out_st);
      oriented_St_3_DecideAction = Adacrus__calcOrientation_out_st.new_orientation;
      Adacrus__halt_step(&Adacrus__halt_out_st);
      v_l_St_3_DecideAction = Adacrus__halt_out_st.v_l;
      v_r_St_3_DecideAction = Adacrus__halt_out_st.v_r;
      dir_St_3_DecideAction = Adacrus__halt_out_st.dir;
      r_4 = r_3;
      oriented = oriented_St_3_DecideAction;
      current_state = current_state_St_3_DecideAction;
      _out->dir = dir_St_3_DecideAction;
      debug_state = debug_state_St_3_DecideAction;
      break;
    case Adacrus__St_3_RotL:
      if (r_3) {
        exit_3 = false;
      } else {
        exit_3 = self->v_190;
      };
      oriented_St_3_RotL = self->oriented_3;
      if (r_3) {
        pnr = false;
      } else {
        pnr = self->v_189;
      };
      r = pnr;
      if (r_3) {
        ck_1 = Adacrus__St_GoAhead;
      } else {
        ck_1 = self->v_188;
      };
      current_state_St_3_RotL = Adacrus__RotL;
      oriented = oriented_St_3_RotL;
      current_state = current_state_St_3_RotL;
      switch (ck_1) {
        case Adacrus__St_GoAhead:
          exit_St_GoAhead = exit_3;
          debug_state_St_3_RotL_St_GoAhead = Adacrus__GoAhead;
          v_187 = (self->v_186+1);
          v_184 = (r_3||r);
          if (self->v_183) {
            v_185 = true;
          } else {
            v_185 = v_184;
          };
          if (v_185) {
            t_forward = 0;
          } else {
            t_forward = v_187;
          };
          dir_St_3_RotL_St_GoAhead = Adacrus__Forward;
          v_r_St_3_RotL_St_GoAhead = 200;
          v_l_St_3_RotL_St_GoAhead = 200;
          v_182 = (t_forward>35);
          if (v_182) {
            nr_St_GoAhead = true;
            ns_St_GoAhead = Adacrus__St_TurnLeft;
          } else {
            nr_St_GoAhead = false;
            ns_St_GoAhead = Adacrus__St_GoAhead;
          };
          v_l_St_3_RotL = v_l_St_3_RotL_St_GoAhead;
          v_r_St_3_RotL = v_r_St_3_RotL_St_GoAhead;
          dir_St_3_RotL = dir_St_3_RotL_St_GoAhead;
          debug_state_St_3_RotL = debug_state_St_3_RotL_St_GoAhead;
          exit = exit_St_GoAhead;
          ns = ns_St_GoAhead;
          nr = nr_St_GoAhead;
          break;
        case Adacrus__St_TurnLeft:
          exit_St_TurnLeft = exit_3;
          debug_state_St_3_RotL_St_TurnLeft = Adacrus__TurnLeft;
          v_181 = (self->v_180+1);
          v_178 = (r_3||r);
          if (self->v_177) {
            v_179 = true;
          } else {
            v_179 = v_178;
          };
          if (v_179) {
            t_left = 0;
          } else {
            t_left = v_181;
          };
          dir_St_3_RotL_St_TurnLeft = Adacrus__Left;
          v_r_St_3_RotL_St_TurnLeft = 100;
          v_l_St_3_RotL_St_TurnLeft = 100;
          Adacrus__isline_step(left_wl, center_wl, right_wl,
                               &Adacrus__isline_out_st);
          v_175 = Adacrus__isline_out_st.out;
          v_174 = (t_left>35);
          v_176 = (v_174&&v_175);
          if (v_176) {
            nr_St_TurnLeft = true;
            ns_St_TurnLeft = Adacrus__St_Exit;
          } else {
            nr_St_TurnLeft = false;
            ns_St_TurnLeft = Adacrus__St_TurnLeft;
          };
          v_l_St_3_RotL = v_l_St_3_RotL_St_TurnLeft;
          v_r_St_3_RotL = v_r_St_3_RotL_St_TurnLeft;
          dir_St_3_RotL = dir_St_3_RotL_St_TurnLeft;
          debug_state_St_3_RotL = debug_state_St_3_RotL_St_TurnLeft;
          exit = exit_St_TurnLeft;
          ns = ns_St_TurnLeft;
          nr = nr_St_TurnLeft;
          break;
        case Adacrus__St_Exit:
          debug_state_St_3_RotL_St_Exit = Adacrus__Exit;
          exit_St_Exit = true;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_3_RotL_St_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_3_RotL_St_Exit = Adacrus__halt_out_st.v_r;
          dir_St_3_RotL_St_Exit = Adacrus__halt_out_st.dir;
          nr_St_Exit = false;
          ns_St_Exit = Adacrus__St_Exit;
          v_l_St_3_RotL = v_l_St_3_RotL_St_Exit;
          v_r_St_3_RotL = v_r_St_3_RotL_St_Exit;
          dir_St_3_RotL = dir_St_3_RotL_St_Exit;
          debug_state_St_3_RotL = debug_state_St_3_RotL_St_Exit;
          exit = exit_St_Exit;
          ns = ns_St_Exit;
          nr = nr_St_Exit;
          break;
        default:
          break;
      };
      if (exit) {
        nr_3_St_3_RotL = false;
        ns_3_St_3_RotL = Adacrus__St_3_DecideAction;
      } else {
        nr_3_St_3_RotL = false;
        ns_3_St_3_RotL = Adacrus__St_3_RotL;
      };
      _out->dir = dir_St_3_RotL;
      debug_state = debug_state_St_3_RotL;
      break;
    case Adacrus__St_3_RotR:
      if (r_3) {
        exit_1_1 = false;
      } else {
        exit_1_1 = self->v_173;
      };
      oriented_St_3_RotR = self->oriented_3;
      if (r_3) {
        pnr_1 = false;
      } else {
        pnr_1 = self->v_172;
      };
      r_1 = pnr_1;
      if (r_3) {
        ck_2 = Adacrus__St_1_GoAhead;
      } else {
        ck_2 = self->v_171;
      };
      current_state_St_3_RotR = Adacrus__RotR;
      oriented = oriented_St_3_RotR;
      current_state = current_state_St_3_RotR;
      switch (ck_2) {
        case Adacrus__St_1_GoAhead:
          exit_1_St_1_GoAhead = exit_1_1;
          debug_state_St_3_RotR_St_1_GoAhead = Adacrus__GoAhead;
          v_170 = (self->v_169+1);
          v_167 = (r_3||r_1);
          if (self->v_166) {
            v_168 = true;
          } else {
            v_168 = v_167;
          };
          if (v_168) {
            t_forward_1 = 0;
          } else {
            t_forward_1 = v_170;
          };
          dir_St_3_RotR_St_1_GoAhead = Adacrus__Forward;
          v_r_St_3_RotR_St_1_GoAhead = 200;
          v_l_St_3_RotR_St_1_GoAhead = 200;
          v_165 = (t_forward_1>35);
          if (v_165) {
            nr_1_St_1_GoAhead = true;
            ns_1_St_1_GoAhead = Adacrus__St_1_TurnRight;
          } else {
            nr_1_St_1_GoAhead = false;
            ns_1_St_1_GoAhead = Adacrus__St_1_GoAhead;
          };
          v_l_St_3_RotR = v_l_St_3_RotR_St_1_GoAhead;
          v_r_St_3_RotR = v_r_St_3_RotR_St_1_GoAhead;
          dir_St_3_RotR = dir_St_3_RotR_St_1_GoAhead;
          debug_state_St_3_RotR = debug_state_St_3_RotR_St_1_GoAhead;
          exit_1 = exit_1_St_1_GoAhead;
          ns_1 = ns_1_St_1_GoAhead;
          nr_1 = nr_1_St_1_GoAhead;
          break;
        case Adacrus__St_1_TurnRight:
          exit_1_St_1_TurnRight = exit_1_1;
          debug_state_St_3_RotR_St_1_TurnRight = Adacrus__TurnRight;
          v_164 = (self->v_163+1);
          v_161 = (r_3||r_1);
          if (self->v_160) {
            v_162 = true;
          } else {
            v_162 = v_161;
          };
          if (v_162) {
            t_right = 0;
          } else {
            t_right = v_164;
          };
          dir_St_3_RotR_St_1_TurnRight = Adacrus__Right;
          v_r_St_3_RotR_St_1_TurnRight = 100;
          v_l_St_3_RotR_St_1_TurnRight = 100;
          Adacrus__isline_step(left_wl, center_wl, right_wl,
                               &Adacrus__isline_out_st);
          v_158 = Adacrus__isline_out_st.out;
          v_157 = (t_right>35);
          v_159 = (v_157&&v_158);
          if (v_159) {
            nr_1_St_1_TurnRight = true;
            ns_1_St_1_TurnRight = Adacrus__St_1_Exit;
          } else {
            nr_1_St_1_TurnRight = false;
            ns_1_St_1_TurnRight = Adacrus__St_1_TurnRight;
          };
          v_l_St_3_RotR = v_l_St_3_RotR_St_1_TurnRight;
          v_r_St_3_RotR = v_r_St_3_RotR_St_1_TurnRight;
          dir_St_3_RotR = dir_St_3_RotR_St_1_TurnRight;
          debug_state_St_3_RotR = debug_state_St_3_RotR_St_1_TurnRight;
          exit_1 = exit_1_St_1_TurnRight;
          ns_1 = ns_1_St_1_TurnRight;
          nr_1 = nr_1_St_1_TurnRight;
          break;
        case Adacrus__St_1_Exit:
          debug_state_St_3_RotR_St_1_Exit = Adacrus__Exit;
          exit_1_St_1_Exit = true;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_3_RotR_St_1_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_3_RotR_St_1_Exit = Adacrus__halt_out_st.v_r;
          dir_St_3_RotR_St_1_Exit = Adacrus__halt_out_st.dir;
          nr_1_St_1_Exit = false;
          ns_1_St_1_Exit = Adacrus__St_1_Exit;
          v_l_St_3_RotR = v_l_St_3_RotR_St_1_Exit;
          v_r_St_3_RotR = v_r_St_3_RotR_St_1_Exit;
          dir_St_3_RotR = dir_St_3_RotR_St_1_Exit;
          debug_state_St_3_RotR = debug_state_St_3_RotR_St_1_Exit;
          exit_1 = exit_1_St_1_Exit;
          ns_1 = ns_1_St_1_Exit;
          nr_1 = nr_1_St_1_Exit;
          break;
        default:
          break;
      };
      if (exit_1) {
        nr_3_St_3_RotR = false;
        ns_3_St_3_RotR = Adacrus__St_3_DecideAction;
      } else {
        nr_3_St_3_RotR = false;
        ns_3_St_3_RotR = Adacrus__St_3_RotR;
      };
      _out->dir = dir_St_3_RotR;
      debug_state = debug_state_St_3_RotR;
      break;
    case Adacrus__St_3_Rot180:
      if (r_3) {
        exit_2_1 = false;
      } else {
        exit_2_1 = self->v_156;
      };
      oriented_St_3_Rot180 = self->oriented_3;
      if (r_3) {
        pnr_2 = false;
      } else {
        pnr_2 = self->v_155;
      };
      r_2 = pnr_2;
      if (r_3) {
        ck_3 = Adacrus__St_2_GoAhead;
      } else {
        ck_3 = self->v_154;
      };
      current_state_St_3_Rot180 = Adacrus__Rot180;
      oriented = oriented_St_3_Rot180;
      current_state = current_state_St_3_Rot180;
      switch (ck_3) {
        case Adacrus__St_2_GoAhead:
          exit_2_St_2_GoAhead = exit_2_1;
          debug_state_St_3_Rot180_St_2_GoAhead = Adacrus__GoAhead;
          v_153 = (self->v_152+1);
          v_150 = (r_3||r_2);
          if (self->v_149) {
            v_151 = true;
          } else {
            v_151 = v_150;
          };
          if (v_151) {
            t_forward_2 = 0;
          } else {
            t_forward_2 = v_153;
          };
          dir_St_3_Rot180_St_2_GoAhead = Adacrus__Forward;
          v_r_St_3_Rot180_St_2_GoAhead = 200;
          v_l_St_3_Rot180_St_2_GoAhead = 200;
          v_148 = (t_forward_2>35);
          if (v_148) {
            nr_2_St_2_GoAhead = true;
            ns_2_St_2_GoAhead = Adacrus__St_2_TurnRight;
          } else {
            nr_2_St_2_GoAhead = false;
            ns_2_St_2_GoAhead = Adacrus__St_2_GoAhead;
          };
          v_l_St_3_Rot180 = v_l_St_3_Rot180_St_2_GoAhead;
          v_r_St_3_Rot180 = v_r_St_3_Rot180_St_2_GoAhead;
          dir_St_3_Rot180 = dir_St_3_Rot180_St_2_GoAhead;
          debug_state_St_3_Rot180 = debug_state_St_3_Rot180_St_2_GoAhead;
          exit_2 = exit_2_St_2_GoAhead;
          ns_2 = ns_2_St_2_GoAhead;
          nr_2 = nr_2_St_2_GoAhead;
          break;
        case Adacrus__St_2_TurnRight:
          exit_2_St_2_TurnRight = exit_2_1;
          debug_state_St_3_Rot180_St_2_TurnRight = Adacrus__TurnRight;
          v_147 = (self->v_146+1);
          v_144 = (r_3||r_2);
          if (self->v_143) {
            v_145 = true;
          } else {
            v_145 = v_144;
          };
          if (v_145) {
            t_right_1 = 0;
          } else {
            t_right_1 = v_147;
          };
          dir_St_3_Rot180_St_2_TurnRight = Adacrus__Right;
          v_r_St_3_Rot180_St_2_TurnRight = 100;
          v_l_St_3_Rot180_St_2_TurnRight = 100;
          Adacrus__isline_step(left_wl, center_wl, right_wl,
                               &Adacrus__isline_out_st);
          v_141 = Adacrus__isline_out_st.out;
          v_140 = (t_right_1>35);
          v_142 = (v_140&&v_141);
          if (v_142) {
            nr_2_St_2_TurnRight = true;
            ns_2_St_2_TurnRight = Adacrus__St_2_TurnRightAgain;
          } else {
            nr_2_St_2_TurnRight = false;
            ns_2_St_2_TurnRight = Adacrus__St_2_TurnRight;
          };
          v_l_St_3_Rot180 = v_l_St_3_Rot180_St_2_TurnRight;
          v_r_St_3_Rot180 = v_r_St_3_Rot180_St_2_TurnRight;
          dir_St_3_Rot180 = dir_St_3_Rot180_St_2_TurnRight;
          debug_state_St_3_Rot180 = debug_state_St_3_Rot180_St_2_TurnRight;
          exit_2 = exit_2_St_2_TurnRight;
          ns_2 = ns_2_St_2_TurnRight;
          nr_2 = nr_2_St_2_TurnRight;
          break;
        case Adacrus__St_2_TurnRightAgain:
          exit_2_St_2_TurnRightAgain = exit_2_1;
          debug_state_St_3_Rot180_St_2_TurnRightAgain = Adacrus__TurnRight;
          v_139 = (self->v_138+1);
          v_136 = (r_3||r_2);
          if (self->v_135) {
            v_137 = true;
          } else {
            v_137 = v_136;
          };
          if (v_137) {
            t_right_again = 0;
          } else {
            t_right_again = v_139;
          };
          dir_St_3_Rot180_St_2_TurnRightAgain = Adacrus__Right;
          v_r_St_3_Rot180_St_2_TurnRightAgain = 100;
          v_l_St_3_Rot180_St_2_TurnRightAgain = 100;
          Adacrus__isline_step(left_wl, center_wl, right_wl,
                               &Adacrus__isline_out_st);
          v_133 = Adacrus__isline_out_st.out;
          v = (t_right_again>35);
          v_134 = (v&&v_133);
          if (v_134) {
            nr_2_St_2_TurnRightAgain = true;
            ns_2_St_2_TurnRightAgain = Adacrus__St_2_Exit;
          } else {
            nr_2_St_2_TurnRightAgain = false;
            ns_2_St_2_TurnRightAgain = Adacrus__St_2_TurnRightAgain;
          };
          v_l_St_3_Rot180 = v_l_St_3_Rot180_St_2_TurnRightAgain;
          v_r_St_3_Rot180 = v_r_St_3_Rot180_St_2_TurnRightAgain;
          dir_St_3_Rot180 = dir_St_3_Rot180_St_2_TurnRightAgain;
          debug_state_St_3_Rot180 = debug_state_St_3_Rot180_St_2_TurnRightAgain;
          exit_2 = exit_2_St_2_TurnRightAgain;
          ns_2 = ns_2_St_2_TurnRightAgain;
          nr_2 = nr_2_St_2_TurnRightAgain;
          break;
        case Adacrus__St_2_Exit:
          exit_2_St_2_Exit = true;
          debug_state_St_3_Rot180_St_2_Exit = Adacrus__Exit;
          Adacrus__halt_step(&Adacrus__halt_out_st);
          v_l_St_3_Rot180_St_2_Exit = Adacrus__halt_out_st.v_l;
          v_r_St_3_Rot180_St_2_Exit = Adacrus__halt_out_st.v_r;
          dir_St_3_Rot180_St_2_Exit = Adacrus__halt_out_st.dir;
          nr_2_St_2_Exit = false;
          ns_2_St_2_Exit = Adacrus__St_2_Exit;
          v_l_St_3_Rot180 = v_l_St_3_Rot180_St_2_Exit;
          v_r_St_3_Rot180 = v_r_St_3_Rot180_St_2_Exit;
          dir_St_3_Rot180 = dir_St_3_Rot180_St_2_Exit;
          debug_state_St_3_Rot180 = debug_state_St_3_Rot180_St_2_Exit;
          exit_2 = exit_2_St_2_Exit;
          ns_2 = ns_2_St_2_Exit;
          nr_2 = nr_2_St_2_Exit;
          break;
        default:
          break;
      };
      if (exit_2) {
        nr_3_St_3_Rot180 = false;
        ns_3_St_3_Rot180 = Adacrus__St_3_DecideAction;
      } else {
        nr_3_St_3_Rot180 = false;
        ns_3_St_3_Rot180 = Adacrus__St_3_Rot180;
      };
      _out->dir = dir_St_3_Rot180;
      debug_state = debug_state_St_3_Rot180;
      break;
    default:
      break;
  };
  _out->o = oriented;
  _out->d_s = debug_state;
  _out->s = current_state;
  switch (self->ck) {
    case Adacrus__St_3_Initial:
      next_node_St_3_Initial = self->next_node_3;
      ns_3 = ns_3_St_3_Initial;
      nr_3 = nr_3_St_3_Initial;
      next_node = next_node_St_3_Initial;
      _out->v_l = v_l_St_3_Initial;
      _out->v_r = v_r_St_3_Initial;
      break;
    case Adacrus__St_3_Moving:
      next_node_St_3_Moving = self->next_node_3;
      ns_3 = ns_3_St_3_Moving;
      nr_3 = nr_3_St_3_Moving;
      next_node = next_node_St_3_Moving;
      v_206 = (next_node.y==2);
      v_207 = (v_205&&v_206);
      if (v_207) {
        v_r_St_3_Moving = v_209;
        v_l_St_3_Moving = v_208;
      } else {
        v_r_St_3_Moving = v_211;
        v_l_St_3_Moving = v_210;
      };
      _out->v_l = v_l_St_3_Moving;
      _out->v_r = v_r_St_3_Moving;
      break;
    case Adacrus__St_3_Exit:
      next_node_St_3_Exit = self->next_node_3;
      ns_3 = ns_3_St_3_Exit;
      nr_3 = nr_3_St_3_Exit;
      next_node = next_node_St_3_Exit;
      _out->v_l = v_l_St_3_Exit;
      _out->v_r = v_r_St_3_Exit;
      break;
    case Adacrus__St_3_DecideAction:
      if (r_4) {
        Adacrus__decideAction_reset(&self->decideAction);
      };
      Adacrus__decideAction_step(self->next_node_3, self->current_state_2,
                                 oriented, ir_prox,
                                 &Adacrus__decideAction_out_st,
                                 &self->decideAction);
      next_node_St_3_DecideAction = Adacrus__decideAction_out_st.next_node;
      next_state = Adacrus__decideAction_out_st.next_state;
      v_195 = (next_state==Adacrus__Exit);
      if (v_195) {
        v_197 = true;
        v_196 = Adacrus__St_3_Exit;
      } else {
        v_197 = false;
        v_196 = Adacrus__St_3_DecideAction;
      };
      v_194 = (next_state==Adacrus__Moving);
      if (v_194) {
        v_199 = true;
        v_198 = Adacrus__St_3_Moving;
      } else {
        v_199 = v_197;
        v_198 = v_196;
      };
      v_193 = (next_state==Adacrus__Rot180);
      if (v_193) {
        v_201 = true;
        v_200 = Adacrus__St_3_Rot180;
      } else {
        v_201 = v_199;
        v_200 = v_198;
      };
      v_192 = (next_state==Adacrus__RotR);
      if (v_192) {
        v_203 = true;
        v_202 = Adacrus__St_3_RotR;
      } else {
        v_203 = v_201;
        v_202 = v_200;
      };
      v_191 = (next_state==Adacrus__RotL);
      if (v_191) {
        nr_3_St_3_DecideAction = true;
        ns_3_St_3_DecideAction = Adacrus__St_3_RotL;
      } else {
        nr_3_St_3_DecideAction = v_203;
        ns_3_St_3_DecideAction = v_202;
      };
      ns_3 = ns_3_St_3_DecideAction;
      nr_3 = nr_3_St_3_DecideAction;
      next_node = next_node_St_3_DecideAction;
      _out->v_l = v_l_St_3_DecideAction;
      _out->v_r = v_r_St_3_DecideAction;
      break;
    case Adacrus__St_3_Rot180:
      ns_3 = ns_3_St_3_Rot180;
      nr_3 = nr_3_St_3_Rot180;
      next_node_St_3_Rot180 = self->next_node_3;
      next_node = next_node_St_3_Rot180;
      _out->v_l = v_l_St_3_Rot180;
      _out->v_r = v_r_St_3_Rot180;
      self->v_156 = exit_2;
      self->v_155 = nr_2;
      self->v_154 = ns_2;
      break;
    case Adacrus__St_3_RotR:
      ns_3 = ns_3_St_3_RotR;
      nr_3 = nr_3_St_3_RotR;
      next_node_St_3_RotR = self->next_node_3;
      next_node = next_node_St_3_RotR;
      _out->v_l = v_l_St_3_RotR;
      _out->v_r = v_r_St_3_RotR;
      self->v_173 = exit_1;
      self->v_172 = nr_1;
      self->v_171 = ns_1;
      break;
    case Adacrus__St_3_RotL:
      ns_3 = ns_3_St_3_RotL;
      nr_3 = nr_3_St_3_RotL;
      next_node_St_3_RotL = self->next_node_3;
      next_node = next_node_St_3_RotL;
      _out->v_l = v_l_St_3_RotL;
      _out->v_r = v_r_St_3_RotL;
      self->v_190 = exit;
      self->v_189 = nr;
      self->v_188 = ns;
      break;
    default:
      break;
  };
  self->debug_state_1 = debug_state;
  self->current_state_2 = current_state;
  self->oriented_3 = oriented;
  self->next_node_3 = next_node;
  self->pnr_3 = nr_3;
  switch (self->ck) {
    case Adacrus__St_3_RotL:
      switch (ck_1) {
        case Adacrus__St_GoAhead:
          self->v_186 = t_forward;
          self->v_183 = false;
          break;
        case Adacrus__St_TurnLeft:
          self->v_180 = t_left;
          self->v_177 = false;
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_3_RotR:
      switch (ck_2) {
        case Adacrus__St_1_GoAhead:
          self->v_169 = t_forward_1;
          self->v_166 = false;
          break;
        case Adacrus__St_1_TurnRight:
          self->v_163 = t_right;
          self->v_160 = false;
          break;
        default:
          break;
      };
      break;
    case Adacrus__St_3_Rot180:
      switch (ck_3) {
        case Adacrus__St_2_GoAhead:
          self->v_152 = t_forward_2;
          self->v_149 = false;
          break;
        case Adacrus__St_2_TurnRight:
          self->v_146 = t_right_1;
          self->v_143 = false;
          break;
        case Adacrus__St_2_TurnRightAgain:
          self->v_138 = t_right_again;
          self->v_135 = false;
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };
  self->ck = ns_3;;
}

void Adacrus__main_reset(Adacrus__main_mem* self) {
  Adacrus__adacrus_params_35__reset(&self->adacrus);
}

void Adacrus__main_step(int left_wl, int center_wl, int right_wl,
                        int ir_prox, Adacrus__main_out* _out,
                        Adacrus__main_mem* self) {
  Adacrus__adacrus_params_35__out Adacrus__adacrus_params_35__out_st;
  Adacrus__adacrus_params_35__step(left_wl, center_wl, right_wl, ir_prox,
                                   &Adacrus__adacrus_params_35__out_st,
                                   &self->adacrus);
  _out->v_l = Adacrus__adacrus_params_35__out_st.v_l;
  _out->v_r = Adacrus__adacrus_params_35__out_st.v_r;
  _out->o = Adacrus__adacrus_params_35__out_st.o;
  _out->dir = Adacrus__adacrus_params_35__out_st.dir;
  _out->s = Adacrus__adacrus_params_35__out_st.s;
  _out->d_s = Adacrus__adacrus_params_35__out_st.d_s;
}

