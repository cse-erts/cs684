/* --- Generated the 11/3/2021 at 15:41 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sun. feb. 7 23:0:23 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "adacrus_types.h"

Adacrus__st_3 Adacrus__st_3_of_string(char* s) {
  if ((strcmp(s, "St_3_RotR")==0)) {
    return Adacrus__St_3_RotR;
  };
  if ((strcmp(s, "St_3_RotL")==0)) {
    return Adacrus__St_3_RotL;
  };
  if ((strcmp(s, "St_3_Rot180")==0)) {
    return Adacrus__St_3_Rot180;
  };
  if ((strcmp(s, "St_3_Moving")==0)) {
    return Adacrus__St_3_Moving;
  };
  if ((strcmp(s, "St_3_Initial")==0)) {
    return Adacrus__St_3_Initial;
  };
  if ((strcmp(s, "St_3_Exit")==0)) {
    return Adacrus__St_3_Exit;
  };
  if ((strcmp(s, "St_3_DecideAction")==0)) {
    return Adacrus__St_3_DecideAction;
  };
}

char* string_of_Adacrus__st_3(Adacrus__st_3 x, char* buf) {
  switch (x) {
    case Adacrus__St_3_RotR:
      strcpy(buf, "St_3_RotR");
      break;
    case Adacrus__St_3_RotL:
      strcpy(buf, "St_3_RotL");
      break;
    case Adacrus__St_3_Rot180:
      strcpy(buf, "St_3_Rot180");
      break;
    case Adacrus__St_3_Moving:
      strcpy(buf, "St_3_Moving");
      break;
    case Adacrus__St_3_Initial:
      strcpy(buf, "St_3_Initial");
      break;
    case Adacrus__St_3_Exit:
      strcpy(buf, "St_3_Exit");
      break;
    case Adacrus__St_3_DecideAction:
      strcpy(buf, "St_3_DecideAction");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_2 Adacrus__st_2_of_string(char* s) {
  if ((strcmp(s, "St_2_TurnRightAgain")==0)) {
    return Adacrus__St_2_TurnRightAgain;
  };
  if ((strcmp(s, "St_2_TurnRight")==0)) {
    return Adacrus__St_2_TurnRight;
  };
  if ((strcmp(s, "St_2_GoAhead")==0)) {
    return Adacrus__St_2_GoAhead;
  };
  if ((strcmp(s, "St_2_Exit")==0)) {
    return Adacrus__St_2_Exit;
  };
}

char* string_of_Adacrus__st_2(Adacrus__st_2 x, char* buf) {
  switch (x) {
    case Adacrus__St_2_TurnRightAgain:
      strcpy(buf, "St_2_TurnRightAgain");
      break;
    case Adacrus__St_2_TurnRight:
      strcpy(buf, "St_2_TurnRight");
      break;
    case Adacrus__St_2_GoAhead:
      strcpy(buf, "St_2_GoAhead");
      break;
    case Adacrus__St_2_Exit:
      strcpy(buf, "St_2_Exit");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st_1 Adacrus__st_1_of_string(char* s) {
  if ((strcmp(s, "St_1_TurnRight")==0)) {
    return Adacrus__St_1_TurnRight;
  };
  if ((strcmp(s, "St_1_GoAhead")==0)) {
    return Adacrus__St_1_GoAhead;
  };
  if ((strcmp(s, "St_1_Exit")==0)) {
    return Adacrus__St_1_Exit;
  };
}

char* string_of_Adacrus__st_1(Adacrus__st_1 x, char* buf) {
  switch (x) {
    case Adacrus__St_1_TurnRight:
      strcpy(buf, "St_1_TurnRight");
      break;
    case Adacrus__St_1_GoAhead:
      strcpy(buf, "St_1_GoAhead");
      break;
    case Adacrus__St_1_Exit:
      strcpy(buf, "St_1_Exit");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__st Adacrus__st_of_string(char* s) {
  if ((strcmp(s, "St_TurnLeft")==0)) {
    return Adacrus__St_TurnLeft;
  };
  if ((strcmp(s, "St_GoAhead")==0)) {
    return Adacrus__St_GoAhead;
  };
  if ((strcmp(s, "St_Exit")==0)) {
    return Adacrus__St_Exit;
  };
}

char* string_of_Adacrus__st(Adacrus__st x, char* buf) {
  switch (x) {
    case Adacrus__St_TurnLeft:
      strcpy(buf, "St_TurnLeft");
      break;
    case Adacrus__St_GoAhead:
      strcpy(buf, "St_GoAhead");
      break;
    case Adacrus__St_Exit:
      strcpy(buf, "St_Exit");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__states Adacrus__states_of_string(char* s) {
  if ((strcmp(s, "Initial")==0)) {
    return Adacrus__Initial;
  };
  if ((strcmp(s, "Moving")==0)) {
    return Adacrus__Moving;
  };
  if ((strcmp(s, "RotL")==0)) {
    return Adacrus__RotL;
  };
  if ((strcmp(s, "RotR")==0)) {
    return Adacrus__RotR;
  };
  if ((strcmp(s, "Rot180")==0)) {
    return Adacrus__Rot180;
  };
  if ((strcmp(s, "AtNode")==0)) {
    return Adacrus__AtNode;
  };
  if ((strcmp(s, "Exit")==0)) {
    return Adacrus__Exit;
  };
  if ((strcmp(s, "GoAhead")==0)) {
    return Adacrus__GoAhead;
  };
  if ((strcmp(s, "TurnRight")==0)) {
    return Adacrus__TurnRight;
  };
  if ((strcmp(s, "TurnLeft")==0)) {
    return Adacrus__TurnLeft;
  };
  if ((strcmp(s, "DecideAction")==0)) {
    return Adacrus__DecideAction;
  };
}

char* string_of_Adacrus__states(Adacrus__states x, char* buf) {
  switch (x) {
    case Adacrus__Initial:
      strcpy(buf, "Initial");
      break;
    case Adacrus__Moving:
      strcpy(buf, "Moving");
      break;
    case Adacrus__RotL:
      strcpy(buf, "RotL");
      break;
    case Adacrus__RotR:
      strcpy(buf, "RotR");
      break;
    case Adacrus__Rot180:
      strcpy(buf, "Rot180");
      break;
    case Adacrus__AtNode:
      strcpy(buf, "AtNode");
      break;
    case Adacrus__Exit:
      strcpy(buf, "Exit");
      break;
    case Adacrus__GoAhead:
      strcpy(buf, "GoAhead");
      break;
    case Adacrus__TurnRight:
      strcpy(buf, "TurnRight");
      break;
    case Adacrus__TurnLeft:
      strcpy(buf, "TurnLeft");
      break;
    case Adacrus__DecideAction:
      strcpy(buf, "DecideAction");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__direction Adacrus__direction_of_string(char* s) {
  if ((strcmp(s, "Forward")==0)) {
    return Adacrus__Forward;
  };
  if ((strcmp(s, "Left")==0)) {
    return Adacrus__Left;
  };
  if ((strcmp(s, "Right")==0)) {
    return Adacrus__Right;
  };
  if ((strcmp(s, "Stop")==0)) {
    return Adacrus__Stop;
  };
}

char* string_of_Adacrus__direction(Adacrus__direction x, char* buf) {
  switch (x) {
    case Adacrus__Forward:
      strcpy(buf, "Forward");
      break;
    case Adacrus__Left:
      strcpy(buf, "Left");
      break;
    case Adacrus__Right:
      strcpy(buf, "Right");
      break;
    case Adacrus__Stop:
      strcpy(buf, "Stop");
      break;
    default:
      break;
  };
  return buf;
}

Adacrus__orientation Adacrus__orientation_of_string(char* s) {
  if ((strcmp(s, "T")==0)) {
    return Adacrus__T;
  };
  if ((strcmp(s, "B")==0)) {
    return Adacrus__B;
  };
  if ((strcmp(s, "L")==0)) {
    return Adacrus__L;
  };
  if ((strcmp(s, "R")==0)) {
    return Adacrus__R;
  };
}

char* string_of_Adacrus__orientation(Adacrus__orientation x, char* buf) {
  switch (x) {
    case Adacrus__T:
      strcpy(buf, "T");
      break;
    case Adacrus__B:
      strcpy(buf, "B");
      break;
    case Adacrus__L:
      strcpy(buf, "L");
      break;
    case Adacrus__R:
      strcpy(buf, "R");
      break;
    default:
      break;
  };
  return buf;
}

