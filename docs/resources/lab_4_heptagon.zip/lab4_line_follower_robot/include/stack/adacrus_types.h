/* --- Generated the 11/3/2021 at 15:41 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sun. feb. 7 23:0:23 CET 2021) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts adacrus.ept --- */

#ifndef ADACRUS_TYPES_H
#define ADACRUS_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Adacrus__St_3_RotR,
  Adacrus__St_3_RotL,
  Adacrus__St_3_Rot180,
  Adacrus__St_3_Moving,
  Adacrus__St_3_Initial,
  Adacrus__St_3_Exit,
  Adacrus__St_3_DecideAction
} Adacrus__st_3;

Adacrus__st_3 Adacrus__st_3_of_string(char* s);

char* string_of_Adacrus__st_3(Adacrus__st_3 x, char* buf);

typedef enum {
  Adacrus__St_2_TurnRightAgain,
  Adacrus__St_2_TurnRight,
  Adacrus__St_2_GoAhead,
  Adacrus__St_2_Exit
} Adacrus__st_2;

Adacrus__st_2 Adacrus__st_2_of_string(char* s);

char* string_of_Adacrus__st_2(Adacrus__st_2 x, char* buf);

typedef enum {
  Adacrus__St_1_TurnRight,
  Adacrus__St_1_GoAhead,
  Adacrus__St_1_Exit
} Adacrus__st_1;

Adacrus__st_1 Adacrus__st_1_of_string(char* s);

char* string_of_Adacrus__st_1(Adacrus__st_1 x, char* buf);

typedef enum {
  Adacrus__St_TurnLeft,
  Adacrus__St_GoAhead,
  Adacrus__St_Exit
} Adacrus__st;

Adacrus__st Adacrus__st_of_string(char* s);

char* string_of_Adacrus__st(Adacrus__st x, char* buf);

typedef enum {
  Adacrus__Initial,
  Adacrus__Moving,
  Adacrus__RotL,
  Adacrus__RotR,
  Adacrus__Rot180,
  Adacrus__AtNode,
  Adacrus__Exit,
  Adacrus__GoAhead,
  Adacrus__TurnRight,
  Adacrus__TurnLeft,
  Adacrus__DecideAction
} Adacrus__states;

Adacrus__states Adacrus__states_of_string(char* s);

char* string_of_Adacrus__states(Adacrus__states x, char* buf);

typedef enum {
  Adacrus__Forward,
  Adacrus__Left,
  Adacrus__Right,
  Adacrus__Stop
} Adacrus__direction;

Adacrus__direction Adacrus__direction_of_string(char* s);

char* string_of_Adacrus__direction(Adacrus__direction x, char* buf);

typedef enum {
  Adacrus__T,
  Adacrus__B,
  Adacrus__L,
  Adacrus__R
} Adacrus__orientation;

Adacrus__orientation Adacrus__orientation_of_string(char* s);

char* string_of_Adacrus__orientation(Adacrus__orientation x, char* buf);

typedef struct Adacrus__coordinates {
  int x;
  int y;
} Adacrus__coordinates;

static const Adacrus__coordinates Adacrus__start = {4, 1};

static const Adacrus__coordinates Adacrus__goal = {4, 6};

#endif // ADACRUS_TYPES_H
