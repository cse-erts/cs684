//
// Created by kirito on 07/03/21.
//

#include <utility>
#include <iostream>

using namespace std;

int main() {
    pair<int, int> a(1, 1);
    pair<int, int> b(1, 1);
    pair<int, int> c(-1, -1);
    cout<<(a==b)<<endl;
    cout<<(a==c);
}
