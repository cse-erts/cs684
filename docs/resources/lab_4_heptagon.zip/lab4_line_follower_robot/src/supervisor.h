//
// Created by kirito on 08/03/21.
//

#ifndef LAB4_LINE_FOLLOWER_ROBOT_SUPERVISOR_H
#define LAB4_LINE_FOLLOWER_ROBOT_SUPERVISOR_H

#endif //LAB4_LINE_FOLLOWER_ROBOT_SUPERVISOR_H
void traverse_line_to_goal();
