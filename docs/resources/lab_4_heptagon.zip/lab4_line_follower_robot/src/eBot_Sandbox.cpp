/*
 * eBot_Sandbox.cpp
 *
 *  Created on: 11-Jan-2021
 *      Author: TAs of CS 684 Spring 2020
 */


#include <utility>
#include "eBot_Sandbox.h"
using namespace std;

// To store 8-bit data of left, center and right white line sensors
unsigned char left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data;

// To store 8-bit data of 5th IR proximity sensors
// unsigned char ir_prox_5_sensor_data;

// To store the direction in which eBot is currently facing
char dir_flag = 'n';



/*
*
* Function Name: forward_wls
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward by the number of nodes specified
* Example Call: forward_wls(2); //Goes forward by two nodes
*
*/
void forward_wls(unsigned char node)
{
    unsigned char node_reached = 0;

    for (int i = 0; i < node; i++) {
        forward();
        _delay_ms(300);

        while (true) {
            // get the ADC converted data of three white line sensors from their appropriate channel numbers
            left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
            center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
            right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );
            // printf("\n %d 	%d 	%d", left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data);

            if (center_wl_sensor_data > 200 && ( left_wl_sensor_data > 200 || right_wl_sensor_data > 200)) {
                stop();
                printf("Forward WLS Node reached: %d\n", ++node_reached);
                break;
            }
            else if (center_wl_sensor_data > 200) {
                velocity(200, 200);
                // printf("\n forward");
            }
            else if (left_wl_sensor_data > 200) {
                velocity(50, 200);
                // printf("\n left");
            }
            else if (right_wl_sensor_data > 200)
            {
                velocity(200, 50);
                // printf("\n right");
            }
            else
            {
                velocity(200, 200);
                // break;
            }
            _delay_ms(10);
        }
    }
}

/*
*
* Function Name: left_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn left until black line is encountered
* Example Call: left_turn_wls();
*
*/
void left_turn_wls()
{
    forward();
    _delay_ms(300);

    while (true)
    {
        // get the ADC converted data of center white line sensors from their appropriate channel number
        center_wl_sensor_data = convert_analog_channel_data( center_wl_sensor_channel );
        if(center_wl_sensor_data < 200)
        {
            left();
            velocity(100, 100);
        }
        else
            break;
        _delay_ms(5);
    }
    // printf("\n\texit value %d \n", convert_analog_channel_data(center_wl_sensor_channel));
    stop();
}


/*
*
* Function Name: right_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn right until black line is encountered
* Example Call: right_turn_wls();
*
*/
void right_turn_wls()
{
    forward();
    _delay_ms(300);

    while (true)
    {
        // get the ADC converted data of center white line sensors from their appropriate channel number
        center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
        if(center_wl_sensor_data < 200)
        {
            right();
            velocity(100, 100);
        }
        else
            break;
        _delay_ms(5);
    }
    //	printf("\n\texit value %d \n", convert_analog_channel_data(center_wl_sensor_channel));
    stop();
}

void forward_wls_till_white() {
    forward();
    _delay_ms(300);
    //printf("entering into wls loop \n");

    while (true) {
        // get the ADC converted data of three white line sensors from their appropriate channel numbers
        left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
        center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
        right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );
        // printf("\n %d 	%d 	%d", left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data);

        if (center_wl_sensor_data > 200 && left_wl_sensor_data > 200 && right_wl_sensor_data > 200) {
            stop();
            printf("I have seen two black together\n");
            // _delay_ms(325);
            break;
        }
        else if (center_wl_sensor_data > 200) {
            velocity(200, 200);
            // printf("\n forward");
        }
        else if (left_wl_sensor_data > 200) {
            velocity(50, 200);
            // printf("\n left");
        }
        else if (right_wl_sensor_data > 200) {
            velocity(200, 50);
            // printf("\n right");
        }
        else {
            velocity(200, 200);
            // break;
        }
        _delay_ms(10);
    }
}

void zig_zag(unsigned char node) {
    unsigned char node_reached = 0;

    for (int i = 0; i < node; i++) {
        forward();
        _delay_ms(300);

        while (true) {
            // get the ADC converted data of three white line sensors from their appropriate channel numbers
            left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
            center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
            right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );
            // printf("\n %d 	%d 	%d", left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data);

            if (center_wl_sensor_data > 200 && left_wl_sensor_data > 200 && right_wl_sensor_data > 200) {
                _delay_ms(325);

                if (++node_reached == node)
                {
                    stop();
                    printf("Node: %d\n", node_reached);
                    break;
                }
                stop();
                printf("Zig-Zag Node reached: %d\n", ++node_reached);
                break;
            }
            else if (center_wl_sensor_data > 200) {
                velocity(100, 100);
                // printf("\n forward");
            }
            else if (left_wl_sensor_data > 200) {
                velocity(50, 100);
                // printf("\n left");
            }
            else if (right_wl_sensor_data > 200) {
                velocity(100, 50);
                // printf("\n right");
            }
            else if (center_wl_sensor_data < 200 && left_wl_sensor_data < 200 && right_wl_sensor_data < 200) {
                forward();
                _delay_ms(50);

                for (int i = 0; i < 300; i++)
                {
                    left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
                    center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
                    right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );

                    left();
                    velocity(50, 50);

                    if (center_wl_sensor_data > 200 || left_wl_sensor_data > 200 || right_wl_sensor_data > 200)
                    {
                        stop();
                        break;
                    }
                    _delay_ms(1);
                }
                for (int i = 0; i < 600; i++)
                {
                    left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
                    center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
                    right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );

                    right();
                    velocity(50, 50);

                    if (center_wl_sensor_data > 200 || left_wl_sensor_data > 200 || right_wl_sensor_data > 200)
                    {
                        stop();
                        break;
                    }
                    _delay_ms(1);
                }
                forward();
                // printf("\n\tBreak happen");
            }

            else
            {
                //forward();
                velocity(100, 100);
            }
            //printf("finding next condition \n");
            _delay_ms(10);
        }
    }
}

void forward_wls_curve(unsigned char node, unsigned char k)
{
    unsigned char node_reached = 0;

    for (int i = 0; i < node; i++)
    {
        forward();

        while (true)
        {
            left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
            center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
            right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );
            // printf("\n %d 	%d 	%d", left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data);

            if (center_wl_sensor_data > 200 && left_wl_sensor_data > 200 && right_wl_sensor_data > 200)
            {
                printf("curve %d\n", node_reached);
                if (k == 0)
                    velocity(200, 100);
                else
                    velocity(100, 200);

                stop();
                printf("Forward WLS Curve Node reached: %d\n", ++node_reached);
                break;
            }
            else if (center_wl_sensor_data > 200)
            {
                if (k == 0)
                {
                    velocity(200, 100);
                    // printf("\n right 1");
                }
                else
                {
                    velocity(100, 200);
                    // printf("\n left 1");
                }
            }
            else if (left_wl_sensor_data > 200)
            {
                velocity(0, 100);
                // printf("\n right 2");
            }
            else if (right_wl_sensor_data > 200)
            {
                velocity(100, 0);
                // printf("\n left 2");
            }
            _delay_ms(10);
        }
    }
}

void white_line_follow(unsigned char node)
{

    for (int i = 0; i < node; i++)
    {
        forward();
        // _delay_ms(300);

        while (true)
        {
            // get the ADC converted data of three white line sensors from their appropriate channel numbers
            left_wl_sensor_data		= convert_analog_channel_data( left_wl_sensor_channel );
            center_wl_sensor_data	= convert_analog_channel_data( center_wl_sensor_channel );
            right_wl_sensor_data	= convert_analog_channel_data( right_wl_sensor_channel );
            // printf("\n %d 	%d 	%d", left_wl_sensor_data, center_wl_sensor_data, right_wl_sensor_data);

            if (center_wl_sensor_data > 200 && left_wl_sensor_data < 200 && right_wl_sensor_data < 200) {
                stop();
                printf("White Line Follow Complete\n");
                break;
            }
            else if (center_wl_sensor_data < 200) {
                velocity(200, 200);
                // printf("\n forward");
            }
            else if (left_wl_sensor_data < 200) {
                velocity(50, 200);
                // printf("\n left");
            }
            else if (right_wl_sensor_data < 200) {
                velocity(200, 50);
                // printf("\n right");
            }
            else {
                velocity(200, 200);
                // break;
            }
            _delay_ms(10);
        }
    }
}
