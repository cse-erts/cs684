#include "eBot_Sandbox.h"
#include "adacrus.h"
#define uc unsigned char
using namespace std;

Adacrus__main_mem mem;


/**
 * @brief      Executes the logic to achieve the aim of Lab 4
 */
void traverse_line_to_goal() {
    unsigned char left_wl_reading, right_wl_reading, center_wl_reading;
    Adacrus__main_out _res;
    Adacrus__main_reset(&mem);
    while (true) {
        // read sensor values
        left_wl_reading = convert_analog_channel_data( left_wl_sensor_channel );
        center_wl_reading = convert_analog_channel_data( center_wl_sensor_channel );
        right_wl_reading = convert_analog_channel_data( right_wl_sensor_channel );

        cout<<+left_wl_reading<<" "<<+center_wl_reading<<" "<<+right_wl_reading<<" "<<endl;
        // step - generate velocity outputs for the wheels
        Adacrus__main_step(left_wl_reading, center_wl_reading, right_wl_reading,
                           &_res, &mem);
        // perform actuation with outputs
//        if (_res.d_s != last_state) {
//            cout<<_res.v_l<<" "<<_res.v_r<<" "<<string_of_Adacrus__direction(_res.dir, buf_1)<<" "
//                <<string_of_Adacrus__states(_res.s, buf_2)<<" "<<string_of_Adacrus__states(_res.d_s, buf_3)
//                <<" "<<string_of_Adacrus__orientation(_res.o, buf_4)<<endl;
            cout<<_res.v_l<<" "<<_res.v_r<<endl;

//            last_state = _res.d_s;
//        }
        forward();
//        if (_res.s == Adacrus__Exit)
//            break;
//        //if (_res.dir == Adacrus__Forward)
//        //else
//        if (_res.dir == Adacrus__Left)
//            left();
//        else if (_res.dir == Adacrus__Right)
//            right();
//        else if (_res.dir == Adacrus__Stop)
//            stop();
        velocity(_res.v_l, _res.v_r);
//       _delay_ms(1000);
    }
}
