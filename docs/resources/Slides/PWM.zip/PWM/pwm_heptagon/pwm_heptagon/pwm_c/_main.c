/* --- Generated the 1/3/2023 at 15:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled tue. jan. 3 12:16:56 CET 2023) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s pwm_gen -hepts pwm.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "_main.h"

Pwm__pwm_gen_mem mem;
int main(int argc, char** argv) {
  int step_c;
  int step_max;
  Pwm__pwm_gen_out _res;
  step_c = 0;
  step_max = 0;
  if ((argc==2)) {
    step_max = atoi(argv[1]);
  };
  Pwm__pwm_gen_reset(&mem);
  while ((!(step_max)||(step_c<step_max))) {
    step_c = (step_c+1);
    Pwm__pwm_gen_step(&_res, &mem);
    printf("%d\n", _res.pwm1_out);
    printf("%d\n", _res.pwm2_out);
    fflush(stdout);
  };
  return 0;
}

