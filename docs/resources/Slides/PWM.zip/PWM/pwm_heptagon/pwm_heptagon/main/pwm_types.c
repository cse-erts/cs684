/* --- Generated the 1/3/2023 at 15:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled tue. jan. 3 12:16:56 CET 2023) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s pwm_gen -hepts pwm.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pwm_types.h"

