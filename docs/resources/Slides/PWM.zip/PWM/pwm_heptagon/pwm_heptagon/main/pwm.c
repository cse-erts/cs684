/* --- Generated the 1/3/2023 at 15:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled tue. jan. 3 12:16:56 CET 2023) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s pwm_gen -hepts pwm.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pwm.h"

void Pwm__pwm_gen_reset(Pwm__pwm_gen_mem* self) {
  self->v_7 = true;
  self->v_3 = true;
  self->v = true;
}

void Pwm__pwm_gen_step(Pwm__pwm_gen_out* _out, Pwm__pwm_gen_mem* self) {
  
  int v_10;
  int v_8;
  int v_6;
  int v_4;
  int v_2;
  int r;
  v_10 = (self->v_9-50);
  v_6 = (self->v_5+50);
  if (self->v) {
    v_2 = 0;
  } else {
    v_2 = self->v_1;
  };
  r = (v_2>=250);
  if (self->v_7) {
    v_8 = true;
  } else {
    v_8 = r;
  };
  if (v_8) {
    _out->pwm2_out = 250;
  } else {
    _out->pwm2_out = v_10;
  };
  if (self->v_3) {
    v_4 = true;
  } else {
    v_4 = r;
  };
  if (v_4) {
    _out->pwm1_out = 0;
  } else {
    _out->pwm1_out = v_6;
  };
  self->v_9 = _out->pwm2_out;
  self->v_7 = false;
  self->v_5 = _out->pwm1_out;
  self->v_3 = false;
  self->v_1 = _out->pwm1_out;
  self->v = false;;
}

