/* --- Generated the 1/3/2023 at 15:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled tue. jan. 3 12:16:56 CET 2023) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s pwm_gen -hepts pwm.ept --- */

#ifndef PWM_H
#define PWM_H

#include "pwm_types.h"
typedef struct Pwm__pwm_gen_mem {
  int v_9;
  int v_7;
  int v_5;
  int v_3;
  int v_1;
  int v;
} Pwm__pwm_gen_mem;

typedef struct Pwm__pwm_gen_out {
  int pwm1_out;
  int pwm2_out;
} Pwm__pwm_gen_out;

void Pwm__pwm_gen_reset(Pwm__pwm_gen_mem* self);

void Pwm__pwm_gen_step(Pwm__pwm_gen_out* _out, Pwm__pwm_gen_mem* self);

#endif // PWM_H
