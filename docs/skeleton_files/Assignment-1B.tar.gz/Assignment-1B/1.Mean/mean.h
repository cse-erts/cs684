typedef struct memory{
    
} memory;

typedef struct out{
    float out;
} out;

void reset(memory* self); // a pointer to a structure of type memory

void step(float x, int count, out* _out, memory* self);