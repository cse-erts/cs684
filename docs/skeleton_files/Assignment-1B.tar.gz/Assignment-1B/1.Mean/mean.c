#include <stdio.h>
#include "mean.h"

void reset(memory* self) {
    // Enter your code here
}

void step(float x, int count, out* _out, memory* self) {
    // Enter your code here
}
