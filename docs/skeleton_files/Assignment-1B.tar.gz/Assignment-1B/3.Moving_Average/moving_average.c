#include <stdio.h>
#include "moving_average.h"

void reset(memory* self) {
    // Enter your code here
}

void step(float x, int count, out* _out, memory* self) {
    // Enter your code here
}