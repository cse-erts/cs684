#define WINDOW_SIZE 5

typedef struct memory {
  
} memory;

typedef struct out {
    float out;
} out;

void reset(memory* self);

void step(float x, int count, out* _out, memory* self);