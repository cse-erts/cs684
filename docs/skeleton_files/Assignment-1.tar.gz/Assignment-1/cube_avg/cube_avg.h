typedef struct memory {

} memory;

typedef struct out {

} out;

void reset(memory* self);

void step(int x, out* _out, memory* self);
