#include <stdio.h>
#include "cube_avg.h"

void reset(memory* self) {

}

void step(int x, out* _out, memory* self) {

}
