#include <stdio.h>
#include "freq.h"

void reset(memory* self) {

}

void step(int x, out* _out, memory* self) {

}
